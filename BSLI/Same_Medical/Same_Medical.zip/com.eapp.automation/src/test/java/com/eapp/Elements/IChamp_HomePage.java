package com.eapp.Elements;

public class IChamp_HomePage {
	//Eapp_Home
		public static String EmpowerImg="//img[@src='images/logo_right.png']";
		public static String iChamp_Link="//a[text()='iChamp']";
		public static String eApp_Link="//*[@id='pagePort']/article/div/div[1]/div/div[2]/div/a";

	
}

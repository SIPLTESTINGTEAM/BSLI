package com.eapp.Operations;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.eapp.Elements.EApp_LandingPage;
import com.eapp.Elements.IChamp_HomePage;
import com.eapp.Elements.IChamp_LandingPage;
import com.eapp.Elements.Minor_Indian;
import com.eapp.Reporting.Extent_Reporting;

public class EApp_LandingPage_Operations {
		WebDriver driver;
		XSSFWorkbook workbook;
		XSSFSheet sheet;
		XSSFCell cell;
		String desiredPath = "./EApp_Datasheet_2.5.xlsx";
		String fileUploadPath = "C:\\Users\\Public\\Pictures\\Sample Pictures\\Desert.jpg";
		File src = new File(desiredPath);
	
		Minor_Indian minor_indian = new Minor_Indian();
		EApp_LandingPage landing_Page = new EApp_LandingPage();
		
		WebElement MH_Kidneysymp_useWalkStickCheck;WebElement	MH_PDCurrent_Symp	;WebElement MH_PDDoctor_Detail; 
		WebElement	MH_ToggleHIV_yes	;WebElement	MH_HIVCurrentSymp	;WebElement	MH_HIVDoctorDetail	;WebElement	MH_HIVDiagnosis_Date	;WebElement	MH_HIVLastDate_Consult	;
		WebElement	MH_HIVDiagnosisDetail	;WebElement	MH_ToggleTreatment_yes	;WebElement	MH_TNRCurrentSymp	;WebElement	MH_TNRDoctor_Detail	;WebElement	MH_TNRDiagnosis_Date	;
		WebElement	MH_TNRLastDate_Consult	;WebElement	MH_TNRDiagnosis_Detail	;WebElement	MH_Detials_Submit	;
		WebElement	FMH_HBPDisorder	;WebElement	FMH_CancerDisorder	;WebElement	FMH_DiabetesDisorder	;WebElement	FMH_Living_FatherAge	;WebElement	FMH_Living_FatherHealthState	;
		WebElement	FMH_Toggle24_No;WebElement	FMH_Toggle23_No	;WebElement	FMH_Living_MotherHealthState	;WebElement	FMH_Living_MotherAge	;
		WebElement	FMH_HeartDisorder	;WebElement	FMH_ChronicDisorder	;WebElement	FMH_HereditaryDisorderinfo	;WebElement	FMH_HereditaryDisorder	;WebElement	FMH_PlusSign9	;
WebElement	LIS_Toggle_Incident_Yes7;WebElement	LIS_Dive_Incident;WebElement	LIS_DiveIncident_Date;WebElement	LIS_Toggle_Additional;WebElement	LIS_DDiveAddInfo;
WebElement	MH_Chestpain_admitted_add;WebElement	MH_Chestpain_treatment_followup_Yes	;WebElement	MH_Chestpain_treatment_followup_details	;WebElement	MH_Chestpain_additional_information_Yes_chestPain	;
WebElement	MH_Chestpain_additonal_information_notes	;WebElement	MH_Chestpain_Submit	;WebElement	Asthma_Checkbox	;WebElement	MH_Asthma_condition	;WebElement	MH_Asthma_diagnose_date	;
WebElement	MH_Asthma_smoker_Yes	;WebElement	MH_Asthma_smoker_Notes	;WebElement	MH_Asthma_frequent_symptons	;WebElement	MH_Asthma_percipitated_symptomReasonInfo	;WebElement	MH_Asthma_last_sympton_date	;
WebElement	MH_Asthma_other_treatment_Yess	;WebElement	MH_Asthma_other_treatment_medication	;WebElement	MH_Asthma_other_treatment_Dose	;WebElement	MH_Asthma_other_treatment_frequent	;
WebElement	MH_Asthma_other_treatment_ADD	;WebElement	MH_Asthma_undergone_investogone_Yes	;WebElement	MH_Asthma_undergone_investigone_notest	;WebElement	MH_Asthma_doctors_name	;
WebElement	MH_Asthma_doctors_address	;WebElement	MH_Asthma_doctors_date	;WebElement	MH_Asthma_doctors_add	;WebElement	MH_Asthma_time_off_work_Yes	;WebElement	MH_Asthma_time_off_work_details	;
WebElement	MH_Asthma_additional_information_yes	;WebElement	MH_Asthma_addtional_information_notes	;WebElement	MH_Asthma_Submit	;WebElement	MH_Diabtetic_Check	;
WebElement	MH_Diabtetic_detectdate	;WebElement	MH_Diabtetic_smokeoption_yes	;WebElement	MH_Diabtetic_diet_yes	;WebElement	MH_Diabtetic_checkbox1_HeartDisease	;
WebElement	MH_Diabtetic_textbox_HeartDisease	;WebElement	MH_Diabtetic_checkbox2_Albumin	;WebElement	MH_Diabtetic_textbox_Albumin	;WebElement	MH_Diabtetic_textbox_Blood_Pressure	;WebElement	MH_Diabtetic_add_Info_yes	;WebElement	MH_Diabtetic_addinfobox	;WebElement	MH_Diabetes_Save_Button	;
WebElement	MH_ProteinCheck	;WebElement	MH_ProteinCurrentSymp	;WebElement	MH_ProteinDoctorDetail	;WebElement	MH_ProteinDiagnosisDate	;
WebElement	MH_ProteinLastDateConsult	;WebElement	MH_ProteinDiagnosisDetail	;WebElement	MH_UlcerCheck	;WebElement	MH_UlcerCurrentSymp	;WebElement	MH_UlcerDoctorDetail	;
WebElement	MH_UlcerDiagnosisDate	;WebElement	MH_UlcerLastDateConsult	;WebElement	MH_UlcerDiagnosisDetail	;WebElement	MH_TumourCheck	;WebElement	MH_TumourCurrentSymp	;WebElement	MH_TumourDoctor_Detail	;WebElement	MH_TumourDiagnosis_Date	;WebElement	MH_TumourLastDate_Consult	;WebElement	MH_TumourDiagnosis_Detail	;
WebElement	MH_ThyroidDisorder_Check	;WebElement	MH_thyroidDis_Hypothyroidism	;WebElement	MH_diagnise_date	;WebElement	MH_medication_name	;WebElement	MH_Dose_Treat	;
WebElement	MH_frequencyTreat	;WebElement	MH_treatment_date	;WebElement	MH_ThyroidaddTreat	;WebElement	MH_surgery_undergo_toggle_yes	;WebElement	MH_thySurgryInput	;
WebElement	MH_thyfuncTest_date	;WebElement	MH_thyDisord_toggle_yes	;WebElement	MH_thyDisordInput	;WebElement	MH_weight_LG_toggle_yes	;WebElement	MH_thyWeightInput	;
WebElement	MH_add_info_toggle_yes	;WebElement	MH_addit_Input	;WebElement	MH_Thyroidpage_Submit	;WebElement	MH_Anemia_Check	;WebElement	MH_AnemiaCurrentSymp	;
WebElement	MH_AnemiaDoctorDetail	;WebElement	MH_AnemiaDiagnosis_Date	;WebElement	MH_AnemiaLastDateConsult	;WebElement	MH_AnemiaDiagnosisDetail	;WebElement	EmotionalDisordersRadio	;WebElement	MentalDisorderRadio	;WebElement	StrokeRadio	;WebElement	FaintingRadio	;WebElement	MH_Paralysis_Check	;
WebElement	MH_ParalysisCurrentSymp	;WebElement	MH_ParalysisDiagnosisDate	;WebElement	MH_ParalysisLastDateConsult	;WebElement	MH_ParalysisDiagnosisDetail	;WebElement	MH_KidneyRadio	;WebElement	MH_UrinaryRadio	;WebElement	MH_BladderRadio	;WebElement	MH_ReproductiveOrganRadio	;WebElement	MH_ProstateRadio	;WebElement	MH_KidneyCurrent_Symp	;WebElement	MH_KidneyDoctorDetail	;WebElement	MH_KidneyDiagnosisDate	;WebElement	MH_KidneyDiagnosisDetail	;WebElement	MH_KidneyLastDateConsult	;WebElement	MH_arthrities	;WebElement	MH_condRheumatoid	;WebElement	MH_KidneyfstExpSympDate	;WebElement	MH_Kidneysymp_OnGoingCheck	;
WebElement	MH_Kidneysymp_worseningCheck	;WebElement	MH_Kidneysymp_lastExp_SympDate	;WebElement	MH_Kidneysymp_affectedJointsInfo	;WebElement	MH_Kidneysymp_dailyActAffctCheck	;
WebElement	MH_Kidneysymp_dailyActAffctInpt	;	
WebElement	LIS_Toggle_NarcoticSubstance_Yes;WebElement	LIS_NarcoticsInfo;WebElement	LIS_Toggle_AlcoholMandate_Yes;WebElement	LIS_AlcoBeerSel	;WebElement	LIS_AlcoBeerQuant;
WebElement	LIS_AlcoWine_Sel;WebElement	LIS_AlcoWineQuant;WebElement	LIS_Alcoliquor	;WebElement	LIS_AlcoliquorQuant	;WebElement	LIS_Alco_ConsultYes	;WebElement	LIS_AlcoDoc_Nam	;
WebElement	LIS_AlcoIntakeReason;WebElement	LIS_AlcoTreatmntDate;WebElement	LIS_AlcoholTreatmntAdd;WebElement	LIS_Toggle_Alcohol_Anonymous;WebElement	LIS_Toggle_Yes11;
WebElement	LIS_AlcoAdd_Info;WebElement	LIS_AlcoMandate_Submit;WebElement	LIS_Toggle_Yes22;WebElement	LIS_NicotineCigSel;WebElement	LIS_NicotineCigPerDay;
WebElement	LIS_NicotineCigNoOfYea;WebElement	LIS_NicotineBidiSe	;WebElement	LIS_NicotineBidiPerDay;WebElement	LIS_NicotineBidiNoOfYea	;WebElement	LIS_NicotinePaanSel	;
WebElement	LIS_NicotinePaanPerDay;WebElement	LIS_NicotinePaan_NoOfYear;WebElement	LIS_NicotineTobaccoSel;WebElement	LIS_NicotineTobaccoPerDay;WebElement	LIS_NicotineTobacco_NoOfYear;
WebElement	LIS_Toggle_Suggestion_Physician	;WebElement	LIS_Suggestion_Physician_Info;WebElement	LIS_NicotineCigNoOfYear	;
WebElement	LIS_NicotineBidiSel	;WebElement	LIS_NicotineBidiNoOfYear	;		WebElement	LIS_Toggle_Diving;WebElement	LIS_travel_PropertYES;WebElement	LIS_traveloutside_Yes;WebElement	LIS_Travel_Countries;WebElement	LIS_Travel_City;WebElement	LIS_Travel_Date_Arriving;
WebElement	LIS_Travel_Date_Departure;WebElement	LIS_Travel_Visa;WebElement	LIS_Travel_ADD;WebElement	LIS_Travel1_Countries;WebElement	LIS_Travel1_City;WebElement	LIS_Travel1_Date_Arriving;
WebElement	LIS_Travel1_Date_Departure;WebElement	LIS_Travel1_Visa;WebElement	LIS_Travel1_ADD;WebElement	LIS_Travel_Nationality;
WebElement	LIS_travel_PropertDetails;WebElement	LIS_toggle_ofResidence;WebElement	LIS_toggle_ofResidenctype;WebElement	LIS_toggle_ofResidenceAddress;
WebElement	LIS_toggle_Medical_facilities;WebElement	LIS_Toggle_travelbusiness;WebElement	LIS_TravelName;WebElement	LIS_Travelrenum;WebElement	LIS_HealthCare;WebElement	LIS_TravelPrec;WebElement	LIS_ModeTravel;
WebElement	LIS_TravelResp;WebElement	LIS_ContractInfoYes;WebElement	LIS_Date_ofCommencement;WebElement	LISDurations;WebElement	LIS_AddInfo;WebElement	LIS_Add_InfoDetails;WebElement	LISSubmit;
		WebElement Adhar_No;WebElement Minorliving_Dropdown;WebElement Studyingin_Radiobutton;	WebElement Existing_Policy ; WebElement Proposer_Personal_Details; WebElement Proposer_MiddleName; WebElement Proposer_Marital_Status;
		WebElement Relationship; WebElement Proposerholdingcitizenship; WebElement Proposertaxresident;
		WebElement Proposer_professional_Details; WebElement Proposer_Qualifications; WebElement Proposer_occupations;
		WebElement Proposer_Nameofbusiness;WebElement Relationship_Dropdown;		WebElement Proposer_Nature_Business;	WebElement personal_details;
		WebElement Proposer_mname;		WebElement Proposer_Type_Organization;		WebElement PlaceOfBirth;		WebElement Birth_State2;WebElement Birth_State;
		WebElement first_Name;		WebElement Fathermothername;		WebElement  Proposer_Years_Business;
		WebElement Proposer_Annual_Income;		WebElement Proposer_Pan_Card;		WebElement PanCard_Validatebutton;
		WebElement Proposer_Agreebutton;		WebElement Insurer_Personal_Details;		WebElement Insurer_BirthState;		WebElement Insurer_Father_Mother_Name;
		WebElement Insurer_Nationality;		WebElement Insurer_livingwith;		WebElement Insurer_Study;WebElement Proposer_Address_Radiobutton;
		WebElement Exposed_Radiobutton;		WebElement Purpose_Radiobutton;		WebElement Agree;		WebElement Insurer_Class;		WebElement Insureer_TelNo_ResNo;		WebElement Insurer_mobNo;
		WebElement Insurer_AltmobNo;		WebElement Communication_Address ;		WebElement Proposer_Address1;		WebElement Proposer_Address2;
		WebElement Proposer_Address3;		WebElement Proposer_Area;		WebElement Proposer_City_Town_Village;		WebElement Proposer_Pin;
		WebElement Proposer_TelNo_ResNo;		WebElement Proposer_mobNo;		WebElement Proposer_AltmobNo;		WebElement Proposer_Email;
		WebElement Proposer_GetPolicyDoc;		WebElement Proposer_EIA_Details; 	WebElement Nationality_Dropdown;
		WebElement Insurer_PepToggle;		WebElement Insurer_Purposeofinsurance;		WebElement Insurer_Agreebutton; 
		WebElement Existing_Policy_PreviousPolicytab;		WebElement Insured_concurrentPolicy;		WebElement Refused_PostponedPolicies;		WebElement Refused_declined_PostponedPolicy;
		WebElement Familyinsuranceadd;		WebElement allchildreninsured_notinsured;		WebElement Fathersexistingpolicy;
		WebElement Mothersexistingpolicy;		WebElement Brothersexistingpolicy;		WebElement Sistersexistingpolicy;
		WebElement Agreebutton;		WebElement policy_payout_addbutton;		WebElement Account_holder_name;		WebElement Account_Type;		WebElement IFSC_Code;		WebElement Renewal_Policy_addButton;		WebElement Payment_Method;
		WebElement BankDetails_Agreebutton;		WebElement MaritalStatus_Dropdown;	WebElement TaxResidence;
			WebElement PersonalDetailsHealth_addbutton;		WebElement Proposer_Height_Feet;	WebElement Proposer_Height_Inch;
		WebElement Proposer_Weight;		WebElement WeightChange_PastOneYr;		WebElement Reason_ChangeofWeight;
		WebElement Weight_timeofBirth;		WebElement WeightChange_ToggleButton;		WebElement lifStyle_Info_addbutton ;
		WebElement LifestylePlus;WebElement Citizenship;		WebElement LifestylePlus_Travel;		WebElement LifestylePlus_occupation;
		WebElement LifestylePlus_narcotic;		WebElement LifestylePlus_alcohol;		WebElement LifestylePlus_ciagare;
		WebElement HIV_togglebutton;		WebElement Family_MedHist_addbutton;		WebElement DiagonsedWithDiseases;
		WebElement Father_age;		WebElement Mother_age;		WebElement Having_Brother;		WebElement Having_Sister;
		WebElement Sister_age;		WebElement Sister_Health;		WebElement MedicalHistory_addbutton;		WebElement IsOnDiet_togglebutton;
		WebElement ConsultDoctor_togglebutton;		WebElement ECG_Xray_togglebutton;		WebElement AdviseForHospital_togglebutton;
		WebElement NeversufferedDisease_chkbox;		WebElement PhysicalDefect_togglebutton;		WebElement HealthSymptom_togglebutton;
		WebElement Family_Hist_addbutton;
		WebElement	LIS_DivingNumbLoc;WebElement	LIS_DivingNumb_LastMonth;WebElement	LIS_DivingNumb_NextMonth;WebElement	LIS_FreeDiving_Date	;WebElement	LIS_FreeDiving_Freq	;WebElement	LIS_FreeDiving_Intention;WebElement	LIS_Toggle_SkinDiving;WebElement	LIS_SkinDiving_Loc;WebElement	LIS_SkinDivingDate;
		WebElement	LIS_Skin_Diving_Freq;WebElement	LIS_SkinDiving_Intention;WebElement	LIS_Toggle_ScubaDiving;WebElement	LIS_ScubaDiving45To100_Sel;WebElement	LIS_PlatformComp;WebElement	LIS_Toggle_Platform;
		WebElement	LIS_CliffDiving_Intention;WebElement	LIS_Cliff_DivingFreq;	WebElement	LIS_CliffDiving_Date;WebElement	LIS_Toggle_CliffDiving;WebElement	LIS_ScubaDiving_Intention;
		WebElement	LIS_ScubaDivingLoc;WebElement	LIS_ScubaDivingDate;WebElement	LIS_ScubaDiving_Freq;WebElement	LIS_CliffDiving_Loc;
		WebElement	LIS_PlatformLoc	;WebElement	LIS_PlatformDate;WebElement	LIS_PlatformFreq;WebElement	LIS_Platform_Intention;WebElement	LIS_Toggle_Yes6	;WebElement	LIS_Diving_Qualification;
		WebElement	LIS_DivingQualificationObtained_Date;WebElement	LIS_DivingQualification_Add	;WebElement	LIS_DivingAvgDepth;WebElement	LIS_DivingAvgDepthLoc;WebElement	LIS_DivingAvgDepth_LastMonth;
		WebElement	LIS_DivingAvgDepth_NextMonth;WebElement	LIS_DivingMax_Depth	;WebElement	LIS_DivingMaxDepth_Lo;
		WebElement	LIS_DivingMaxDepth_LastMonth;WebElement	LIS_DivingmaxDepth_NextMonth;WebElement	LIS_Divingnumb;
		WebElement Insurer_Height_Feet;		WebElement Insurer_Height_Inch;WebElement pan_close;		WebElement Insurer_Weight;WebElement LIS_Free_Diving;		WebElement DiagonsedWithDiseases_chkbox;		WebElement insurability_dec_addbutton;
		WebElement avail_med_ser_button;		WebElement diagnose_disease_button;		WebElement diagnose_asthma_button;		WebElement consult_doctor_button;
		WebElement healthDetails_Agreebutton;		WebElement Insurer_IAR_MiddleName;		WebElement Insurer_IAR_NonMedical;
		WebElement Insurer_AgeProof;		WebElement Insurer_IAR_personallyMet;		WebElement Insurer_IAR_reference;		WebElement Insurer_IAR_ClusterMarket;
		WebElement Insurer_IAR_durationinYears;		WebElement Insurer_IAR_durationinMonths;		WebElement Insurer_IAR_productoffer;
		WebElement Insurer_IAR_Amountcalculation;		WebElement IAR_EstimateProposer;		WebElement  IAR_EstimateInsurer;
		WebElement IAR_investment_Proposer;		WebElement  IAR_investment_Insurer;		WebElement IAR_liabilities_Proposer;		WebElement IAR_liabilities_Insurer;		WebElement IAR_physicalDefects;		WebElement IAR_adverseeffects;		WebElement IAR_Declined_postponed_application;
		WebElement  IAR_FinancialStability;		WebElement IAR_suspiciousactivity_Report;		WebElement IAR_other_Remarks;
		WebElement IAR_IAgreebutton;		WebElement Review_Application_Place;		WebElement Review_Submitted_button;
		WebElement Review_Enter_OTP;		WebElement Review_OTP_submit;		WebElement ID_proof_doc;
		WebElement IDProof_doc_select ;		WebElement ID_proof_doc_upload;		WebElement address_proof_doc;
		WebElement AddProof_doc_select;		WebElement Online_Payment_button;		WebElement Online_Payment_submit_button;		WebElement IDProof_agree;
		WebElement IDProof_close;		WebElement NonMedical_proof_doc;		WebElement Misc_doc_upload;
		WebElement Photo_upload;		WebElement  NEFT_doc_upload;		WebElement cust_Declaration_doc_upload;
		WebElement Central_KYC_doc_upload;		WebElement ECS_Mandate_doc_upload;
		WebElement NonMed_agree;		WebElement NonMed_close;		WebElement PANCard_doc;		WebElement PANCard_upload;
		WebElement Agree_button;		WebElement close_button;		WebElement ABGEmp_doc;		WebElement ABGEmp_upload;
		WebElement Agree_button_final;		WebElement close_button_final;		WebElement Standard_Age_doc;		WebElement Standard_Age_select;
		WebElement STDage_proof_upload;		WebElement Agree_button_insurer;		WebElement Existingpoliciplus;		WebElement ExisistingToggle;
		WebElement Refusedplus;		WebElement RefusedToggle;		WebElement ExistingPolicyOfFather;		WebElement ChildrenInsured;
		WebElement ExistingPolicyOfSister;		WebElement ExistingPolicyOfMother;		WebElement ExistingPolicyOfBrother;		WebElement Iagree;		WebElement Sales_Hierarchy_IAgree; WebElement Illustration_IAgree; WebElement Existing_BSLI_Policy_Toggle_Yes;
		WebElement Existing_BSLI_Policy_Toggle_No; WebElement Aadhar_UID; WebElement Personal_Details; WebElement Insurer_MiddleName;
		WebElement Marital_Status; WebElement Father_Spouse_Name; WebElement Place_Of_Birth_State;        WebElement Place_Of_Birth_City; WebElement Citizenship_Toggle_Yes; WebElement Citizenship_Toggle_No;
		WebElement Country_Name; WebElement Tax_Resident_Toggle_Yes; WebElement Tax_Resident_Number;		WebElement Proposer_Employer; WebElement Qualification; WebElement Occupation;		WebElement Proposer_Designation; WebElement Proposer_TypeOfOrganization; WebElement Proposer_NatureOfDuties;
		WebElement Proposer_YearsWithEmployer; WebElement Proposer_AnnualIncome; WebElement Proposer_PAN;		WebElement Validate_PAN; WebElement Address1_Ins; WebElement Address3_Ins;		WebElement Area_Ins; WebElement City_Ins; WebElement State_Ins;		WebElement StateIns2; WebElement PIN_Ins; WebElement Tel_No_Ins;
		WebElement Mobile_No_Ins; WebElement Alt_Mobile_No_Ins; WebElement Communication_Details;		WebElement Email_Ins; WebElement Email_Toogle;WebElement EIA_Details;WebElement LIS_Diving_MandateSubmit;
		WebElement PEP_Toogle; WebElement Risk; WebElement EIA_NO;WebElement IAgree;WebElement LIS_DivingMaxDepth_Loc;
		WebElement Concurrent_Toggle; WebElement Country_Name2; WebElement Nominee_First_Name;		WebElement Nominee_Last_Name; WebElement Nominee_DoB; WebElement Nominee_Relationship;
		WebElement Nominee_Share; WebElement Nominee_Add; WebElement Refused_Link;		WebElement Nominee_Agree; WebElement Refused_Toggle; WebElement Nominee_Contact;
	 WebElement PPD_Iagree; WebElement Place_Of_Birth_State2; WebElement Father_Health;	 WebElement Account_Number; WebElement Weight_Kg; WebElement Height_Feet;
	 WebElement Weight_Change_Toggle_No; WebElement Brother_Toggle_NO; WebElement Lifestyle_Toggle3_No;
	 WebElement Family_Medical_History_None; WebElement BankDetails_Iagree; WebElement Brother_Toggle_No;
	 WebElement Account_Holder_Name; WebElement Mother_Health; WebElement IFSC;	 WebElement Lifestyle_Toggle2_No; WebElement MotherAge; WebElement Premium_Link;	 WebElement Savings; WebElement DirectBill; WebElement Lifestyle_Information;
	 WebElement FatherAge; WebElement Family_Medical_History; WebElement Lifestyle_Toggle5_No;	 WebElement Lifestyle_Toggle1_No; WebElement Lifestyle_Toggle4_No; WebElement Height_Inch;
	 WebElement Sister_Toggle_No; WebElement MedicalHistory; WebElement MedicalHistory_Toggle1;	 WebElement MedicalHistory_Toggle2; WebElement MedicalHistory_Toggle3; WebElement MedicalHistory_Toggle4;
	 WebElement MedicalHistory_Toggle5; WebElement MedicalHistory_Toggle6; WebElement MedicalHistory_Toggle7;	 WebElement MedicalHistory_Toggle8; WebElement MedicalHistory_Toggle9; WebElement MedicalHistory_Toggle10;
	 WebElement MedicalHistory_Checkbox_NoDisease; WebElement Father_First_Name; WebElement Father_Middle_Name;
	 WebElement Proffesional_Details;	 WebElement Father_Surname; WebElement Country_of_Birth; WebElement MedicalHistory_IAgree;
	 WebElement NRI_Father_Surname; WebElement NRI_Current_Country; WebElement NRI_Country_of_Birth; 	 WebElement NRI_Country_of_Birth2; WebElement NRI_Country_PR2; WebElement NRI_Country_PR;
	 WebElement NRI_Father_First_Name; WebElement NRI_Date_PR; WebElement NRI_Origin_Yes;	 WebElement Other_Details; WebElement NRI_Last_Visit; WebElement Address3;
	 WebElement NRI_Passport_Number; WebElement Area; WebElement NRI_Current_Country2;	 WebElement NRI_Father_Middle_Name; WebElement Abroad_Area;  WebElement Stay_Months;  WebElement Abroad_Address2;
	 WebElement NRI_Residence;  WebElement Purpose;  WebElement Type_Of_Address;  WebElement Abroad_Address1;
	 WebElement NRI_City;  WebElement NRI_Mobile;  WebElement NRI_State2;  WebElement NRI_Office;  WebElement NRI_State;
	 WebElement Abroad_Address3;  WebElement Stay_Years;  WebElement Purpose_Details;  WebElement NRI_PIN;  WebElement Stay_Office;
	 WebElement NRI_Other_Details;WebElement NRI_Current_Country22; WebElement Eapp_Button; WebElement Search_Input;
	 WebElement Application_Number; WebElement NRI_Tab;WebElement Income_Proof; WebElement Customer_Declaration_Form;
	 WebElement IAR_months; WebElement NRI_IAgree; WebElement Central_Kyc_Form; WebElement Identity_Proof_Document_Type; WebElement IAR_Liabilities;
	 WebElement Passport_Copy; WebElement Payment_Details; WebElement IAR_Years; WebElement IAR_NonMedical; WebElement IAR_Toggle4;
	 WebElement Identity_Proof_Close_Button; WebElement I_Agree_Document_Upload; WebElement IAR_Personally_Met_Yes; WebElement NRI_Account_No; WebElement Bank_Details;
	 WebElement IAR_years; WebElement Income_Proof_Agree_Button; WebElement IAR_How_Calculate;WebElement IAR_Toggle6;WebElement IAR_Toggle5; 
	 WebElement Income_Proof_Browse_Button; WebElement IAR_Months; WebElement IAR_Protection; WebElement Identity_Proof_Browse_Button; WebElement IAR_AgeProof;
	 WebElement IAR_Investments; WebElement Applicant_Request; WebElement I_Agree_Non_Medical_Requirements;WebElement Enter_OTP; WebElement online_payment_submit_button;
	 WebElement IAR_Toggle2; WebElement Cluster_Market;WebElement Identity_Proof_Agree_Button; WebElement IAR_MiddleName;WebElement Exchange_Details;
	 WebElement Income_Proof_Document_Type; WebElement Non_Medical_Requirements;WebElement Exchange_Facility_No;WebElement Reviewed_Accepted;WebElement Identity_Proof;
	 WebElement IAR_IAgree; WebElement Submit_OTP;WebElement Income_Proof_Close_Button;WebElement IAR_Realistic;WebElement Close_Button;
	 WebElement IAR_Other_Remarks; WebElement IAR_Toggle3;WebElement Place_Of_Application;WebElement Cancelled_Cheque;
	 WebElement NRI_Payment_NRE;WebElement IAR_Tab; WebElement Document_Upload_Tab;WebElement abg_Employee_browse;
	 WebElement i_agree_ABG_Employee; WebElement abg_Employee; WebElement i_agree_button; WebElement online_submit;
	 WebElement dummy_payment; WebElement Pay_Now;WebElement Close_Payment_Success;WebElement Tax_Resident_Toggle_No;
	 WebElement Review_and_Acceptance_Tab;	 WebElement holder_Name;		WebElement account_no;		WebElement Acc_type;		WebElement Premium_pay;		WebElement ifsc_code;
		WebElement Direct_bill;	WebElement Iagree4;	WebElement Hight_feet;		WebElement Weight;		WebElement Hight_inch;	WebElement Weightchange;	WebElement weightChangetoggle;		WebElement Travel_Outside;		WebElement lifestyleclick;	 //Sales Hierarchy and Illustration Agree
		WebElement Consume;	WebElement Consume_cigaratte;	WebElement Consume_alcohol;		WebElement familyclick;WebElement	MH_Toggle_MedicalHistory	;WebElement	MH_RA_Symptoms_No	;
WebElement	MH_Clinic_Investigation_No	;WebElement	MH_IsOnDiet_No	;WebElement	MH_UT_No	;WebElement	MH_AS_No	;WebElement	MH_Chestpain_MedicalHistory	;WebElement	MH_Chestpain_investigation_date	;WebElement	MH_Chestpain_investigation_results	;WebElement	MH_Chestpain_investigation_add	;
WebElement	MH_Chestpain_medication_taken_Yes	;WebElement	MH_Chestpain_medication_box	;WebElement	MH_Chestpain_medication_dose	;
WebElement	MH_Chestpain_medication_date	;WebElement	MH_Chestpain_medication_ADD	;WebElement	MH_Chestpain_patient_treatmentYes	;WebElement	MH_Chestpain_admitted_to_hospital_details	;WebElement	MH_Chestpain_admitted_to_hospital	;WebElement	MH_Chestpain_admitted_date	;WebElement	MH_Chestpain_investigation_box	;WebElement	MH_Chestpain_investigations_yes	;WebElement	MH_Chestpain_recurrence_notebox	;WebElement	MH_Chestpain_recurrenceinfo	;WebElement	MH_Chestpain_Date	;WebElement	MH_Chestpain_angina	;	WebElement Fatherhealth_State;
		WebElement Diseasenone;		WebElement motherage;	WebElement Motherhealth_State;	WebElement Sisterhealth_State;		WebElement Havesis;		WebElement Havebrother;		WebElement sisterage;
		WebElement MedicalHistoryClick;	WebElement Medicine_never;	WebElement Medicine_defects;WebElement weightchange;	WebElement Medicine;	WebElement Add;		WebElement Medicine_ECG;
		WebElement Medicine_cold;	WebElement familyhistory;	WebElement Medicine_admit;		WebElement Medicine_symptoms;	WebElement Medicine_HIV;	WebElement Medicine_agree;		WebElement Reason;		WebElement Weightathetimeofbirth;		WebElement normalcareatbirth;		WebElement dignosed;
		WebElement none;	WebElement shortnessofbreath;		WebElement complaint;		WebElement declarationIAgree;
			WebElement Protection;			WebElement documentuploadclick;		WebElement Typeofdoc;		WebElement RAbutton;
		WebElement Typeof_doc;	WebElement Browse;	WebElement DUclose;		WebElement Submit;
				WebElement Non_Medical;	WebElement ID_proof_doc_agree;		WebElement Neft_Cancelled_Cheque;
		WebElement ID_proof_doc_close;	WebElement Miscellaneous_Document;	WebElement Photograph;		WebElement Eapp_Customer_Declaration_Form;
		WebElement	MH_PDDiagnosisDate;WebElement	MH_Toggle_yes;WebElement	MH_OtherDiagnosis_Detail;WebElement	MH_OtherLastDate_Consult;
		WebElement	MH_OtherDiagnosisDate;WebElement	MH_OtherDoctorDetail;WebElement	MH_OtherCurrentSymp;WebElement	MH_OtherIllnessRadio;WebElement	MH_EyeDiagnosis_Detail;
		WebElement	MH_EyeLastDateConsult;WebElement	MH_EyeDiagnosis_Date;WebElement	MH_EyeCurrent_Symp;WebElement	MH_EarDisorderRadio;WebElement	MH_EyeDisorderRadio;
		WebElement	MH_Arthritis_arthrities_Submit;WebElement	MH_systemicadd_Info	;WebElement	MH_systemicManifst_Inpt;WebElement	MH_Arthritis_systemicManifstCheck;WebElement	MH_advisedOPD_Inpt;
		WebElement	MH_Arthritis_advisedOPDCheck;WebElement	MH_arthritisadd	;WebElement	MH_Arthritisresult;WebElement	MH_Arthritis_arthritislocation;WebElement	MH_arthritis_treatmentdate;WebElement	MH_Arthritis_arthritis_treatment;
		WebElement	MH_Arthritis_symp_othertreatment;WebElement	MH_Kidneysymp_curTakeMedicineCheck;WebElement	MH_Kidneysymp_useWalkStickInpt;WebElement	MH_PDLastDateConsult;
		WebElement	MH_PPDDiagnosisDetail;WebElement MH_Diabtetic_checkbox3_Blood_Pressure;
		WebElement MH_Gynac_No; WebElement	MH_Pregant_No;
	 //Riders Tab
		
		@SuppressWarnings("deprecation")
		public void Sales_Hierarchy_Illustration_Agree(WebDriver driver) throws IOException, InterruptedException {
			try {
				
				
				Thread.sleep(1000);
				
				//Sales Hierarchy
				Sales_Hierarchy_IAgree=driver.findElement(By.xpath(EApp_LandingPage.Iagree_SalesH)); 	
				Sales_Hierarchy_IAgree.click();
			       Extent_Reporting.Log_Pass("Clicking I agree for Sales Hierarchy","Clicked I agree for Sales Hierarchy");

					Thread.sleep(2000);
					
					//Illustration
					//Scroll
					JavascriptExecutor jse = (JavascriptExecutor)driver;
					jse.executeScript("window.scrollBy(0,250)", "");
					Thread.sleep(2000);
					Illustration_IAgree = driver.findElement(By.xpath(EApp_LandingPage.Iagree_Illustration));
					Illustration_IAgree.click();
					Thread.sleep(1000);
				       Extent_Reporting.Log_Pass("Clicking I agree for Illustration","Clicked I agree for Illustration");

				       Extent_Reporting.Log_Pass_with_Screenshot("Sales Hierarchy and Illustration Agree", "Sales Hierarchy and Illustration Agree", driver);

					    
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
		
			
	}
		
//Basic Details To be Insured
		//Same_Medical
		
		@SuppressWarnings("deprecation")
		public void Basic_Details_To_Be_Insured_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
			try {
				Thread.sleep(1000);
				System.out.println("Eapp Policy Tab");
				FileInputStream finput = new FileInputStream(src);
				  workbook = new XSSFWorkbook(finput);
				  sheet= workbook.getSheetAt(4);
				
				       //Toggle - Existing BSLI policy
				       Thread.sleep(1000);
				       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
				       Existing_BSLI_Policy_Toggle_No.click();
				       System.out.println("clickcing_Existing_BSLI_Policy_Toggle_No");
				       	
				       Thread.sleep(1000);
						System.out.println("Toggle");

				       
					Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Insurer_UID));
					cell = sheet.getRow(6).getCell(42);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String AadharUID = cell.getStringCellValue();
				       System.out.println(AadharUID);	
				       Aadhar_UID.sendKeys(AadharUID);
				
					Thread.sleep(1000);
					Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
					Personal_Details.click();
					
					//Personal Details
					Thread.sleep(1000);
					Insurer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
					cell = sheet.getRow(6).getCell(44);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String InsurerMiddleName = cell.getStringCellValue();
				       System.out.println(InsurerMiddleName);	
				       Insurer_MiddleName.sendKeys(InsurerMiddleName);
			       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name");
			       
			       Thread.sleep(1000);
					Marital_Status = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MaritalStatus));
					cell = sheet.getRow(6).getCell(45);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String MaritalStatus = cell.getStringCellValue();
				       System.out.println(MaritalStatus);	
				       Select Marital_Status_Dropdown = new Select(Marital_Status);
				       Marital_Status_Dropdown.selectByValue("M");
			       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
			      
			       Thread.sleep(1000);
					Father_Spouse_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
					cell = sheet.getRow(6).getCell(46);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String FatherSpouse_Name = cell.getStringCellValue();
				       System.out.println(FatherSpouse_Name);	
				       Father_Spouse_Name.sendKeys(FatherSpouse_Name);
				       Extent_Reporting.Log_Pass("Entering Father/Spouse Name ","Entered Father/Spouse Name as "+FatherSpouse_Name);
						Thread.sleep(1000);

				     //Scroll
						JavascriptExecutor jse8 = (JavascriptExecutor)driver;
						jse8.executeScript("window.scrollBy(0,50)", "");
						Thread.sleep(1000);
				       
				       Thread.sleep(1000);
						Place_Of_Birth_State = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
						cell = sheet.getRow(6).getCell(47);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String Place_OfBirth_State = cell.getStringCellValue();
					       System.out.println(Place_OfBirth_State);	
					       Place_Of_Birth_State.sendKeys(Place_OfBirth_State);
					       Thread.sleep(1000);
					       Place_Of_Birth_State2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
					       Place_Of_Birth_State2.click();
			       Extent_Reporting.Log_Pass("Entering Place of Birth (State) ","Entered Place of Birth (State) as "+Place_OfBirth_State);
			      
			       Thread.sleep(1000);
					Place_Of_Birth_City = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthCity));
					cell = sheet.getRow(6).getCell(48);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String Place_OfBirth_City = cell.getStringCellValue();
				       System.out.println(Place_OfBirth_City);	
				       Place_Of_Birth_City.sendKeys(Place_OfBirth_City);
		       Extent_Reporting.Log_Pass("Entering Place of Birth (City) ","Entered Place of Birth (City) as "+Place_OfBirth_City);
		      
		       Citizenship_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Citizenship_NO));
		       Citizenship_Toggle_No.click();
		       Thread.sleep(1000);

	       Tax_Resident_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tax_Resident_NO));
	       Tax_Resident_Toggle_No.click();
	       Thread.sleep(1000);
      
      //Professional Details
					       Proffesional_Details = driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
					       Proffesional_Details.click();
					       Thread.sleep(1000);
					       
					       Qualification = driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
					       cell = sheet.getRow(6).getCell(52);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String qualification = cell.getStringCellValue();
					       System.out.println(qualification);	
					       Select qualification_ins = new Select(Qualification);
					       qualification_ins.selectByValue("G");
						       Extent_Reporting.Log_Pass("Selecting Qualification","Selected Qualification as Graduate");
						      
						       Occupation = driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
						       cell = sheet.getRow(6).getCell(53);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String occupation = cell.getStringCellValue();
						       System.out.println(occupation);	
						       Select occupation_ins = new Select(Occupation);
						       occupation_ins.selectByValue("97");
						       Extent_Reporting.Log_Pass("Selecting Occupation","Selected Occupation as Service");
						   		Thread.sleep(2000);
						  
						  	Proposer_Employer = driver.findElement(By.xpath(EApp_LandingPage.SerEmployerName));
							cell = sheet.getRow(6).getCell(54);
						     cell.setCellType(Cell.CELL_TYPE_STRING);
						     String ProposerEmployer = cell.getStringCellValue();
						     System.out.println(ProposerEmployer);	
						     Proposer_Employer.sendKeys(ProposerEmployer);
							Extent_Reporting.Log_Pass("Entering Name of Employer ","Entered Name of Employer as "+ProposerEmployer);
							
							Proposer_Designation = driver.findElement(By.xpath(EApp_LandingPage.designation));
							cell = sheet.getRow(6).getCell(55);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerDesignation = cell.getStringCellValue();
							 System.out.println(ProposerDesignation);	
							 Proposer_Designation.sendKeys(ProposerDesignation);
							Extent_Reporting.Log_Pass("Entering Designation ","Entered Designation as "+ProposerDesignation);
							
							Proposer_TypeOfOrganization = driver.findElement(By.xpath(EApp_LandingPage.SerOrganizationType));
							cell = sheet.getRow(6).getCell(56);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerTypeOfOrganization = cell.getStringCellValue();
							 System.out.println(ProposerTypeOfOrganization);	
							 Select TypeOfOrganization = new Select(Proposer_TypeOfOrganization);
							 TypeOfOrganization.selectByValue("H");	
						     Extent_Reporting.Log_Pass("Entering Type Of Organization ","Entered Type Of Organization as "+ProposerTypeOfOrganization);
							
							Proposer_NatureOfDuties = driver.findElement(By.xpath(EApp_LandingPage.SerNatureOfDuty));
							cell = sheet.getRow(6).getCell(57);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerNatureOfDuties = cell.getStringCellValue();
							 System.out.println(ProposerNatureOfDuties);	
							 Proposer_NatureOfDuties.sendKeys(ProposerNatureOfDuties);
							Extent_Reporting.Log_Pass("Entering Nature Of Duties ","Entered Nature Of Duties as "+ProposerNatureOfDuties);
							
							Proposer_YearsWithEmployer = driver.findElement(By.xpath(EApp_LandingPage.SerExperience));
							cell = sheet.getRow(6).getCell(58);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerYearsWithEmployer = cell.getStringCellValue();
							 System.out.println(ProposerYearsWithEmployer);	
							 Proposer_YearsWithEmployer.sendKeys(ProposerYearsWithEmployer);
							Extent_Reporting.Log_Pass("Entering Years With Employer ","Entered Years With Employer as "+ProposerYearsWithEmployer);
							
							Proposer_AnnualIncome = driver.findElement(By.xpath(EApp_LandingPage.SerAnnualIncome));
							cell = sheet.getRow(6).getCell(69);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerAnnualIncome = cell.getStringCellValue();
							 System.out.println(ProposerAnnualIncome);	
							 Proposer_AnnualIncome.sendKeys(ProposerAnnualIncome);
							Extent_Reporting.Log_Pass("Entering Annual Income ","Entered Annual Income as "+ProposerAnnualIncome);
							
							Proposer_PAN = driver.findElement(By.xpath(EApp_LandingPage.pan));
							cell = sheet.getRow(6).getCell(70);
							 cell.setCellType(Cell.CELL_TYPE_STRING);
							 String ProposerPAN = cell.getStringCellValue();
							 System.out.println(ProposerPAN);	
							 Proposer_PAN.sendKeys(ProposerPAN);
							Extent_Reporting.Log_Pass("Entering PAN ","Entered PAN as "+ProposerPAN);
							
							Validate_PAN = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
							Validate_PAN.click();
							Thread.sleep(1000);
							
			//Scroll
							JavascriptExecutor jse2 = (JavascriptExecutor)driver;
							jse2.executeScript("window.scrollBy(0,250)", "");
							Thread.sleep(1000);
						
			//Communication details
							Communication_Details = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
							Communication_Details.click();
						    Thread.sleep(1000);
						    
		  //Scroll
						  	JavascriptExecutor jse9 = (JavascriptExecutor)driver;
						  	jse9.executeScript("window.scrollBy(0,-150)", "");
						  	Thread.sleep(1000);
						  	
							Address1_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address1));
							cell = sheet.getRow(6).getCell(74);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Address1Ins = cell.getStringCellValue();
							System.out.println(Address1Ins);	
							Address1_Ins.sendKeys(Address1Ins);
							Extent_Reporting.Log_Pass("Entering Address1 ","Entered Address1 as "+Address1Ins);
							
							Address3_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address3));
							cell = sheet.getRow(6).getCell(75);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Address3Ins = cell.getStringCellValue();
							System.out.println(Address3Ins);	
							Address3_Ins.sendKeys(Address3Ins);
							Extent_Reporting.Log_Pass("Entering Address3 ","Entered Address3 as "+Address3Ins);
						
								
							Area_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Area));
							cell = sheet.getRow(6).getCell(77);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String AreaIns = cell.getStringCellValue();
							System.out.println(AreaIns);	
							Area_Ins.sendKeys(AreaIns);
							Extent_Reporting.Log_Pass("Entering Area ","Entered Area as "+AreaIns);
						
						
							City_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_city));
							cell = sheet.getRow(6).getCell(78);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String CityIns = cell.getStringCellValue();
							System.out.println(CityIns);	
							City_Ins.sendKeys(CityIns);
							Extent_Reporting.Log_Pass("Entering City ","Entered City as "+CityIns);
						/*
							State_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_State));
							String StateIns = "MAHARASHTRA";
							System.out.println(StateIns);	
							State_Ins.sendKeys(StateIns);
							Thread.sleep(1000);
							StateIns2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
							StateIns2.click();
							Extent_Reporting.Log_Pass("Entering State ","Entered State as "+StateIns);
						*/
							PIN_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Pin));
							cell = sheet.getRow(6).getCell(79);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String PINIns = cell.getStringCellValue();
							System.out.println(PINIns);	
							PIN_Ins.sendKeys(PINIns);
							Extent_Reporting.Log_Pass("Entering PIN ","Entered PIN as "+PINIns);
						
							Tel_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tel_Number));
							cell = sheet.getRow(6).getCell(80);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String TelNo_Ins = cell.getStringCellValue();
							System.out.println(TelNo_Ins);	
							Tel_No_Ins.sendKeys(TelNo_Ins);
							Extent_Reporting.Log_Pass("Entering Tel No ","Entered Tel No as "+TelNo_Ins);
						
							Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_mobile_Number));
							cell = sheet.getRow(6).getCell(81);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String MobileNo_Ins = cell.getStringCellValue();
							System.out.println(MobileNo_Ins);	
							Mobile_No_Ins.sendKeys(MobileNo_Ins);
							Extent_Reporting.Log_Pass("Entering Mobile No ","Entered Mobile No as "+MobileNo_Ins);
						
			// Scroll Up 
							JavascriptExecutor jse4 = (JavascriptExecutor)driver;
							jse4.executeScript("window.scrollBy(0,150)", "");
							Thread.sleep(1000);
							 
							Alt_Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Alternate_Number));
							cell = sheet.getRow(6).getCell(82);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String AltMobile_No_Ins = cell.getStringCellValue();
							System.out.println(AltMobile_No_Ins);	
							Alt_Mobile_No_Ins.sendKeys(AltMobile_No_Ins);
							Extent_Reporting.Log_Pass("Entering Alternate Mobile No ","Entered Alternate Mobile No as "+AltMobile_No_Ins);
						
							Email_Ins = driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
							cell = sheet.getRow(6).getCell(83);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String EmailIns = cell.getStringCellValue();
							System.out.println(EmailIns);	
							Email_Ins.sendKeys(EmailIns);
							Extent_Reporting.Log_Pass("Entering Email Address ","Entered Email Address as "+EmailIns);
						
							Email_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
							Email_Toogle.click();
							Thread.sleep(1000);
							
			//Scroll
								JavascriptExecutor jse3 = (JavascriptExecutor)driver;
								jse3.executeScript("window.scrollBy(0,250)", "");
								Thread.sleep(1000);
						
			//EIA Details
								EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
								EIA_Details.click();
								Thread.sleep(1000);
								
								EIA_NO = driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
								EIA_NO.click();
								Thread.sleep(1000);
								
			//Other Details
								
								Other_Details = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Other_Details));
								Other_Details.click();
								Thread.sleep(1000);
								
								PEP_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
								PEP_Toogle.click();
								Thread.sleep(1000);
						
								Risk = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
								Risk.click();
								Thread.sleep(1000);
								
								IAgree = driver.findElement(By.xpath(EApp_LandingPage.Basic_Details_Agree));
								IAgree.click();
								Thread.sleep(1000);
	
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
		}

	//NRI
		
		@SuppressWarnings("deprecation")
		public void Basic_Details_To_Be_Insured_NRI(WebDriver driver) throws IOException, InterruptedException {
			try {
				Thread.sleep(1000);
				System.out.println("Eapp Policy Tab");
				FileInputStream finput = new FileInputStream(src);
				  workbook = new XSSFWorkbook(finput);
				  sheet= workbook.getSheetAt(3);
				
				       //Toggle - Existing BSLI policy
				       Thread.sleep(1000);
				       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
				       Existing_BSLI_Policy_Toggle_No.click();
				       System.out.println("clickcing_Existing_BSLI_Policy_Toggle_No");
				       	
				       Thread.sleep(1000);
						System.out.println("Toggle");

				       
					Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Insurer_UID));
					cell = sheet.getRow(6).getCell(43);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String AadharUID = cell.getStringCellValue();
				       System.out.println(AadharUID);	
				       Aadhar_UID.sendKeys(AadharUID);
				
					Thread.sleep(1000);
					Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
					Personal_Details.click();
					
					//Personal Details
					Thread.sleep(1000);
					Insurer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
					cell = sheet.getRow(6).getCell(45);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String InsurerMiddleName = cell.getStringCellValue();
				       System.out.println(InsurerMiddleName);	
				       Insurer_MiddleName.sendKeys(InsurerMiddleName);
			       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name");
			       
			       Thread.sleep(1000);
					Marital_Status = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MaritalStatus));
					cell = sheet.getRow(6).getCell(46);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String MaritalStatus = cell.getStringCellValue();
				       System.out.println(MaritalStatus);	
				       Select Marital_Status_Dropdown = new Select(Marital_Status);
				       Marital_Status_Dropdown.selectByValue("M");
			       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
			      
			       Thread.sleep(1000);
					Father_Spouse_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
					cell = sheet.getRow(6).getCell(47);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String FatherSpouse_Name = cell.getStringCellValue();
				       System.out.println(FatherSpouse_Name);	
				       Father_Spouse_Name.sendKeys(FatherSpouse_Name);
				       Extent_Reporting.Log_Pass("Entering Father/Spouse Name ","Entered Father/Spouse Name as "+FatherSpouse_Name);
						Thread.sleep(1000);

				     //Scroll
						JavascriptExecutor jse8 = (JavascriptExecutor)driver;
						jse8.executeScript("window.scrollBy(0,50)", "");
						Thread.sleep(1000);
				       
				       Thread.sleep(1000);
						Place_Of_Birth_State = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
						cell = sheet.getRow(6).getCell(48);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String Place_OfBirth_State = cell.getStringCellValue();
					       System.out.println(Place_OfBirth_State);	
					       Place_Of_Birth_State.sendKeys(Place_OfBirth_State);
					       Thread.sleep(1000);
					       Place_Of_Birth_State2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
					       Place_Of_Birth_State2.click();
			       Extent_Reporting.Log_Pass("Entering Place of Birth (State) ","Entered Place of Birth (State) as "+Place_OfBirth_State);
			      
			       Thread.sleep(1000);
					Place_Of_Birth_City = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthCity));
					cell = sheet.getRow(6).getCell(49);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String Place_OfBirth_City = cell.getStringCellValue();
				       System.out.println(Place_OfBirth_City);	
				       Place_Of_Birth_City.sendKeys(Place_OfBirth_City);
		       Extent_Reporting.Log_Pass("Entering Place of Birth (City) ","Entered Place of Birth (City) as "+Place_OfBirth_City);
		      
		       Citizenship_Toggle_Yes = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Citizenship_Yes));
		       Citizenship_Toggle_Yes.click();
		       Thread.sleep(1000);

		       Country_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Country_Name));
				cell = sheet.getRow(6).getCell(51);
			       cell.setCellType(Cell.CELL_TYPE_STRING);
			       String CountryName = cell.getStringCellValue();
			       System.out.println(CountryName);	
			       Country_Name.sendKeys(CountryName);
			       Thread.sleep(1000);
			       Country_Name2 = driver.findElement(By.xpath("//li[text()='United States']"));
			       Country_Name2.click();
			       Thread.sleep(1000);

			       
	       Extent_Reporting.Log_Pass("Entering Country ","Entered country as "+CountryName);
	      

	       Tax_Resident_Toggle_Yes = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tax_Resident_Yes));
	       Tax_Resident_Toggle_Yes.click();
	       Thread.sleep(1000);

	       Tax_Resident_Number = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Unique_Tax_Indentification_Number));
			cell = sheet.getRow(6).getCell(53);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String Tax_ResidentNumber = cell.getStringCellValue();
		       System.out.println(Tax_ResidentNumber);	
		       Tax_Resident_Number.sendKeys(Tax_ResidentNumber);
       Extent_Reporting.Log_Pass("Entering Tax Resident Number ","Entered Tax Resident Number as "+Tax_ResidentNumber);
      Thread.sleep(1000);
      
      //Professional Details
	       Proffesional_Details = driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
	       Proffesional_Details.click();
	       Thread.sleep(1000);
	       
	       Qualification = driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
	       cell = sheet.getRow(6).getCell(55);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String qualification = cell.getStringCellValue();
	       System.out.println(qualification);	
	       Select qualification_ins = new Select(Qualification);
	       qualification_ins.selectByValue("G");
       Extent_Reporting.Log_Pass("Selecting Qualification","Selected Qualification as Graduate");
      
       Occupation = driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
       cell = sheet.getRow(6).getCell(56);
       cell.setCellType(Cell.CELL_TYPE_STRING);
       String occupation = cell.getStringCellValue();
       System.out.println(occupation);	
       Select occupation_ins = new Select(Occupation);
       occupation_ins.selectByValue("97");
       Extent_Reporting.Log_Pass("Selecting Occupation","Selected Occupation as Service");
   		Thread.sleep(2000);
  
  	Proposer_Employer = driver.findElement(By.xpath(EApp_LandingPage.SerEmployerName));
	cell = sheet.getRow(6).getCell(57);
     cell.setCellType(Cell.CELL_TYPE_STRING);
     String ProposerEmployer = cell.getStringCellValue();
     System.out.println(ProposerEmployer);	
     Proposer_Employer.sendKeys(ProposerEmployer);
	Extent_Reporting.Log_Pass("Entering Name of Employer ","Entered Name of Employer as "+ProposerEmployer);
	
	Proposer_Designation = driver.findElement(By.xpath(EApp_LandingPage.designation));
	cell = sheet.getRow(6).getCell(58);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerDesignation = cell.getStringCellValue();
	 System.out.println(ProposerDesignation);	
	 Proposer_Designation.sendKeys(ProposerDesignation);
	Extent_Reporting.Log_Pass("Entering Designation ","Entered Designation as "+ProposerDesignation);
	
	Proposer_TypeOfOrganization = driver.findElement(By.xpath(EApp_LandingPage.SerOrganizationType));
	cell = sheet.getRow(6).getCell(59);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerTypeOfOrganization = cell.getStringCellValue();
	 System.out.println(ProposerTypeOfOrganization);	
	 Select TypeOfOrganization = new Select(Proposer_TypeOfOrganization);
	 TypeOfOrganization.selectByValue("H");	
     Extent_Reporting.Log_Pass("Entering Type Of Organization ","Entered Type Of Organization as "+ProposerTypeOfOrganization);
	
	Proposer_NatureOfDuties = driver.findElement(By.xpath(EApp_LandingPage.SerNatureOfDuty));
	cell = sheet.getRow(6).getCell(60);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerNatureOfDuties = cell.getStringCellValue();
	 System.out.println(ProposerNatureOfDuties);	
	 Proposer_NatureOfDuties.sendKeys(ProposerNatureOfDuties);
	Extent_Reporting.Log_Pass("Entering Nature Of Duties ","Entered Nature Of Duties as "+ProposerNatureOfDuties);
	
	Proposer_YearsWithEmployer = driver.findElement(By.xpath(EApp_LandingPage.SerExperience));
	cell = sheet.getRow(6).getCell(61);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerYearsWithEmployer = cell.getStringCellValue();
	 System.out.println(ProposerYearsWithEmployer);	
	 Proposer_YearsWithEmployer.sendKeys(ProposerYearsWithEmployer);
	Extent_Reporting.Log_Pass("Entering Years With Employer ","Entered Years With Employer as "+ProposerYearsWithEmployer);
	
	Proposer_AnnualIncome = driver.findElement(By.xpath(EApp_LandingPage.SerAnnualIncome));
	cell = sheet.getRow(6).getCell(72);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerAnnualIncome = cell.getStringCellValue();
	 System.out.println(ProposerAnnualIncome);	
	 Proposer_AnnualIncome.sendKeys(ProposerAnnualIncome);
	Extent_Reporting.Log_Pass("Entering Annual Income ","Entered Annual Income as "+ProposerAnnualIncome);
	
	Proposer_PAN = driver.findElement(By.xpath(EApp_LandingPage.pan));
	cell = sheet.getRow(6).getCell(73);
	 cell.setCellType(Cell.CELL_TYPE_STRING);
	 String ProposerPAN = cell.getStringCellValue();
	 System.out.println(ProposerPAN);	
	 Proposer_PAN.sendKeys(ProposerPAN);
	Extent_Reporting.Log_Pass("Entering PAN ","Entered PAN as "+ProposerPAN);
	
	Validate_PAN = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
	Validate_PAN.click();
	Thread.sleep(1000);
	
	//Scroll
	JavascriptExecutor jse2 = (JavascriptExecutor)driver;
	jse2.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(1000);

//Communication details
	Communication_Details = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
	Communication_Details.click();
    Thread.sleep(1000);
    
  //Scroll
  	JavascriptExecutor jse9 = (JavascriptExecutor)driver;
  	jse9.executeScript("window.scrollBy(0,-150)", "");
  	Thread.sleep(1000);
  	
	Address1_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address1));
	cell = sheet.getRow(6).getCell(77);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String Address1Ins = cell.getStringCellValue();
	System.out.println(Address1Ins);	
	Address1_Ins.sendKeys(Address1Ins);
	Extent_Reporting.Log_Pass("Entering Address1 ","Entered Address1 as "+Address1Ins);
	
	Address3_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address3));
	cell = sheet.getRow(6).getCell(79);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String Address3Ins = cell.getStringCellValue();
	System.out.println(Address3Ins);	
	Address3_Ins.sendKeys(Address3Ins);
	Extent_Reporting.Log_Pass("Entering Address3 ","Entered Address3 as "+Address3Ins);

		
	Area_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Area));
	cell = sheet.getRow(6).getCell(80);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String AreaIns = cell.getStringCellValue();
	System.out.println(AreaIns);	
	Area_Ins.sendKeys(AreaIns);
	Extent_Reporting.Log_Pass("Entering Area ","Entered Area as "+AreaIns);


	City_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_city));
	cell = sheet.getRow(6).getCell(81);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String CityIns = cell.getStringCellValue();
	System.out.println(CityIns);	
	City_Ins.sendKeys(CityIns);
	Extent_Reporting.Log_Pass("Entering City ","Entered City as "+CityIns);

	State_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_State));
	String StateIns = "MAHARASHTRA";
	System.out.println(StateIns);	
	State_Ins.sendKeys(StateIns);
	Thread.sleep(1000);
	StateIns2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
	StateIns2.click();
	Extent_Reporting.Log_Pass("Entering State ","Entered State as "+StateIns);

	PIN_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Pin));
	cell = sheet.getRow(6).getCell(82);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String PINIns = cell.getStringCellValue();
	System.out.println(PINIns);	
	PIN_Ins.sendKeys(PINIns);
	Extent_Reporting.Log_Pass("Entering PIN ","Entered PIN as "+PINIns);

	Tel_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tel_Number));
	cell = sheet.getRow(6).getCell(83);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String TelNo_Ins = cell.getStringCellValue();
	System.out.println(TelNo_Ins);	
	Tel_No_Ins.sendKeys(TelNo_Ins);
	Extent_Reporting.Log_Pass("Entering Tel No ","Entered Tel No as "+TelNo_Ins);

	Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_mobile_Number));
	cell = sheet.getRow(6).getCell(84);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String MobileNo_Ins = cell.getStringCellValue();
	System.out.println(MobileNo_Ins);	
	Mobile_No_Ins.sendKeys(MobileNo_Ins);
	Extent_Reporting.Log_Pass("Entering Mobile No ","Entered Mobile No as "+MobileNo_Ins);

	// Scroll Up 
	JavascriptExecutor jse4 = (JavascriptExecutor)driver;
	jse4.executeScript("window.scrollBy(0,150)", "");
	Thread.sleep(1000);
	 
	Alt_Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Alternate_Number));
	cell = sheet.getRow(6).getCell(85);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String AltMobile_No_Ins = cell.getStringCellValue();
	System.out.println(AltMobile_No_Ins);	
	Alt_Mobile_No_Ins.sendKeys(AltMobile_No_Ins);
	Extent_Reporting.Log_Pass("Entering Alternate Mobile No ","Entered Alternate Mobile No as "+AltMobile_No_Ins);

	Email_Ins = driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
	cell = sheet.getRow(6).getCell(86);
	cell.setCellType(Cell.CELL_TYPE_STRING);
	String EmailIns = cell.getStringCellValue();
	System.out.println(EmailIns);	
	Email_Ins.sendKeys(EmailIns);
	Extent_Reporting.Log_Pass("Entering Email Address ","Entered Email Address as "+EmailIns);

	Email_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
	Email_Toogle.click();
	Thread.sleep(1000);
	
	//Scroll
		JavascriptExecutor jse3 = (JavascriptExecutor)driver;
		jse3.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);

		//EIA Details
		EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
		EIA_Details.click();
		Thread.sleep(1000);
		
		EIA_NO = driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
		EIA_NO.click();
		Thread.sleep(1000);
		
		//Other Details
		
		Other_Details = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Other_Details));
		Other_Details.click();
		Thread.sleep(1000);
		
		PEP_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
		PEP_Toogle.click();
		Thread.sleep(1000);

		Risk = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
		Risk.click();
		Thread.sleep(1000);
		
		IAgree = driver.findElement(By.xpath(EApp_LandingPage.Basic_Details_Agree));
		IAgree.click();
		Thread.sleep(1000);
	
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
		}
		 
	  		   
		public void previous_details_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
		{
		   try
		   {
          
          Existingpoliciplus = driver.findElement(By.xpath(EApp_LandingPage.Existingpoliciplus));
          Existingpoliciplus.click();
		Thread.sleep(1000);
	   	ExisistingToggle = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyNo));
      	ExisistingToggle.click();
      	
      	Refusedplus=driver.findElement(By.xpath(EApp_LandingPage.PlusSign6));
      	Refusedplus.click();
		
      	RefusedToggle=driver.findElement(By.xpath(EApp_LandingPage.DeclinedPolicyNo));
      	
      	RefusedToggle.click();
      	
      	//family insured history
          ChildrenInsured=driver.findElement(By.xpath(EApp_LandingPage.childreninsuredYes));
          
          ChildrenInsured.click();
          
          
          ExistingPolicyOfFather=driver.findElement(By.xpath(EApp_LandingPage.Existingpolicyfatherno));
          ExistingPolicyOfFather.click();
          
          ExistingPolicyOfMother=driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyMotherNo));
          ExistingPolicyOfMother.click();
          
          ExistingPolicyOfBrother=driver.findElement(By.xpath(EApp_LandingPage.Existingpolicybrono));
          ExistingPolicyOfBrother.click();
          
          ExistingPolicyOfSister=driver.findElement(By.xpath(EApp_LandingPage.Existingpolicysisno));
          ExistingPolicyOfSister.click();
          
          
          Iagree=driver.findElement(By.xpath(EApp_LandingPage.i_agree));
          Iagree.click();
		   }
      	catch(Exception e)
		{
			Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
			e.printStackTrace();
		}
		   }
	    
		 @SuppressWarnings("deprecation")
			public void Minor_Basic_Details_BSLIVisionLifeSecurePlan_DocumentUploadTab(WebDriver driver) throws IOException, InterruptedException {
				    try {
				     Thread.sleep(1000);
				    
				   
				   //identity proof
				      Thread.sleep(1000);
				      ID_proof_doc = driver.findElement(By.xpath(EApp_LandingPage.identity_Proof));
				      ID_proof_doc.click();
				       Extent_Reporting.Log_Pass("Entering ID proof Doc","Entered ID proof");
				    
				       //select id proof doc  
				       Thread.sleep(1000);
				       IDProof_doc_select = driver.findElement(By.xpath(EApp_LandingPage.typeOfDocument));
				       cell = sheet.getRow(6).getCell(243);
				            cell.setCellType(Cell.CELL_TYPE_STRING);
				            String IDProofDoc = cell.getStringCellValue();
				            System.out.println(IDProofDoc); 
				            Select IDProofDoc1 = new Select(IDProof_doc_select);
				            IDProofDoc1.selectByValue("Passport");
				               Extent_Reporting.Log_Pass("Entering Age Proof ","Entered Age Proof is as "+IDProofDoc); 
				          
				       //Upload doc
				               Thread.sleep(1000);
				               //Browse Click
				         ID_proof_doc_upload = driver.findElement(By.xpath(EApp_LandingPage.browseButton));
				         ID_proof_doc_upload.click();
				          Extent_Reporting.Log_Pass("Entering ID proof Doc upload","ID proof doc uploaded successfully");
				      //doc find 
				          
				     
				              Thread.sleep(500);
				            StringSelection ss = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

				              //imitate mouse events like ENTER, CTRL+C, CTRL+V
				              Robot robot = new Robot();
				              robot.delay(250);
				              robot.keyPress(KeyEvent.VK_ENTER);
				              robot.keyRelease(KeyEvent.VK_ENTER);
				              robot.keyPress(KeyEvent.VK_CONTROL);
				              robot.keyPress(KeyEvent.VK_V);
				              robot.keyRelease(KeyEvent.VK_V);
				              robot.keyRelease(KeyEvent.VK_CONTROL);
				              robot.keyPress(KeyEvent.VK_ENTER);
				              robot.delay(50);
				              robot.keyRelease(KeyEvent.VK_ENTER) ;
				              
				              ID_proof_doc_agree = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
				           ID_proof_doc_agree.click();
				           ID_proof_doc_close = driver.findElement(By.xpath(EApp_LandingPage.close_button));
				           ID_proof_doc_close.click();
				              
				              
				   /*   //address proof  
				              Thread.sleep(1000);
				          address_proof_doc = driver.findElement(By.xpath(EApp_LandingPage.ageProof));
				          address_proof_doc.click();
				           Extent_Reporting.Log_Pass("Entering Address proof Doc","Entered Address proof");
				         //select id proof doc  
				        Thread.sleep(1000);
				        IDProof_doc_select = driver.findElement(By.xpath(EApp_LandingPage.typeOfDocument));
				        cell = sheet.getRow(6).getCell(243);
				             cell.setCellType(Cell.CELL_TYPE_STRING);
				             String IDProofDoc12 = cell.getStringCellValue();
				             System.out.println(IDProofDoc); 
				             Select IDProofDoc123 = new Select(IDProof_doc_select);
				             IDProofDoc123.selectByValue("Passport");
				                Extent_Reporting.Log_Pass("Entering Age Proof ","Entered Age Proof is as "+IDProofDoc12); 
				           
				        //Upload doc
				                Thread.sleep(1000);
				           
				           //Browse Click
				          ID_proof_doc_upload = driver.findElement(By.xpath(EApp_LandingPage.browseButton));
				          ID_proof_doc_upload.click();
				           Extent_Reporting.Log_Pass("Entering ID proof Doc upload","ID proof doc uploaded successfully");
				       //doc find
				               Thread.sleep(500);
				             StringSelection ss1 = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);

				               //imitate mouse events like ENTER, CTRL+C, CTRL+V
				               Robot robot1 = new Robot();
				               robot1.delay(250);
				               robot1.keyPress(KeyEvent.VK_ENTER);
				               robot1.keyRelease(KeyEvent.VK_ENTER);
				               robot1.keyPress(KeyEvent.VK_CONTROL);
				               robot1.keyPress(KeyEvent.VK_V);
				               robot1.keyRelease(KeyEvent.VK_V);
				               robot1.keyRelease(KeyEvent.VK_CONTROL);
				               robot1.keyPress(KeyEvent.VK_ENTER);
				               robot1.delay(50);
				               robot1.keyRelease(KeyEvent.VK_ENTER) ;*/
				               
				               // non medical requirement
				               
				               Non_Medical =driver.findElement(By.xpath(EApp_LandingPage.nonMedicalRequirements));
				               Non_Medical.click();
				               //Miscellaneous_Document
				               Miscellaneous_Document = driver.findElement(By.xpath(EApp_LandingPage.miscellaneous_Document));
				               Miscellaneous_Document.click();
				               StringSelection ss2 = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss2, null);

				               //imitate mouse events like ENTER, CTRL+C, CTRL+V
				               Robot robot2 = new Robot();
				               robot2.delay(250);
				               robot2.keyPress(KeyEvent.VK_ENTER);
				               robot2.keyRelease(KeyEvent.VK_ENTER);
				               robot2.keyPress(KeyEvent.VK_CONTROL);
				               robot2.keyPress(KeyEvent.VK_V);
				               robot2.keyRelease(KeyEvent.VK_V);
				               robot2.keyRelease(KeyEvent.VK_CONTROL);
				               robot2.keyPress(KeyEvent.VK_ENTER);
				               robot2.delay(50);
				               robot2.keyRelease(KeyEvent.VK_ENTER) ;
				               
				               //neft_Cancelled_Cheque
				              Neft_Cancelled_Cheque =driver.findElement(By.xpath(EApp_LandingPage.neft_Cancelled_Cheque));
				              Neft_Cancelled_Cheque.click();
				              StringSelection ss3 = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss3, null);

				               //imitate mouse events like ENTER, CTRL+C, CTRL+V
				               Robot robot3 = new Robot();
				               robot3.delay(250);
				               robot3.keyPress(KeyEvent.VK_ENTER);
				               robot3.keyRelease(KeyEvent.VK_ENTER);
				               robot3.keyPress(KeyEvent.VK_CONTROL);
				               robot3.keyPress(KeyEvent.VK_V);
				               robot3.keyRelease(KeyEvent.VK_V);
				               robot3.keyRelease(KeyEvent.VK_CONTROL);
				               robot3.keyPress(KeyEvent.VK_ENTER);
				               robot3.delay(50);
				               robot3.keyRelease(KeyEvent.VK_ENTER) ;
				               //photograph
				               Photograph =driver.findElement(By.xpath(EApp_LandingPage.photograph));
				               Photograph.click();
				               StringSelection ss4 = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss4, null);

				               //imitate mouse events like ENTER, CTRL+C, CTRL+V
				               Robot robot4 = new Robot();
				               robot4.delay(250);
				               robot4.keyPress(KeyEvent.VK_ENTER);
				               robot4.keyRelease(KeyEvent.VK_ENTER);
				               robot4.keyPress(KeyEvent.VK_CONTROL);
				               robot4.keyPress(KeyEvent.VK_V);
				               robot4.keyRelease(KeyEvent.VK_V);
				               robot4.keyRelease(KeyEvent.VK_CONTROL);
				               robot4.keyPress(KeyEvent.VK_ENTER);
				               robot4.delay(50);
				               robot4.keyRelease(KeyEvent.VK_ENTER) ;
				               //eapp_Customer_Declaration_Form
				               Eapp_Customer_Declaration_Form=driver.findElement(By.xpath(EApp_LandingPage.eapp_Customer_Declaration_Form));
				               Eapp_Customer_Declaration_Form.click();
				               StringSelection ss5 = new StringSelection("D:\\Subhojeet\\VAPT.pdf");
				               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss5, null);							
			
			
		   	}
				    
				   	catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
		       
		       
		       
		       }	   
				    
	    @SuppressWarnings("deprecation")
		public void Basic_Details_BSLIVisionLifeSecurePlan_IAR(WebDriver driver) throws InterruptedException 
	       {
	       try {
	    	   Thread.sleep(1000);
	    	   
	    	  //middle name insurer  
	    	   Thread.sleep(1000);
	    	   Insurer_IAR_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.middleName));
	    	   cell = sheet.getRow(6).getCell(211);
	    	         cell.setCellType(Cell.CELL_TYPE_STRING);
	    	         String InsurerIARMiddleName = cell.getStringCellValue();
	    	         System.out.println(InsurerIARMiddleName); 
	    	         Insurer_IAR_MiddleName.sendKeys(InsurerIARMiddleName);
	    	        Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name" +InsurerIARMiddleName);
	    	        
	    	        //non medical
	    	        Thread.sleep(1000);
	    	   Insurer_IAR_NonMedical = driver.findElement(By.xpath(EApp_LandingPage.nonMedical));
	    	   Insurer_IAR_NonMedical.click();
	    	      System.out.println(Insurer_IAR_NonMedical); 
	    	        
	    	      Extent_Reporting.Log_Pass("Entering Insurer's Non Medical Value","Entered Insurer's Non Medical submitted successfully");
	    	        
	    	      
	    	      // age proof
	    	      
	    	      Insurer_AgeProof = driver.findElement(By.xpath(EApp_LandingPage.ageProof_Dropdown));
	    	       cell = sheet.getRow(6).getCell(214);
	    	       cell.setCellType(Cell.CELL_TYPE_STRING);
	    	       String AgeProof = cell.getStringCellValue();
	    	       System.out.println(AgeProof); 
	    	       Select AgeProof1 = new Select(Insurer_AgeProof);
	    	       AgeProof1.selectByValue("Passport");
	    	          Extent_Reporting.Log_Pass("Entering Age Proof ","Entered Age Proof is as "+AgeProof); 
	    	     
	    	      //personally met
	    	          Insurer_IAR_personallyMet = driver.findElement(By.xpath(EApp_LandingPage.Toggle_IAR_Yes));
	    	          Insurer_IAR_personallyMet.click();
	    	       System.out.println(Insurer_IAR_personallyMet); 
	    	         
	    	       Extent_Reporting.Log_Pass("Entering Insurer personally met for application","Entered Insurer personally met for application submitted successfully");
	    	         
	    	 //reference 
	    	       Insurer_IAR_reference = driver.findElement(By.xpath(EApp_LandingPage.applicant_Request));
	    	       Insurer_IAR_reference.click();
	    	       System.out.println("Insurer_IAR_Reference");
	    	       Extent_Reporting.Log_Pass("Entering Insurer Referrence","Entered Insurer Reference" );
	    	       
	    	   //cluster market
	    	       Thread.sleep(1000);
	    	    Insurer_IAR_ClusterMarket = driver.findElement(By.xpath(EApp_LandingPage.clusterName));
	    	    cell = sheet.getRow(6).getCell(217);
	    	          cell.setCellType(Cell.CELL_TYPE_STRING);
	    	          String InsurerIARClusterMarket = cell.getStringCellValue();
	    	          System.out.println(InsurerIARClusterMarket); 
	    	          Insurer_IAR_ClusterMarket.sendKeys(InsurerIARClusterMarket);
	    	         Extent_Reporting.Log_Pass("Entering Cluster Market","Entered Cluster Market" +InsurerIARClusterMarket);
	    	       
	    	         JavascriptExecutor jse = (JavascriptExecutor)driver;
	    	        jse.executeScript("window.scrollBy(0,250)", "");
	    	        Thread.sleep(1000);
	    	        
	    	    
	    	        
	    	  //known insurer in years
	    	        Thread.sleep(1000);
	    	     Insurer_IAR_durationinYears = driver.findElement(By.xpath(EApp_LandingPage.years));
	    	     cell = sheet.getRow(6).getCell(218);
	    	           cell.setCellType(Cell.CELL_TYPE_STRING);
	    	           String InsurerIARdurationyears = cell.getStringCellValue();
	    	           System.out.println(InsurerIARdurationyears); 
	    	           Insurer_IAR_durationinYears.sendKeys(InsurerIARdurationyears);
	    	          Extent_Reporting.Log_Pass("Entering duration of Knowing Insurer in Years","Entered duration of knowing Insurer in Years " +InsurerIARdurationyears);
	    	        
	    	       
	    	     //Known insurer in months      
	    	          Thread.sleep(1000);
	    	     Insurer_IAR_durationinMonths = driver.findElement(By.xpath(EApp_LandingPage.months));
	    	     cell = sheet.getRow(6).getCell(219);
	    	           cell.setCellType(Cell.CELL_TYPE_STRING);
	    	           String InsurerIARdurationmonths = cell.getStringCellValue();
	    	           System.out.println(InsurerIARdurationmonths); 
	    	           Insurer_IAR_durationinMonths.sendKeys(InsurerIARdurationmonths);
	    	          Extent_Reporting.Log_Pass("Entering duration of Knowing Insurer in Months","Entered duration of knowing Insurer in Months " +InsurerIARdurationmonths);
	    	            
	    	       // Product offer
	    	          Insurer_IAR_productoffer = driver.findElement(By.xpath(EApp_LandingPage.protection));
	    	          Insurer_IAR_productoffer.click();
	    	         System.out.println("Insurer_IAR_productoffer");
	    	         Extent_Reporting.Log_Pass("Entering product offers to Insurer ","Entered product offers to Insurer" +Insurer_IAR_productoffer);
	    	    
	    	   //amount calculation process
	    	         Thread.sleep(1000);
	    	      Insurer_IAR_Amountcalculation = driver.findElement(By.xpath(EApp_LandingPage.howCalculate));
	    	      cell = sheet.getRow(6).getCell(221);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String InsurerIARAmountCalculation = cell.getStringCellValue();
	    	            System.out.println(InsurerIARAmountCalculation); 
	    	            Insurer_IAR_Amountcalculation.sendKeys(InsurerIARAmountCalculation);
	    	           Extent_Reporting.Log_Pass("Entering calculation process of Amount","Entered calculation process of Amount " +InsurerIARAmountCalculation);
	    	                 
	    	   //financial details
	    	       //Realistic estimate proposer
	    	           
	    	           Thread.sleep(1000);
	    	      IAR_EstimateProposer = driver.findElement(By.xpath(EApp_LandingPage.realistic_Estimate_Proposer));
	    	      cell = sheet.getRow(6).getCell(223);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IAREstimateProposer = cell.getStringCellValue();
	    	            System.out.println(IAREstimateProposer); 
	    	            IAR_EstimateProposer.sendKeys(IAREstimateProposer);
	    	           Extent_Reporting.Log_Pass("Entering Realistic Estimate for Proposer","Entered Realistic Estimate for Proposer " +IAREstimateProposer);
	    	                 
	    	        //Realistic estimate insurer   
	    	           
	    	           Thread.sleep(1000);
	    	           IAR_EstimateInsurer = driver.findElement(By.xpath(EApp_LandingPage.realistic_Estimate_Insurer));
	    	      cell = sheet.getRow(6).getCell(224);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IAREstimateInsurer = cell.getStringCellValue();
	    	            System.out.println(IAREstimateInsurer); 
	    	            IAR_EstimateInsurer.sendKeys(IAREstimateInsurer);
	    	           Extent_Reporting.Log_Pass("Entering Realistic Estimate for Insurer","Entered Realistic Estimate for Insurer " +IAREstimateInsurer);
	    	                 
	    	      //Investments proposer
	    	           Thread.sleep(1000);
	    	      IAR_investment_Proposer = driver.findElement(By.xpath(EApp_LandingPage.Investment_Proposer));
	    	      cell = sheet.getRow(6).getCell(226);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IARInvestmentProposer = cell.getStringCellValue();
	    	            System.out.println(IARInvestmentProposer); 
	    	            IAR_investment_Proposer.sendKeys(IARInvestmentProposer);
	    	           Extent_Reporting.Log_Pass("Entering Investment of Proposer","Entered Investment of Proposer" +IARInvestmentProposer);
	    	//Investment insurer
	    	           Thread.sleep(1000);
	    	           IAR_investment_Insurer= driver.findElement(By.xpath(EApp_LandingPage.Investment_Insurer));
	    	      cell = sheet.getRow(6).getCell(227);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IARInvestmentInsurer = cell.getStringCellValue();
	    	            System.out.println(IARInvestmentInsurer); 
	    	            IAR_investment_Insurer.sendKeys(IARInvestmentInsurer);
	    	           Extent_Reporting.Log_Pass("Entering Insurer's Investments","Entered Insurer's Investments  " +IARInvestmentInsurer);
	    	               
	    	           //Liabilities proposer
	    	           Thread.sleep(1000);
	    	      IAR_liabilities_Proposer = driver.findElement(By.xpath(EApp_LandingPage.liabilities_Proposer));
	    	      cell = sheet.getRow(6).getCell(229);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IARLiabilitiesProposer = cell.getStringCellValue();
	    	            System.out.println(IARLiabilitiesProposer); 
	    	            IAR_liabilities_Proposer.sendKeys(IARLiabilitiesProposer);
	    	           Extent_Reporting.Log_Pass("Entering Liabilities of Proposer","Entered Liabilities of Proposer" +IARLiabilitiesProposer);
	    	                 
	    	           
	    	           //Liabilities insurer
	    	           Thread.sleep(1000);
	    	           IAR_liabilities_Insurer = driver.findElement(By.xpath(EApp_LandingPage.howCalculate));
	    	      cell = sheet.getRow(6).getCell(230);
	    	            cell.setCellType(Cell.CELL_TYPE_STRING);
	    	            String IARLiabilitiesInsurer = cell.getStringCellValue();
	    	            System.out.println(IARLiabilitiesInsurer); 
	    	            IAR_liabilities_Insurer.sendKeys(IARLiabilitiesInsurer);
	    	           Extent_Reporting.Log_Pass("Entering Insurer's Liabilities ","Entered Insurer's Liabilities " +IARLiabilitiesInsurer);
	    	                 
	    	    //Questions
	    	           
	    	           IAR_physicalDefects = driver.findElement(By.xpath(EApp_LandingPage.Toggle2_IAR_No));
	    	           IAR_physicalDefects.click();
	    	          System.out.println("IAR_physicalDefects");
	    	          Extent_Reporting.Log_Pass("Entering Insurer's Physical Defects Information ","Entered Insurer's Physical Defects Information" +IAR_physicalDefects);
	    	            
	    	           
	    	          IAR_adverseeffects = driver.findElement(By.xpath(EApp_LandingPage.Toggle3_IAR_No));
	    	          IAR_adverseeffects.click();
	    	           System.out.println("IAR_adverseeffects");
	    	           Extent_Reporting.Log_Pass("Entering Insurer's adverse Effect Information ","Entered Insurer's adverse Effect Information" +IAR_adverseeffects);
	    	                
	    	           IAR_Declined_postponed_application = driver.findElement(By.xpath(EApp_LandingPage.Toggle4_IAR_No));
	    	           IAR_Declined_postponed_application .click();
	    	            System.out.println("IAR_Declined_postponed_application ");
	    	            Extent_Reporting.Log_Pass("Entering Insurer's Declined/postponed application Information ","Entered Insurer's Declined/postponed application Information" +IAR_Declined_postponed_application );
	    	              
	    	            IAR_FinancialStability = driver.findElement(By.xpath(EApp_LandingPage.Toggle5_IAR_Yes));
	    	            IAR_FinancialStability.click();
	    	             System.out.println("IAR_FinancialStability");
	    	             Extent_Reporting.Log_Pass("Entering Insurer's Financial stability Information ","Entered Insurer's Financial stability Information" +IAR_FinancialStability);
	    	               
	    	           
	    	             IAR_suspiciousactivity_Report= driver.findElement(By.xpath(EApp_LandingPage.Toggle6_IAR_No));
	    	             IAR_suspiciousactivity_Report.click();
	    	              System.out.println(" IAR_suspiciousactivity_Report");
	    	              Extent_Reporting.Log_Pass("Entering Insurer's Suspicious activity Information ","Entered Insurer's  Suspicious activity  Information" + IAR_suspiciousactivity_Report);
	    	                
	    	           //Remarks
	    	       Thread.sleep(1000);
	    	      IAR_other_Remarks = driver.findElement(By.xpath(EApp_LandingPage.otherRemarks));
	    	      cell = sheet.getRow(6).getCell(236);
	    	      cell.setCellType(Cell.CELL_TYPE_STRING);
	    	           String IAROtherRemarks = cell.getStringCellValue();
	    	          System.out.println(IAROtherRemarks); 
	    	          IAR_other_Remarks.sendKeys(IAROtherRemarks);
	    	         Extent_Reporting.Log_Pass("Entering Other Remarks ","Entered Other Remarks " +IAROtherRemarks);
	    	                         
	    	           
	    	    //I agree button       
	    	           
	    	         JavascriptExecutor jse1 = (JavascriptExecutor)driver;
	    	        jse1.executeScript("window.scrollBy(0,250)", "");
	    	        Thread.sleep(1000);
	    	        IAR_IAgreebutton = driver.findElement(By.xpath(EApp_LandingPage.IAR_IAgree));
	    	     IAR_IAgreebutton.click();

	    	        }
	    	        catch(Exception e)
	    	        {
	    	         Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	    	         e.printStackTrace();
	    	        }       
	    	}
	       
	   	@SuppressWarnings("deprecation")
		public void Basic_Details_BSLIVisionLifeSecurePlan_ReviewandAcceptance(WebDriver driver) throws InterruptedException

	   	{ 
	   		try
	   		{
	   	//Enter otp
	        
	        Thread.sleep(1000);
	        Review_Enter_OTP = driver.findElement(By.xpath(EApp_LandingPage.otp_input));
	        cell = sheet.getRow(6).getCell(240);
	              cell.setCellType(Cell.CELL_TYPE_STRING);
	              String EnterOTP = cell.getStringCellValue();
	              System.out.println(EnterOTP); 
	              Review_Enter_OTP.sendKeys(EnterOTP);
	             Extent_Reporting.Log_Pass("Entering Application submission OTP","Entered Application submission OTP" +EnterOTP);
	         
	      //otp submit
	             Thread.sleep(1000);
	        Review_OTP_submit = driver.findElement(By.xpath(EApp_LandingPage.otp_click));
	        Review_OTP_submit.click();
	         Extent_Reporting.Log_Pass("Entering OTP submit","Entered OTP submit successfully ");
	         
	  
	   	 RAbutton=driver.findElement(By.xpath(EApp_LandingPage.RAbutton));
		   	RAbutton.click();
	   	}
	   	  catch(Exception e)
	        {
	         Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	         e.printStackTrace();
	        }

	   	}

	
		
		public void Basic_Details_BSLIVisionLifeSecurePlan_Paymentgateway(WebDriver driver) throws InterruptedException, AWTException
		{
			try
			{
				
				Submit=driver.findElement(By.xpath(EApp_LandingPage.Submit));
				Submit.click();
				
				
				
				
			}
			catch(Exception e)
			{
    	         Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
    	         e.printStackTrace();
    	        }
		}
	   	
		 @SuppressWarnings("deprecation")
			public void Health_details_Tobeinsured_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
		  		{
		  		   try
		  		   { 
					       	//Health details to be insured
					       
		
					           Hight_feet=driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
							   cell = sheet.getRow(6).getCell(3);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String hight_feet = cell.getStringCellValue();
						       System.out.println(hight_feet);	
						       first_Name.sendKeys(hight_feet);
						       Extent_Reporting.Log_Pass("Enterng hight in feet","Entered hight Successfully");
						       
						       Hight_inch=driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
							   cell = sheet.getRow(6).getCell(3);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String Hight_inch = cell.getStringCellValue();
						       System.out.println(Hight_inch);	
						       first_Name.sendKeys(Hight_inch);
						       Extent_Reporting.Log_Pass("Enterng hight in inch","Entered hight Successfully");
						       
						       Weight=driver.findElement(By.xpath(EApp_LandingPage.Weight));
							   cell = sheet.getRow(6).getCell(3);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String weight = cell.getStringCellValue();
						       System.out.println(weight);	
						       first_Name.sendKeys(weight);
						       Extent_Reporting.Log_Pass("Enterng weight","Entered weight Successfully");
						  
						       
								Weightchange=driver.findElement(By.xpath(EApp_LandingPage.WeightChanDetails));
								   cell = sheet.getRow(6).getCell(49);
							    cell.setCellType(Cell.CELL_TYPE_STRING);
							    String weightchange = cell.getStringCellValue();
							    System.out.println(weightchange);	
							    Weightchange.sendKeys(weight);
							       Extent_Reporting.Log_Pass("Enterng weight","Entered weight Successfully");
						       
							       
									Reason=driver.findElement(By.xpath(EApp_LandingPage.reason));
									   cell = sheet.getRow(6).getCell(49);
								    cell.setCellType(Cell.CELL_TYPE_STRING);
								    String reason = cell.getStringCellValue();
								    System.out.println(reason);	
								    Reason.sendKeys(reason);
								       Extent_Reporting.Log_Pass("Enterng Reason","Entered Reason Successfully");
							   
							       Weightathetimeofbirth=driver.findElement(By.xpath(EApp_LandingPage.Weight_timeofBirth));
								   cell = sheet.getRow(6).getCell(3);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String Weightathetimeofbirth = cell.getStringCellValue();
							       System.out.println(Weightathetimeofbirth);	
							       first_Name.sendKeys(Weightathetimeofbirth);
							       Extent_Reporting.Log_Pass("Enterng weight","Entered weight Successfully");
							       
							       familyhistory=driver.findElement(By.xpath(EApp_LandingPage.familyhistoryplus));
							       familyhistory.click();
							       none=driver.findElement(By.xpath(EApp_LandingPage.none));
							       none.click();
							       
							       //insurability declaration
							       normalcareatbirth=driver.findElement(By.xpath(EApp_LandingPage.normalcareatbirth));
							       normalcareatbirth.click();
							       dignosed=driver.findElement(By.xpath(EApp_LandingPage.dignosed));
							       dignosed.click();
							       
							       
							       shortnessofbreath=driver.findElement(By.xpath(EApp_LandingPage.shortnessofbreath));
							       shortnessofbreath.click();
							       
							       complaint=driver.findElement(By.xpath(EApp_LandingPage.complaints));
							       complaint.click();
							       
							       
							       declarationIAgree=driver.findElement(By.xpath(EApp_LandingPage.DeclarationIagree));
							       declarationIAgree.click();
							       
		  		   }
							       
							   	catch(Exception e)
								{
									Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
									e.printStackTrace();
								}
		  		}
					       
//Minor_Indian
				@SuppressWarnings("deprecation")
				public void Basic_Details_To_Be_Insured_Minor_Indian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						System.out.println("Eapp Policy Tab");
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(5);
						
						       //Toggle - Existing BSLI policy
						       Thread.sleep(1000);
						       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
						       Existing_BSLI_Policy_Toggle_No.click();
						       System.out.println("clickcing_Existing_BSLI_Policy_Toggle_No");
						       	
						       Thread.sleep(1000);
								System.out.println("Toggle");

							    

							    
								Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Proposer_UID));
								cell = sheet.getRow(6).getCell(44);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String AadharUID = cell.getStringCellValue();
							       System.out.println(AadharUID);	
							       Aadhar_UID.sendKeys(AadharUID);
							
								Thread.sleep(1000);
								Proposer_Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
								Proposer_Personal_Details.click();
								
								Thread.sleep(1000);
								Proposer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Proposer_MiddleName));
								cell = sheet.getRow(6).getCell(46);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerMiddleName = cell.getStringCellValue();
							       System.out.println(ProposerMiddleName );	
							       Proposer_MiddleName.sendKeys(ProposerMiddleName );
						       Extent_Reporting.Log_Pass("Entering Proposer's Middle Name","Entered Proposer's Middle Name");
						       
						       Thread.sleep(1000);
						      Relationship = driver.findElement(By.xpath(minor_indian.relationshipwithInsurer));
								cell = sheet.getRow(6).getCell(47);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String Relationship1  = cell.getStringCellValue();
							       System.out.println(Relationship1 );	
							       Select Relationship_Dropdown = new Select(Relationship);
							       Relationship_Dropdown.selectByValue("PAREN");
						       Extent_Reporting.Log_Pass("Selecting Relationship with Insurer","Selected Relationship with Insurer as Parent");
						       
						       
						       
						       Thread.sleep(1000);
								Proposer_Marital_Status = driver.findElement(By.xpath(minor_indian.Proposer_MaritalStatus));
								cell = sheet.getRow(6).getCell(48);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String MaritalStatus = cell.getStringCellValue();
							       System.out.println(MaritalStatus);	
							       Select Proposer_Marital_Status_Dropdown = new Select(Proposer_Marital_Status );
							       Proposer_Marital_Status_Dropdown.selectByValue("M");
						       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
						       
						       
						       Proposerholdingcitizenship = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Citizenship_NO));
						       Proposerholdingcitizenship.click();
						       
						       Proposertaxresident =driver.findElement(By.xpath(EApp_LandingPage.Proposer_Tax_Resident_NO));
						       Proposertaxresident.click(); 
						      
						       Thread.sleep(1000);
						       
						       //proposer professional details
						       Proposer_professional_Details=driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
						       Proposer_professional_Details.click();
						          
						          //Qualifications
						          Proposer_Qualifications=driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
						       cell = sheet.getRow(6).getCell(52);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String qualify = cell.getStringCellValue();
						          System.out.println(qualify); 
						          Select qualification1 = new Select( Proposer_Qualifications);
						          qualification1.selectByValue("S");
						          Extent_Reporting.Log_Pass("Entering Qualification ","Entered Qualification as "+qualify);
						               
						          //Occupations
						          Proposer_occupations =driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
						       cell = sheet.getRow(6).getCell(54);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String occupy = cell.getStringCellValue();
						          System.out.println(occupy); 
						          Select occupations1 = new Select(Proposer_occupations);
						          occupations1.selectByValue("92");
						          Extent_Reporting.Log_Pass("Entering occupations ","Entered occupations as "+occupy);
						          
						          //Name of business
						          Proposer_Nameofbusiness =driver.findElement(By.xpath(EApp_LandingPage.BussEmployerName));
						          cell = sheet.getRow(6).getCell(55);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String Name_business = cell.getStringCellValue();
						          System.out.println(Name_business);
						          Proposer_Nameofbusiness.sendKeys(Name_business);
						          Extent_Reporting.Log_Pass("Entering Name of Business","Entered Name of Business Successfully");
						          
						          //Nature of Business
						          Proposer_Nature_Business =driver.findElement(By.xpath(EApp_LandingPage.NatureofBus));
						          cell = sheet.getRow(6).getCell(56);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String Nature_business = cell.getStringCellValue();
						          System.out.println(Nature_business);
						          Proposer_Nature_Business.sendKeys(Nature_business);
						          Extent_Reporting.Log_Pass("Entering Nature of Business","Entered Nature of Business Successfully");
						          
						          //Type of Organization
						          Proposer_Type_Organization=driver.findElement(By.xpath(EApp_LandingPage.BUsOrganizationType));
						          cell = sheet.getRow(6).getCell(57);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String type_organization = cell.getStringCellValue();
						          System.out.println(type_organization); 
						          Select type_organization1 = new Select(Proposer_Type_Organization);
						          type_organization1.selectByValue("H");
						             Extent_Reporting.Log_Pass("Entering Type_Organization ","Entered Type_Organization as "+type_organization1);
						          
						             //Years in Business
						             Proposer_Years_Business =driver.findElement(By.xpath(EApp_LandingPage.BusExperience));
						          cell = sheet.getRow(6).getCell(58);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String Years_business = cell.getStringCellValue();
						          System.out.println(Years_business);
						          Proposer_Years_Business.sendKeys(Years_business);
						          Extent_Reporting.Log_Pass("Entering Years of Business","Entered Years of Business Successfully");
						             
						          //Annual Income
						          Proposer_Annual_Income =driver.findElement(By.xpath(EApp_LandingPage.BusAnnualIncome));
						          cell = sheet.getRow(6).getCell(70);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String Annual_income = cell.getStringCellValue();
						          System.out.println(Annual_income);
						          Proposer_Annual_Income.sendKeys(Annual_income);
						          Extent_Reporting.Log_Pass("Entering Annual income","Entered Annual Income Successfully");
						          
						          //PAN
						          Proposer_Pan_Card=driver.findElement(By.xpath(EApp_LandingPage.pan));
						          cell = sheet.getRow(6).getCell(71);
						          cell.setCellType(Cell.CELL_TYPE_STRING);
						          String Pan_card = cell.getStringCellValue();
						          System.out.println(Pan_card);
						          Proposer_Pan_Card.sendKeys(Pan_card);
						          Extent_Reporting.Log_Pass("Entering Pan card","Entered Pan card Successfully");
						          
						        //PAN Card Validate
						          PanCard_Validatebutton = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
						          PanCard_Validatebutton.click();
						          
						         /*  //Close
						            pan_close =driver.findElement(By.xpath(""));
						            pan_close.click();
						            
						          */
						         
						          
						          
						       //Communication Details
						       Communication_Address = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
						       Communication_Address.click();
						       
						       
						       //address1
						       
						       Thread.sleep(1000);
						       Proposer_Address1 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address1));
								cell = sheet.getRow(6).getCell(75);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerAddress1  = cell.getStringCellValue();
							       System.out.println(ProposerAddress1);	
							       Proposer_Address1.sendKeys(ProposerAddress1);
						       Extent_Reporting.Log_Pass("Entering Proposer's Address 1","Entered Proposer's Address1");
						       
						     //address2
						       
						       Thread.sleep(1000);
						       Proposer_Address2 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address2));
								cell = sheet.getRow(6).getCell(76);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerAddress2  = cell.getStringCellValue();
							       System.out.println(ProposerAddress2);	
							       Proposer_Address2.sendKeys(ProposerAddress2);
						       Extent_Reporting.Log_Pass("Entering Proposer's Address 2","Entered Proposer's Address2");
						       
						       //address3
						       
						       Thread.sleep(1000);
						       Proposer_Address3 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address3));
								cell = sheet.getRow(6).getCell(77);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerAddress3  = cell.getStringCellValue();
							       System.out.println(ProposerAddress3);	
							       Proposer_Address3.sendKeys(ProposerAddress3);
						       Extent_Reporting.Log_Pass("Entering Proposer's Address 3","Entered Proposer's Address3");
						       
						       //area
						       Thread.sleep(1000);
						       Proposer_Area= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Area));
								cell = sheet.getRow(6).getCell(78);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerArea  = cell.getStringCellValue();
							       System.out.println(ProposerArea);	
							       Proposer_Area.sendKeys(ProposerArea);
						       Extent_Reporting.Log_Pass("Entering Proposer's Area","Entered Proposer's Area");
						       
						       
						       //city/town/village
						       
						       Thread.sleep(1000);
						       Proposer_City_Town_Village= driver.findElement(By.xpath(EApp_LandingPage.Proposer_city));
								cell = sheet.getRow(6).getCell(79);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerCity  = cell.getStringCellValue();
							       System.out.println(ProposerCity);	
							       Proposer_City_Town_Village.sendKeys(ProposerCity);
						       Extent_Reporting.Log_Pass("Entering Proposer's City","Entered Proposer's City"); 
						       
						       
						       //pin
						       Thread.sleep(1000);
						       Proposer_Pin= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Pin));
								cell = sheet.getRow(6).getCell(80);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerPin  = cell.getStringCellValue();
							       System.out.println(ProposerPin);	
							       Proposer_Pin.sendKeys(ProposerPin);
						       Extent_Reporting.Log_Pass("Entering Proposer's Pin","Entered Proposer's Pin"); 
						       
						       //TelNo/ ResNo
						       
						       Thread.sleep(1000);
						       Proposer_TelNo_ResNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Tel_Number));
								cell = sheet.getRow(6).getCell(81);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerTelNo  = cell.getStringCellValue();
							       System.out.println(ProposerTelNo);	
							       Proposer_TelNo_ResNo.sendKeys(ProposerTelNo);
						       Extent_Reporting.Log_Pass("Entering Proposer's Tel No","Entered Proposer's Tel No"); 
						       
						       
						       //mobile no
						       
						       Thread.sleep(1000);
						       Proposer_mobNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_mobile_Number));
								cell = sheet.getRow(6).getCell(82);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerMobNo  = cell.getStringCellValue();
							       System.out.println(ProposerMobNo);	
							       Proposer_mobNo.sendKeys(ProposerMobNo);
						       Extent_Reporting.Log_Pass("Entering Proposer's Mob No","Entered Proposer's Mob No"); 
						       
						       //alt mob no
						       
						       Thread.sleep(1000);
						       Proposer_AltmobNo = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Alternate_Number));
								cell = sheet.getRow(6).getCell(83);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerAltMobNo  = cell.getStringCellValue();
							       System.out.println(ProposerAltMobNo);	
							       Proposer_AltmobNo.sendKeys(ProposerAltMobNo);
						       Extent_Reporting.Log_Pass("Entering Proposer's Alt Mob No","Entered Proposer's Alt Mob No"); 
						       
						       
						      //emailadd
						       
						       Thread.sleep(1000);
						       Proposer_Email= driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
								cell = sheet.getRow(6).getCell(84);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerEmailid = cell.getStringCellValue();
							       System.out.println(ProposerEmailid);	
							       Proposer_Email.sendKeys(ProposerEmailid);
						       Extent_Reporting.Log_Pass("Entering Proposer's EmailId","Entered Proposer's EmailId"); 
						       
						       
						       Proposer_GetPolicyDoc =driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
						       Proposer_GetPolicyDoc.click();
						       
						       
						     //EIA Details
						       Thread.sleep(1000);
						       Proposer_EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
						       Proposer_EIA_Details.click();   
						       EIA_Details =driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
						       EIA_Details .click();
						      
						       JavascriptExecutor jse1 = (JavascriptExecutor)driver;
								jse1.executeScript("window.scrollBy(0,250)", "");
								Thread.sleep(1000);
								Proposer_Agreebutton = driver.findElement(By.xpath(minor_indian.IAgree_button));
								Proposer_Agreebutton.click();
							}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
		
				
				@SuppressWarnings("deprecation")
				public void Policy_Tab_tobeinsured_MinorIndian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
							
						 Existing_Policy = driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
						    Existing_Policy.click();	
						   		
							
						    Thread.sleep(1000);
							Insurer_Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
							Insurer_Personal_Details.click();
							
							
						//Middle name
							Thread.sleep(1000);
							Insurer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
							cell = sheet.getRow(6).getCell(93);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String InsurerMiddleName = cell.getStringCellValue();
						       System.out.println(InsurerMiddleName);	
						       Insurer_MiddleName.sendKeys(InsurerMiddleName);
					       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name");
					       
					    //place of birthstate
					       
					       Thread.sleep(1000);
							Place_Of_Birth_State = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
							cell = sheet.getRow(6).getCell(94);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String Place_OfBirth_State = cell.getStringCellValue();
						       System.out.println(Place_OfBirth_State);	
						       Place_Of_Birth_State.sendKeys(Place_OfBirth_State);
				      Extent_Reporting.Log_Pass("Entering Place of Birth (State) ","Entered Place of Birth (State) as "+Place_OfBirth_State);
				     
				      // place of birth city
				      
				      Thread.sleep(1000);
						Place_Of_Birth_City = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
						cell = sheet.getRow(6).getCell(95);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String Place_OfBirth_City = cell.getStringCellValue();
					       System.out.println(Place_OfBirth_City);	
					       Place_Of_Birth_City.sendKeys(Place_OfBirth_City);
				  Extent_Reporting.Log_Pass("Entering Place of Birth (City) ","Entered Place of Birth (City) as "+Place_OfBirth_City);
				 
							//Father/mother name
							
				  Insurer_Father_Mother_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
					cell = sheet.getRow(6).getCell(96);
				     cell.setCellType(Cell.CELL_TYPE_STRING);
				     String FatherMother_Name = cell.getStringCellValue();
				     System.out.println(FatherMother_Name);	
				     Insurer_Father_Mother_Name .sendKeys(FatherMother_Name);
				     Extent_Reporting.Log_Pass("Entering Father/Mother Name ","Entered Father/Mother Name as "+FatherMother_Name);
					
				     //Nationality
							
				     Insurer_Nationality =driver.findElement(By.xpath(EApp_LandingPage.Insurer_Nationality_Dropdown));
				     cell = sheet.getRow(6).getCell(97);
				     cell.setCellType(Cell.CELL_TYPE_STRING);
				     String Nationality = cell.getStringCellValue();
				     System.out.println(Nationality); 
				     Select Nationality1 = new Select(Insurer_Nationality);
				     Nationality1.selectByValue("Indian");
				        Extent_Reporting.Log_Pass("Entering Nationality ","Entered Nationality as "+Nationality1);
				     	
							//Minor Living with
				        
				        Insurer_livingwith =driver.findElement(By.xpath(minor_indian.Insurer_Living_With));
				        cell = sheet.getRow(6).getCell(98);
				        cell.setCellType(Cell.CELL_TYPE_STRING);
				        String Livingwith = cell.getStringCellValue();
				        System.out.println(Livingwith); 
				        Select Livingwith1 = new Select(Insurer_livingwith);
				        Livingwith1.selectByValue("Parents");
				       Extent_Reporting.Log_Pass("Entering Insurer living with ","Entered Insurer living with as "+Livingwith);
				        	
				           JavascriptExecutor jse1 = (JavascriptExecutor)driver;
							jse1.executeScript("window.scrollBy(0,250)", "");
							Thread.sleep(1000);
							
							
						// Insurer Studying in
							
							Insurer_Study = driver.findElement(By.xpath(minor_indian.Insurer_Study));
							Insurer_Study.click(); 
							cell = sheet.getRow(6).getCell(99);
					        cell.setCellType(Cell.CELL_TYPE_STRING);
					        String StudyPlace = cell.getStringCellValue();
					        System.out.println(StudyPlace); 
					        Extent_Reporting.Log_Pass("Entering Insurer Studied in ","Entered Insurer Studied in as "+StudyPlace);
				        	   	
					     //Insurer Class
					        
					       Insurer_Class = driver.findElement(By.xpath(minor_indian.Insurer_Class));
							cell = sheet.getRow(6).getCell(100);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String InsurerClass = cell.getStringCellValue();
						       System.out.println(InsurerClass);	
						       Insurer_Class.sendKeys(InsurerClass);
					  Extent_Reporting.Log_Pass("Entering Insurer Class","Entered Insurer Class as "+InsurerClass);    
							
					  //Communication Details
				      Communication_Address = driver.findElement(By.xpath(minor_indian.Communication_Address));
				      Communication_Address.click();
				      
				      //TelNo/ ResNo
				      
				      Thread.sleep(1000);
				      Insureer_TelNo_ResNo= driver.findElement(By.xpath(minor_indian.Insurer_Tel_Res_No));
						cell = sheet.getRow(6).getCell(545);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String InsurerTelNo  = cell.getStringCellValue();
					       System.out.println(InsurerTelNo);	
					       Insureer_TelNo_ResNo.sendKeys(InsurerTelNo);
				      Extent_Reporting.Log_Pass("Entering Insurer's Tel No","Entered Insurer's Tel No"); 
				      
				      
				      //mobile no
				      
				      Thread.sleep(1000);
				      Insurer_mobNo= driver.findElement(By.xpath(EApp_LandingPage.Insurer_mobile_Number));
						cell = sheet.getRow(6).getCell(33);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String InsurerMobNo  = cell.getStringCellValue();
					       System.out.println(InsurerMobNo);	
					       Insurer_mobNo.sendKeys(InsurerMobNo);
				      Extent_Reporting.Log_Pass("Entering Insurer's Mob No","Entered Insurer's Mob No"); 
				      
				      //alt mob no
				      
				      Thread.sleep(1000);
				      Insurer_AltmobNo = driver.findElement(By.xpath(minor_indian.Insurer_AltMob_No));
						cell = sheet.getRow(6).getCell(33);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String InsurerAltMobNo  = cell.getStringCellValue();
					       System.out.println(InsurerAltMobNo);	
					       Insurer_AltmobNo.sendKeys(InsurerAltMobNo  );
				      Extent_Reporting.Log_Pass("Entering Proposer's Alt Mob No","Entered Proposer's Alt Mob No"); 
				      
				    //Other Details
				      
				      Thread.sleep(1000);
				      Insurer_PepToggle = driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
				      Insurer_PepToggle.click();
				      
				      //purpose of insurance
				      
				      Thread.sleep(1000);
				      Insurer_Purposeofinsurance = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
				      Insurer_Purposeofinsurance.click(); 
						cell = sheet.getRow(6).getCell(114);
				      cell.setCellType(Cell.CELL_TYPE_STRING);
				      String PurposeofInsurance = cell.getStringCellValue();
				      System.out.println(PurposeofInsurance); 
				      Extent_Reporting.Log_Pass("Entering Insurer Purpose of insurance is ","Entered Insurer Purpose of insurance is as "+PurposeofInsurance);
				  	   	
					//agree button
				      
				      JavascriptExecutor jse = (JavascriptExecutor)driver;
						jse.executeScript("window.scrollBy(0,250)", "");
						Thread.sleep(1000);
						Insurer_Agreebutton = driver.findElement(By.xpath(minor_indian.InsurerIAgreeButton));
						Insurer_Agreebutton.click();
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}		
						
				}


				@SuppressWarnings("deprecation")
				public void PreviousPolicyDetails_Tab_tobeinsured_MinorIndian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						
						 Existing_Policy_PreviousPolicytab = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyAdd));
						 Existing_Policy_PreviousPolicytab.click();	
						 
						 //concurrent policy
						 
						 Thread.sleep(1000);
						 Insured_concurrentPolicy = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyNo));
						 Insured_concurrentPolicy.click();
						 Extent_Reporting.Log_Pass("Entering Concurrent Policy ","Entered concurrent policy successfully");
						 Refused_PostponedPolicies =driver.findElement(By.xpath(EApp_LandingPage.PlusSign6));
						 Refused_PostponedPolicies .click();
						
						 //refused policies
						 
						 Thread.sleep(1000);
						 Refused_declined_PostponedPolicy = driver.findElement(By.xpath(EApp_LandingPage.DeclinedPolicyNo));
						 Refused_declined_PostponedPolicy.click();
						 Extent_Reporting.Log_Pass("Entering Postponed_Refused Policy ","Entered Postponed_Refused policy successfully");
						 
				// family insurance history

				   Thread.sleep(1000);
				   Familyinsuranceadd=driver.findElement(By.xpath(minor_indian.familyinsuranceaddbutton));
				   Familyinsuranceadd.click();
				   
				   
				   allchildreninsured_notinsured =driver.findElement(By.xpath(minor_indian.allinsured));
				   allchildreninsured_notinsured.click();
				   System.out.println("allchildreninsured");
				   Fathersexistingpolicy =driver.findElement(By.xpath(minor_indian.fathersinsurance));
				   Fathersexistingpolicy.click();
				   
				   Mothersexistingpolicy =driver.findElement(By.xpath(minor_indian.mothersinsurance));
				   Mothersexistingpolicy.click();

				   Brothersexistingpolicy =driver.findElement(By.xpath(minor_indian.brothersinsurance));
				   Brothersexistingpolicy.click();

				   Sistersexistingpolicy =driver.findElement(By.xpath(minor_indian.sistersinsurance));
				   Sistersexistingpolicy.click();

				   JavascriptExecutor jse = (JavascriptExecutor)driver;
					jse.executeScript("window.scrollBy(0,250)", "");
					Thread.sleep(1000);
					Agreebutton = driver.findElement(By.xpath(minor_indian.Iagree3));
					Agreebutton.click();

					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}

				}




				@SuppressWarnings("deprecation")
				public void BankDetailsTab_Proposer_MinorIndian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						
				//PolicyPayoutdetails

						 Thread.sleep(1000);
						 policy_payout_addbutton = driver.findElement(By.xpath(minor_indian.policypayoutdetailsaddbutton));
						 policy_payout_addbutton.click();
						 
						//Account Holder name
						 Thread.sleep(1000);
					     Account_holder_name = driver.findElement(By.xpath(EApp_LandingPage.AccountHolderNam));
							cell = sheet.getRow(6).getCell(131);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String Accountholdername  = cell.getStringCellValue();
						       System.out.println(Accountholdername);	
						       Account_holder_name.sendKeys(Accountholdername);
					      Extent_Reporting.Log_Pass("Entering Account Holder Name","Entered Account Holder Name" +Accountholdername); 
					      
					      //Account no
					      Thread.sleep(1000);
						     Account_Number = driver.findElement(By.xpath(EApp_LandingPage.AccountNum));
								cell = sheet.getRow(6).getCell(132);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String AccountNo = cell.getStringCellValue();
							       System.out.println(AccountNo);	
							       Account_Number.sendKeys(AccountNo);
						      Extent_Reporting.Log_Pass("Entering Account No","Entered Account No" +AccountNo); 
						   
						   //Account Type 
						      Thread.sleep(1000);
						      Account_Type = driver.findElement(By.xpath(minor_indian.AccountType));
								cell = sheet.getRow(6).getCell(133);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String AccountType = cell.getStringCellValue();
							       System.out.println(AccountType);	
							       Account_Type.sendKeys(AccountType);
						      Extent_Reporting.Log_Pass("Entering Account Type","Entered Account Type" +AccountType); 
						      
						  //IFSC 
						 Thread.sleep(1000);  
						  IFSC_Code = driver.findElement(By.xpath(EApp_LandingPage.IFSC));
								cell = sheet.getRow(6).getCell(134);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String IFSCCode = cell.getStringCellValue();
							       System.out.println(IFSCCode);	
							       IFSC_Code.sendKeys(IFSCCode);
						      Extent_Reporting.Log_Pass("Entering IFSC Code","Entered IFSC Code" +IFSCCode); 
						         
						 
					// Renewal Premium Payment Details of Proposer
						 
						      
						   Thread.sleep(1000);   
						  Renewal_Policy_addButton = driver.findElement(By.xpath(minor_indian.PlusSign7));
						  Renewal_Policy_addButton.click();
						  
						  //payment method
						  Thread.sleep(1000);  
						  Payment_Method = driver.findElement(By.xpath(EApp_LandingPage.DirectBill));
								cell = sheet.getRow(6).getCell(136);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String Paymentmethod = cell.getStringCellValue();
							       System.out.println(Paymentmethod);	
							       Payment_Method.sendKeys(Paymentmethod);
						      Extent_Reporting.Log_Pass("Entering Account No","Entered Account No" +Paymentmethod); 
						  
				// I agree button

						      JavascriptExecutor jse = (JavascriptExecutor)driver;
						   	jse.executeScript("window.scrollBy(0,250)", "");
						   	Thread.sleep(1000);
						   	BankDetails_Agreebutton = driver.findElement(By.xpath(minor_indian.Iagree4));
						   	BankDetails_Agreebutton.click();

						   	}
						   	catch(Exception e)
						   	{
						   		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						   		e.printStackTrace();
						   	}   
						      
				}		      

			
				 //proposer professional details
				    
				    
				    @SuppressWarnings("deprecation")
					public void prof_details_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
					{
				    	
				        Proposer_professional_Details=driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
				        Proposer_professional_Details.click();
				           
				           //Qualifications
				           Proposer_Qualifications=driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
				           cell = sheet.getRow(6).getCell(52);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String qualify = cell.getStringCellValue();
				           System.out.println(qualify); 
				           Select qualification1 = new Select( Proposer_Qualifications);
				           qualification1.selectByValue("SSC");
				           Extent_Reporting.Log_Pass("Entering Qualification ","Entered Qualification as "+qualify);
				                
				           //Occupations
				           Proposer_occupations =driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
				           cell = sheet.getRow(6).getCell(54);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String occupy = cell.getStringCellValue();
				           System.out.println(occupy); 
				           Select occupations1 = new Select(Proposer_occupations);
				           occupations1.selectByValue("Business Owner");
				           Extent_Reporting.Log_Pass("Entering occupations ","Entered occupations as "+occupy);
				           
				           //Name of business
				           Proposer_Nameofbusiness =driver.findElement(By.xpath(EApp_LandingPage.BussEmployerName));
				           cell = sheet.getRow(6).getCell(55);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String Name_business = cell.getStringCellValue();
				           System.out.println(Name_business);
				           Proposer_Nameofbusiness.sendKeys(Name_business);
				           Extent_Reporting.Log_Pass("Entering Name of Business","Entered Name of Business Successfully");
				           
				           //Nature of Business
				           Proposer_Nature_Business =driver.findElement(By.xpath(EApp_LandingPage.NatureofBus));
				           cell = sheet.getRow(6).getCell(56);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String Nature_business = cell.getStringCellValue();
				           System.out.println(Nature_business);
				           Proposer_Nature_Business.sendKeys(Nature_business);
				           Extent_Reporting.Log_Pass("Entering Nature of Business","Entered Nature of Business Successfully");
				           
				           //Type of Organization
				           Proposer_Type_Organization=driver.findElement(By.xpath(EApp_LandingPage.BUsOrganizationType));
				           cell = sheet.getRow(6).getCell(57);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String type_organization = cell.getStringCellValue();
				           System.out.println(type_organization); 
				           Select type_organization1 = new Select(Proposer_Type_Organization);
				           type_organization1.selectByValue("Private Ltd.");
				              Extent_Reporting.Log_Pass("Entering Type_Organization ","Entered Type_Organization as "+type_organization1);
				           
				              //Years in Business
				              Proposer_Years_Business =driver.findElement(By.xpath(EApp_LandingPage.NatureofBus));
				           cell = sheet.getRow(6).getCell(58);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String Years_business = cell.getStringCellValue();
				           System.out.println(Years_business);
				           Proposer_Years_Business.sendKeys(Years_business);
				           Extent_Reporting.Log_Pass("Entering Years of Business","Entered Years of Business Successfully");
				              
				           //Annual Income
				           Proposer_Annual_Income =driver.findElement(By.xpath(EApp_LandingPage.NatureofBus));
				           cell = sheet.getRow(6).getCell(70);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String Annual_income = cell.getStringCellValue();
				           System.out.println(Annual_income);
				           Proposer_Annual_Income.sendKeys(Annual_income);
				           Extent_Reporting.Log_Pass("Entering Annual income","Entered Annual Income Successfully");
				           
				           //PAN
				           Proposer_Pan_Card=driver.findElement(By.xpath(EApp_LandingPage.pan));
				           cell = sheet.getRow(6).getCell(71);
				           cell.setCellType(Cell.CELL_TYPE_STRING);
				           String Pan_card = cell.getStringCellValue();
				           System.out.println(Pan_card);
				           Proposer_Pan_Card.sendKeys(Pan_card);
				           Extent_Reporting.Log_Pass("Entering Pan card","Entered Pan card Successfully");
				           
				         //PAN Card Validate
				           PanCard_Validatebutton = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
				           PanCard_Validatebutton.click();
				           
				            //Close
				             pan_close =driver.findElement(By.xpath("EApp_LandingPage.pan_close"));
				             pan_close.click();
				    
				             //Communication Details
				             Communication_Address = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
				             Communication_Address.click();
				        
					
				             //address1
				        
				             Thread.sleep(1000);
				             Proposer_Address1 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address1));
				             cell = sheet.getRow(6).getCell(75);
				             cell.setCellType(Cell.CELL_TYPE_STRING);
				             String ProposerAddress1  = cell.getStringCellValue();
				             System.out.println(ProposerAddress1); 
				             Proposer_Address1.sendKeys(ProposerAddress1);
				             Extent_Reporting.Log_Pass("Entering Proposer's Address 1","Entered Proposer's Address1");
				        
				      //address2
				        
				             Thread.sleep(1000);
				             Proposer_Address2 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address2));
				             cell = sheet.getRow(6).getCell(76);
				             cell.setCellType(Cell.CELL_TYPE_STRING);
				             String ProposerAddress2  = cell.getStringCellValue();
				             System.out.println(ProposerAddress2); 
				        	Proposer_Address2.sendKeys(ProposerAddress2);
				        	Extent_Reporting.Log_Pass("Entering Proposer's Address 2","Entered Proposer's Address2");
				        
				        //address3
					        
					        Thread.sleep(1000);
					        Proposer_Address3 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address3));
					        cell = sheet.getRow(6).getCell(77);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerAddress3  = cell.getStringCellValue();
					         System.out.println(ProposerAddress3); 
					         Proposer_Address3.sendKeys(ProposerAddress3);
					        Extent_Reporting.Log_Pass("Entering Proposer's Address 3","Entered Proposer's Address3");
					        
					        //area
					        Thread.sleep(1000);
					        Proposer_Area= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Area));
					        cell = sheet.getRow(6).getCell(78);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerArea  = cell.getStringCellValue();
					         System.out.println(ProposerArea); 
					         Proposer_Area.sendKeys(ProposerArea);
					        Extent_Reporting.Log_Pass("Entering Proposer's Area","Entered Proposer's Area");
					        
					        
					        //city/town/village
					        
					        Thread.sleep(1000);
					        Proposer_City_Town_Village= driver.findElement(By.xpath(EApp_LandingPage.Proposer_city));
					        cell = sheet.getRow(6).getCell(79);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerCity  = cell.getStringCellValue();
					         System.out.println(ProposerCity); 
					         Proposer_City_Town_Village.sendKeys(ProposerCity);
					        Extent_Reporting.Log_Pass("Entering Proposer's City","Entered Proposer's City"); 
					        
						        
					        //pin
					        Thread.sleep(1000);
					        Proposer_Pin= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Pin));
					        cell = sheet.getRow(6).getCell(80);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerPin  = cell.getStringCellValue();
					         System.out.println(ProposerPin); 
					         Proposer_Pin.sendKeys(ProposerPin);
					        Extent_Reporting.Log_Pass("Entering Proposer's Pin","Entered Proposer's Pin"); 
					        
					        //TelNo/ ResNo
					        
					        Thread.sleep(1000);
					        Proposer_TelNo_ResNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Tel_Number));
					        cell = sheet.getRow(6).getCell(81);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerTelNo  = cell.getStringCellValue();
					         System.out.println(ProposerTelNo); 
					         Proposer_TelNo_ResNo.sendKeys(ProposerTelNo);
					        Extent_Reporting.Log_Pass("Entering Proposer's Tel No","Entered Proposer's Tel No"); 
					        
					        
					        //mobile no
					        
					        Thread.sleep(1000);
					        Proposer_mobNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_mobile_Number));
					        cell = sheet.getRow(6).getCell(82);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerMobNo  = cell.getStringCellValue();
					         System.out.println(ProposerMobNo); 
					         Proposer_mobNo.sendKeys(ProposerMobNo);
					        Extent_Reporting.Log_Pass("Entering Proposer's Mob No","Entered Proposer's Mob No"); 
					        
					        //alt mob no
					        
					        Thread.sleep(1000);
					        Proposer_AltmobNo = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Alternate_Number));
					        cell = sheet.getRow(6).getCell(83);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerAltMobNo  = cell.getStringCellValue();
					         System.out.println(ProposerAltMobNo); 
					         Proposer_AltmobNo.sendKeys(ProposerAltMobNo);
					        Extent_Reporting.Log_Pass("Entering Proposer's Alt Mob No","Entered Proposer's Alt Mob No"); 
					        
					        
					       //emailadd
					        
					        Thread.sleep(1000);
					        Proposer_Email= driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
					        cell = sheet.getRow(6).getCell(84);
					         cell.setCellType(Cell.CELL_TYPE_STRING);
					         String ProposerEmailid = cell.getStringCellValue();
					         System.out.println(ProposerEmailid); 
					         Proposer_Email.sendKeys(ProposerEmailid);
					        Extent_Reporting.Log_Pass("Entering Proposer's EmailId","Entered Proposer's EmailId"); 
					        
					        
					        Proposer_GetPolicyDoc =driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
					        Proposer_GetPolicyDoc.click();
					        
					        //document 
					        Proposer_GetPolicyDoc =driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
				            Proposer_GetPolicyDoc.click();
					        
					    
					        
					      //EIA Details
					        Thread.sleep(1000);
					        Proposer_EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
					        Proposer_EIA_Details.click();   
					        EIA_Details =driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
					        EIA_Details .click();
						       
						        JavascriptExecutor jse1 = (JavascriptExecutor)driver;
						   jse1.executeScript("window.scrollBy(0,250)", "");
						   Thread.sleep(1000);
						   Proposer_Agreebutton = driver.findElement(By.xpath(EApp_LandingPage.i_agree));
						   Proposer_Agreebutton.click();
						
					}
				 

				@SuppressWarnings("deprecation")
				public void HealthDetailsTab_Proposer_minorIndian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						
						//Personal Details

						 Thread.sleep(1000);
						 PersonalDetailsHealth_addbutton = driver.findElement(By.xpath(minor_indian.HealthPersonalDetail));
						 PersonalDetailsHealth_addbutton.click();
						 
						//Height in Feet
						 Thread.sleep(1000);
					    Proposer_Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
							cell = sheet.getRow(6).getCell(143);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String ProposerHeightFeet = cell.getStringCellValue();
						       System.out.println(ProposerHeightFeet);	
						       Proposer_Height_Feet.sendKeys(ProposerHeightFeet);
					      Extent_Reporting.Log_Pass("Entering Proposer Height in Feet","Entered Proposer Height in Feet" +ProposerHeightFeet); 
					      
					    //Height in Inch
							 Thread.sleep(1000);
						    Proposer_Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
								cell = sheet.getRow(6).getCell(144);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String ProposerHeightInch = cell.getStringCellValue();
							       System.out.println(ProposerHeightInch);	
							       Proposer_Height_Inch.sendKeys(ProposerHeightInch);
						      Extent_Reporting.Log_Pass("Entering Insurer Height in Inch","Entered Insurer Height in Inch" +ProposerHeightInch); 
						     
						      //Weight
					      Thread.sleep(1000);
						     Proposer_Weight = driver.findElement(By.xpath(EApp_LandingPage.Weight));
								cell = sheet.getRow(6).getCell(145);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String InsurerWeight = cell.getStringCellValue();
							       System.out.println(InsurerWeight);	
							       Proposer_Weight.sendKeys(InsurerWeight);
						      Extent_Reporting.Log_Pass("Entering Insurer Weight ","Entered Insurer Weight" +InsurerWeight); 
						   
						      // Toggle for weight change
						      
						      Thread.sleep(1000);
						      WeightChange_ToggleButton = driver.findElement(By.xpath(minor_indian.Toggle17));
						      WeightChange_ToggleButton.click();	
							       System.out.println("NoWeightchange");	
							       Extent_Reporting.Log_Pass("Entering Weight change","Entered Weight change successfully");       
						      
						         
					      //Lifestyle Information
					      
					      Thread.sleep(1000);
					      lifStyle_Info_addbutton =driver.findElement(By.xpath(minor_indian.PlusSign8));
					      lifStyle_Info_addbutton.click();
					      
					    //LifeStyle Plus
					      
					      LifestylePlus_Travel=driver.findElement(By.xpath(minor_indian.Travel));
					      LifestylePlus_Travel.click(); 
					      LifestylePlus_occupation=driver.findElement(By.xpath(minor_indian.occupation));
					      LifestylePlus_occupation.click();
					      LifestylePlus_narcotic=driver.findElement(By.xpath(minor_indian.narcotic));
					      LifestylePlus_narcotic.click();
					      LifestylePlus_alcohol=driver.findElement(By.xpath(minor_indian.alcohol));
					      LifestylePlus_alcohol.click();
					      LifestylePlus_ciagare=driver.findElement(By.xpath(minor_indian.cigar));
					      LifestylePlus_ciagare.click();
					      
					  //Family Medical History
					      
					      Thread.sleep(1000);
					      Family_MedHist_addbutton =driver.findElement(By.xpath(minor_indian.PlusSign9));
					      Family_MedHist_addbutton.click();
					      
					      //diagonsed with disease
					      
					      Thread.sleep(1000);  
						  DiagonsedWithDiseases = driver.findElement(By.xpath(EApp_LandingPage.FMHNone));
						  DiagonsedWithDiseases.click();		
						  System.out.println("DiagnosedwithDisease");	
						 Extent_Reporting.Log_Pass("Entering Diagnose with Disease","Entered diagnosed with Disease as none"); 
						   
					    //father age
						 
						 Thread.sleep(1000);  
						  Father_age = driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
								cell = sheet.getRow(6).getCell(157);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String FatherAge = cell.getStringCellValue();
							       System.out.println(FatherAge);	
							       Father_age.sendKeys(FatherAge);
						      Extent_Reporting.Log_Pass("Entering Father age","Entered Father age" +FatherAge); 
						   
					      // father health
						    Father_Health = driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
						      cell = sheet.getRow(6).getCell(158);
						      cell.setCellType(Cell.CELL_TYPE_STRING);
						      String FatherHealth = cell.getStringCellValue();
						      System.out.println(FatherHealth); 
						      Select FatherHealth1 = new Select(Father_Health);
						      FatherHealth1.selectByValue("Ok/Good");
						         Extent_Reporting.Log_Pass("Entering Father Health ","Entered Father Health  as "+FatherHealth); 
					      
						 //Mother age
								 
						Thread.sleep(1000);  
						Mother_age = driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
						cell = sheet.getRow(6).getCell(160);
						cell.setCellType(Cell.CELL_TYPE_STRING);
						String MotherAge = cell.getStringCellValue();
						System.out.println(MotherAge);	
						Mother_age .sendKeys(MotherAge);
				  Extent_Reporting.Log_Pass("Entering Mother age","Entered Mother age" +MotherAge); 
								   
							      // Mother health
								    Mother_Health = driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
								      cell = sheet.getRow(6).getCell(161);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String MotherHealth = cell.getStringCellValue();
								      System.out.println(MotherHealth); 
								      Select MotherHealth1 = new Select(Mother_Health);
								      MotherHealth1.selectByValue("Ok/Good");
								         Extent_Reporting.Log_Pass("Entering Mother Health ","Entered Mother Health  as "+MotherHealth); 
							      
					    // brother
								         
					    Having_Brother = driver.findElement(By.xpath(minor_indian.Toggle23));
					    Having_Brother.click();
					    Extent_Reporting.Log_Pass("Entering Having Brother ","Entered Having Brother as None"); 
					      
					    
					    //Sister
					    
					    Having_Sister =driver.findElement(By.xpath(minor_indian.ToggleYes));
					    Having_Sister.click();
					    Extent_Reporting.Log_Pass("Entering Having Sister ","Entered Having Sister"); 
					       
					  //Sister age
						 
					  		Thread.sleep(1000);  
					  		Sister_age = driver.findElement(By.xpath(EApp_LandingPage.SisterAge));
					  		cell = sheet.getRow(6).getCell(167);
					  		cell.setCellType(Cell.CELL_TYPE_STRING);
					  		String SisterAge = cell.getStringCellValue();
					  		System.out.println(SisterAge);	
					  		Sister_age .sendKeys(SisterAge);
					    Extent_Reporting.Log_Pass("Entering Sister age","Entered Sister age" +SisterAge); 
					  				   
					  			      // Sister health
					  				    Sister_Health = driver.findElement(By.xpath(EApp_LandingPage.SisterHealthState));
					  				      cell = sheet.getRow(6).getCell(168);
					  				      cell.setCellType(Cell.CELL_TYPE_STRING);
					  				      String SisterHealth = cell.getStringCellValue();
					  				      System.out.println(SisterHealth); 
					  				      Select SisterHealth1 = new Select(Sister_Health);
					  				    SisterHealth1.selectByValue("Ok/Good");
					  				         Extent_Reporting.Log_Pass("Entering Sister Health ","Entered Sister Health  as "+SisterHealth); 
					  			      
						  
					  				         
					  				         //Medical History
					  				         
					  				       Thread.sleep(1000);
					  				      MedicalHistory_addbutton =driver.findElement(By.xpath(minor_indian.PlusSign10));
					  				    MedicalHistory_addbutton.click();
					  				      		         
					  			// is on diet
					  				  Thread.sleep(1000);
				  				      IsOnDiet_togglebutton =driver.findElement(By.xpath(minor_indian.ToggleNo));
				  				    IsOnDiet_togglebutton.click();
				  			
				  				 // consult doctor
				  				    
				  				  Thread.sleep(1000);
								      ConsultDoctor_togglebutton =driver.findElement(By.xpath(minor_indian.consultDoctor_No));
								      ConsultDoctor_togglebutton.click();
								 
								      //ECG/Xray
								      
								      Thread.sleep(1000);
								      ECG_Xray_togglebutton =driver.findElement(By.xpath(minor_indian.ECG_NO));
								      ECG_Xray_togglebutton.click();
								  
								// advise to admit hospital
								      Thread.sleep(1000);
								      AdviseForHospital_togglebutton =driver.findElement(By.xpath(minor_indian.Advise_for_Hospital_No));
								      AdviseForHospital_togglebutton.click();
					  				         
					  		//never suffered disease
								      Thread.sleep(1000);
								      NeversufferedDisease_chkbox =driver.findElement(By.xpath(minor_indian.never_suffered_chkbox));
								      NeversufferedDisease_chkbox.click();   
							//Physical Defect
								      Thread.sleep(1000);
								      PhysicalDefect_togglebutton =driver.findElement(By.xpath(minor_indian.physicalDefect_No));
								      PhysicalDefect_togglebutton.click();    
					  		//health symptom complaint
								      Thread.sleep(1000);
								      HealthSymptom_togglebutton =driver.findElement(By.xpath(minor_indian.health_symptom_No));
								      HealthSymptom_togglebutton.click();       
					  		//HIV
								      Thread.sleep(1000);
								      HIV_togglebutton =driver.findElement(By.xpath(minor_indian.HIV_No));
								      HIV_togglebutton.click();          
						  //Agree button
								      
								      JavascriptExecutor jse = (JavascriptExecutor)driver;
								  	jse.executeScript("window.scrollBy(0,250)", "");
								  	Thread.sleep(1000);
								  	Agreebutton = driver.findElement(By.xpath(EApp_LandingPage.Iagree5));
								  	Agreebutton.click();   
								      
								      
				//I agree button

						      JavascriptExecutor jse1 = (JavascriptExecutor)driver;
						   	jse1.executeScript("window.scrollBy(0,250)", "");
						   	Thread.sleep(1000);
						   	BankDetails_Agreebutton = driver.findElement(By.xpath(minor_indian.Iagree4));
						   	BankDetails_Agreebutton.click();

						   	}
						   	catch(Exception e)
						   	{
						   		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						   		e.printStackTrace();
						   	}   
						      
				}

				@SuppressWarnings("deprecation")
				public void HealthDetailsTab_ToBeInsured_minorIndian(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						
						//Personal Details

						 Thread.sleep(1000);
						 PersonalDetailsHealth_addbutton = driver.findElement(By.xpath(minor_indian.HealthPersonalDetail));
						 PersonalDetailsHealth_addbutton.click();
						 
						//Height in Feet
						 Thread.sleep(1000);
					    Insurer_Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
							cell = sheet.getRow(6).getCell(197);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String InsurerHeightFeet = cell.getStringCellValue();
						       System.out.println(InsurerHeightFeet);	
						       Insurer_Height_Feet.sendKeys(InsurerHeightFeet);
					      Extent_Reporting.Log_Pass("Entering Insurer Height in Feet","Entered Insurer Height in Feet" +InsurerHeightFeet); 
					      
					    //Height in Inch
							 Thread.sleep(1000);
						    Insurer_Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
								cell = sheet.getRow(6).getCell(198);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String InsurerHeightInch = cell.getStringCellValue();
							       System.out.println(InsurerHeightInch);	
							       Insurer_Height_Inch.sendKeys(InsurerHeightInch);
						      Extent_Reporting.Log_Pass("Entering Insurer Height in Inch","Entered Insurer Height in Inch" +InsurerHeightInch); 
						     
						      //Weight
					      Thread.sleep(1000);
						     Insurer_Weight = driver.findElement(By.xpath(EApp_LandingPage.Weight));
								cell = sheet.getRow(6).getCell(199);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String InsurerWeight = cell.getStringCellValue();
							       System.out.println(InsurerWeight);	
							       Insurer_Weight.sendKeys(InsurerWeight);
						      Extent_Reporting.Log_Pass("Entering Insurer Weight ","Entered Insurer Weight" +InsurerWeight); 
						   
						    /*  // Toggle for weight change
						      
						      Thread.sleep(1000);
						      WeightChange_ToggleButton = driver.findElement(By.xpath(EApp_LandingPage.Toggle17));
						      WeightChange_ToggleButton.click();	
							       System.out.println("Weightchange");	
							       Extent_Reporting.Log_Pass("Entering Weight change","Entered Weight change successfully");       
						    */
							       
								   //Weight change past one year
								      Thread.sleep(1000);
								      WeightChange_PastOneYr = driver.findElement(By.xpath(minor_indian.Weight_Change_inKG));
										cell = sheet.getRow(6).getCell(200);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String Weightchangeoneyear = cell.getStringCellValue();
									       System.out.println(Weightchangeoneyear);	
									       WeightChange_PastOneYr.sendKeys(Weightchangeoneyear);
								      Extent_Reporting.Log_Pass("Entering Weight change for last one year","Entered Weight change for last one year" +Weightchangeoneyear); 
								      
								  //Reasons For change
								 Thread.sleep(1000);  
								  Reason_ChangeofWeight= driver.findElement(By.xpath(EApp_LandingPage.WeightChanDetails));
										cell = sheet.getRow(6).getCell(201);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String ReasonForChange = cell.getStringCellValue();
									       System.out.println(ReasonForChange);	
									       Reason_ChangeofWeight.sendKeys(ReasonForChange);
								      Extent_Reporting.Log_Pass("Entering Reason for weight Change","Entered Reason for weight Change" +ReasonForChange); 
								         
								 
							// Weight At time of Birth
								 
								   Thread.sleep(1000);   
								   Weight_timeofBirth= driver.findElement(By.xpath(minor_indian.Weight_timeofBirth));
									cell = sheet.getRow(6).getCell(202);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String WeightatTimeofBirth = cell.getStringCellValue();
								       System.out.println( WeightatTimeofBirth );	
								       Weight_timeofBirth.sendKeys( WeightatTimeofBirth );
							      Extent_Reporting.Log_Pass("Entering Weight at the Time of Birth","Entered Weight at the Time of Birth" + WeightatTimeofBirth ); 

							    //Family Medical History
							      
							      Thread.sleep(1000);
							      Family_Hist_addbutton =driver.findElement(By.xpath(minor_indian.Family_History_addbutton));
							      Family_Hist_addbutton.click();
							      
							      //diagonsed with disease
							      
							      Thread.sleep(1000);  
								  DiagonsedWithDiseases_chkbox = driver.findElement(By.xpath(minor_indian.None_button));
								  DiagonsedWithDiseases_chkbox.click();		
								  System.out.println("DiagnosedwithDisease");	
								 Extent_Reporting.Log_Pass("Entering Diagnose with Disease","Entered diagnosed with Disease as none"); 
								   
								//insurability declaration
							      
							      Thread.sleep(1000);
							      insurability_dec_addbutton =driver.findElement(By.xpath(minor_indian.insurability_button));
							      insurability_dec_addbutton.click();	 
								 
							    //avail medical service
							      Thread.sleep(1000);
							      avail_med_ser_button =driver.findElement(By.xpath(minor_indian.availed_medical_service_no));
							      avail_med_ser_button.click();
							      
							     //diagnose disease
							      Thread.sleep(1000);
							      diagnose_disease_button =driver.findElement(By.xpath(minor_indian.diagnose_with_disease_no));
							      diagnose_disease_button.click();
							      
							      //diagnose asthma
							      Thread.sleep(1000);
							      diagnose_asthma_button =driver.findElement(By.xpath(minor_indian.diagnose_asthma_no));
							      diagnose_asthma_button.click();
							      
							      //consult doctor
							      Thread.sleep(1000);
							      consult_doctor_button =driver.findElement(By.xpath(minor_indian.consult_doctor_no));
							      consult_doctor_button.click();
							      
							      
							      
							      //I agree button

							  					      JavascriptExecutor jse1 = (JavascriptExecutor)driver;
							  					   	jse1.executeScript("window.scrollBy(0,250)", "");
							  					   	Thread.sleep(1000);
							  					   	healthDetails_Agreebutton = driver.findElement(By.xpath(minor_indian.agree_insurer_health));
							  					   	healthDetails_Agreebutton.click();

							  					   	}
							  					   	catch(Exception e)
							  					   	{
							  					   		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							  					   		e.printStackTrace();
							  					   	}   		  
				}
					
					
					@SuppressWarnings("deprecation")
					public void IARTab_Insurer_minorIndian(WebDriver driver) throws IOException, InterruptedException {
						try {
							Thread.sleep(1000);
							
						//middle name insurer 	
							Thread.sleep(1000);
							Insurer_IAR_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.middleName));
							cell = sheet.getRow(6).getCell(211);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String InsurerIARMiddleName = cell.getStringCellValue();
						       System.out.println(InsurerIARMiddleName);	
						       Insurer_IAR_MiddleName.sendKeys(InsurerIARMiddleName);
					       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name" +InsurerIARMiddleName);
					       
					       //non medical
					       Thread.sleep(1000);
							Insurer_IAR_NonMedical = driver.findElement(By.xpath(EApp_LandingPage.nonMedical));
							Insurer_IAR_NonMedical.click();
							   System.out.println(Insurer_IAR_NonMedical);	
						      
					     Extent_Reporting.Log_Pass("Entering Insurer's Non Medical Value","Entered Insurer's Non Medical submitted successfully");
					       
					     
					     // age proof
					     
					     Insurer_AgeProof = driver.findElement(By.xpath(EApp_LandingPage.ageProof_Dropdown));
					      cell = sheet.getRow(6).getCell(214);
					      cell.setCellType(Cell.CELL_TYPE_STRING);
					      String AgeProof = cell.getStringCellValue();
					      System.out.println(AgeProof); 
					      Select AgeProof1 = new Select(Insurer_AgeProof);
					      AgeProof1.selectByValue("Passport");
					         Extent_Reporting.Log_Pass("Entering Age Proof ","Entered Age Proof is as "+AgeProof); 
				     
					     //personally met
					         Insurer_IAR_personallyMet = driver.findElement(By.xpath(minor_indian.Toggle_IAR_Yes));
					         Insurer_IAR_personallyMet.click();
								   System.out.println(Insurer_IAR_personallyMet);	
							      
						     Extent_Reporting.Log_Pass("Entering Insurer personally met for application","Entered Insurer personally met for application submitted successfully");
						       
					//reference 
						     Insurer_IAR_reference = driver.findElement(By.xpath(EApp_LandingPage.applicant_Request));
						     Insurer_IAR_reference.click();
						     System.out.println("Insurer_IAR_Reference");
						     Extent_Reporting.Log_Pass("Entering Insurer Referrence","Entered Insurer Reference" );
						     
						 //cluster market
						     Thread.sleep(1000);
								Insurer_IAR_ClusterMarket = driver.findElement(By.xpath(EApp_LandingPage.clusterName));
								cell = sheet.getRow(6).getCell(217);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String InsurerIARClusterMarket = cell.getStringCellValue();
							       System.out.println(InsurerIARClusterMarket);	
							       Insurer_IAR_ClusterMarket.sendKeys(InsurerIARClusterMarket);
						       Extent_Reporting.Log_Pass("Entering Cluster Market","Entered Cluster Market" +InsurerIARClusterMarket);
						     
						       JavascriptExecutor jse = (JavascriptExecutor)driver;
								   	jse.executeScript("window.scrollBy(0,250)", "");
								   	Thread.sleep(1000);
								       
						  
								   	
						//known insurer in years
								    Thread.sleep(1000);
									Insurer_IAR_durationinYears = driver.findElement(By.xpath(EApp_LandingPage.years));
									cell = sheet.getRow(6).getCell(218);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String InsurerIARdurationyears = cell.getStringCellValue();
								       System.out.println(InsurerIARdurationyears);	
								       Insurer_IAR_durationinYears.sendKeys(InsurerIARdurationyears);
							       Extent_Reporting.Log_Pass("Entering duration of Knowing Insurer in Years","Entered duration of knowing Insurer in Years " +InsurerIARdurationyears);
							     
								   
							  //Known insurer in months      
							       Thread.sleep(1000);
									Insurer_IAR_durationinMonths = driver.findElement(By.xpath(EApp_LandingPage.months));
									cell = sheet.getRow(6).getCell(219);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String InsurerIARdurationmonths = cell.getStringCellValue();
								       System.out.println(InsurerIARdurationmonths);	
								       Insurer_IAR_durationinMonths.sendKeys(InsurerIARdurationmonths);
							       Extent_Reporting.Log_Pass("Entering duration of Knowing Insurer in Months","Entered duration of knowing Insurer in Months " +InsurerIARdurationmonths);
							        	
						     // Product offer
							       Insurer_IAR_productoffer = driver.findElement(By.xpath(EApp_LandingPage.protection));
							       Insurer_IAR_productoffer.click();
								     System.out.println("Insurer_IAR_productoffer");
								     Extent_Reporting.Log_Pass("Entering product offers to Insurer ","Entered product offers to Insurer" +Insurer_IAR_productoffer);
								
							//amount calculation process
								     Thread.sleep(1000);
										Insurer_IAR_Amountcalculation = driver.findElement(By.xpath(EApp_LandingPage.howCalculate));
										cell = sheet.getRow(6).getCell(221);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String InsurerIARAmountCalculation = cell.getStringCellValue();
									       System.out.println(InsurerIARAmountCalculation);	
									       Insurer_IAR_Amountcalculation.sendKeys(InsurerIARAmountCalculation);
								       Extent_Reporting.Log_Pass("Entering calculation process of Amount","Entered calculation process of Amount " +InsurerIARAmountCalculation);
								        	    
							//financial details
								   //Realistic estimate proposer
								       
								       Thread.sleep(1000);
										IAR_EstimateProposer = driver.findElement(By.xpath(minor_indian.realistic_Estimate_Proposer));
										cell = sheet.getRow(6).getCell(223);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IAREstimateProposer = cell.getStringCellValue();
									       System.out.println(IAREstimateProposer);	
									       IAR_EstimateProposer.sendKeys(IAREstimateProposer);
								       Extent_Reporting.Log_Pass("Entering Realistic Estimate for Proposer","Entered Realistic Estimate for Proposer " +IAREstimateProposer);
								        	    
								    //Realistic estimate insurer   
								       
								       Thread.sleep(1000);
								       IAR_EstimateInsurer = driver.findElement(By.xpath(minor_indian.realistic_Estimate_Insurer));
										cell = sheet.getRow(6).getCell(224);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IAREstimateInsurer = cell.getStringCellValue();
									       System.out.println(IAREstimateInsurer);	
									       IAR_EstimateInsurer.sendKeys(IAREstimateInsurer);
								       Extent_Reporting.Log_Pass("Entering Realistic Estimate for Insurer","Entered Realistic Estimate for Insurer " +IAREstimateInsurer);
								        	    
								  //Investments proposer
								       Thread.sleep(1000);
										IAR_investment_Proposer = driver.findElement(By.xpath(minor_indian.Investment_Proposer));
										cell = sheet.getRow(6).getCell(226);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IARInvestmentProposer = cell.getStringCellValue();
									       System.out.println(IARInvestmentProposer);	
									       IAR_investment_Proposer.sendKeys(IARInvestmentProposer);
								       Extent_Reporting.Log_Pass("Entering Investment of Proposer","Entered Investment of Proposer" +IARInvestmentProposer);
								        	    
								       //Investment insurer
								       Thread.sleep(1000);
								       IAR_investment_Insurer= driver.findElement(By.xpath(minor_indian.Investment_Insurer));
										cell = sheet.getRow(6).getCell(227);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IARInvestmentInsurer = cell.getStringCellValue();
									       System.out.println(IARInvestmentInsurer);	
									       IAR_investment_Insurer.sendKeys(IARInvestmentInsurer);
								       Extent_Reporting.Log_Pass("Entering Insurer's Investments","Entered Insurer's Investments	 " +IARInvestmentInsurer);
								        	  
								       //Liabilities proposer
								       Thread.sleep(1000);
										IAR_liabilities_Proposer = driver.findElement(By.xpath(minor_indian.liabilities_Proposer));
										cell = sheet.getRow(6).getCell(229);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IARLiabilitiesProposer = cell.getStringCellValue();
									       System.out.println(IARLiabilitiesProposer);	
									       IAR_liabilities_Proposer.sendKeys(IARLiabilitiesProposer);
								       Extent_Reporting.Log_Pass("Entering Liabilities of Proposer","Entered Liabilities of Proposer" +IARLiabilitiesProposer);
								        	    
								       
								       //Liabilities insurer
								       Thread.sleep(1000);
								       IAR_liabilities_Insurer = driver.findElement(By.xpath(EApp_LandingPage.howCalculate));
										cell = sheet.getRow(6).getCell(230);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String IARLiabilitiesInsurer = cell.getStringCellValue();
									       System.out.println(IARLiabilitiesInsurer);	
									       IAR_liabilities_Insurer.sendKeys(IARLiabilitiesInsurer);
								       Extent_Reporting.Log_Pass("Entering Insurer's Liabilities ","Entered Insurer's Liabilities " +IARLiabilitiesInsurer);
								        	    
								//Questions
								       
								       IAR_physicalDefects = driver.findElement(By.xpath(minor_indian.Toggle2_IAR_No));
								       IAR_physicalDefects.click();
									     System.out.println("IAR_physicalDefects");
									     Extent_Reporting.Log_Pass("Entering Insurer's Physical Defects Information ","Entered Insurer's Physical Defects Information" +IAR_physicalDefects);
									       
								       
									     IAR_adverseeffects = driver.findElement(By.xpath(minor_indian.Toggle3_IAR_No));
									     IAR_adverseeffects.click();
										     System.out.println("IAR_adverseeffects");
										     Extent_Reporting.Log_Pass("Entering Insurer's adverse Effect Information ","Entered Insurer's adverse Effect Information" +IAR_adverseeffects);
										          
										     IAR_Declined_postponed_application = driver.findElement(By.xpath(minor_indian.Toggle4_IAR_No));
										     IAR_Declined_postponed_application .click();
											     System.out.println("IAR_Declined_postponed_application ");
											     Extent_Reporting.Log_Pass("Entering Insurer's Declined/postponed application Information ","Entered Insurer's Declined/postponed application Information" +IAR_Declined_postponed_application );
											       
											     IAR_FinancialStability = driver.findElement(By.xpath(minor_indian.Toggle5_IAR_Yes));
											     IAR_FinancialStability.click();
												     System.out.println("IAR_FinancialStability");
												     Extent_Reporting.Log_Pass("Entering Insurer's Financial stability Information ","Entered Insurer's Financial stability Information" +IAR_FinancialStability);
												       
								       
												     IAR_suspiciousactivity_Report= driver.findElement(By.xpath(minor_indian.Toggle6_IAR_No));
												     IAR_suspiciousactivity_Report.click();
													     System.out.println(" IAR_suspiciousactivity_Report");
													     Extent_Reporting.Log_Pass("Entering Insurer's Suspicious activity Information ","Entered Insurer's  Suspicious activity  Information" + IAR_suspiciousactivity_Report);
													       
								       //Remarks
										 Thread.sleep(1000);
									 IAR_other_Remarks = driver.findElement(By.xpath(EApp_LandingPage.otherRemarks));
										cell = sheet.getRow(6).getCell(236);
										cell.setCellType(Cell.CELL_TYPE_STRING);
								       String IAROtherRemarks = cell.getStringCellValue();
								      System.out.println(IAROtherRemarks);	
								      IAR_other_Remarks.sendKeys(IAROtherRemarks);
						       Extent_Reporting.Log_Pass("Entering Other Remarks ","Entered Other Remarks " +IAROtherRemarks);
													        	       
								       
								//I agree button       
								       
						       JavascriptExecutor jse1 = (JavascriptExecutor)driver;
								   	jse1.executeScript("window.scrollBy(0,250)", "");
								   	Thread.sleep(1000);
								   	IAR_IAgreebutton = driver.findElement(By.xpath(EApp_LandingPage.IAR_IAgree));
									IAR_IAgreebutton.click();

								   	}
								   	catch(Exception e)
								   	{
								   		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
								   		e.printStackTrace();
								   	}   		  
				}			       
								       

				
				
				
		
//Same
				@SuppressWarnings("deprecation")
				public void Basic_Details_To_Be_Insured_Same(WebDriver driver) throws IOException, InterruptedException {
					try {
						Thread.sleep(1000);
						System.out.println("Eapp Policy Tab");
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(1);
						
						       //Toggle - Existing BSLI policy
						       Thread.sleep(1000);
						       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
						       Existing_BSLI_Policy_Toggle_No.click();
						       System.out.println("clickcing_Existing_BSLI_Policy_Toggle_No");
						       	
						       Thread.sleep(1000);
								System.out.println("Toggle");

						       
							Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Insurer_UID));
							cell = sheet.getRow(6).getCell(57);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String AadharUID = cell.getStringCellValue();
						       System.out.println(AadharUID);	
						       Aadhar_UID.sendKeys(AadharUID);
						
							Thread.sleep(1000);
							Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
							Personal_Details.click();
							
							//Personal Details
							Thread.sleep(1000);
							Insurer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
							cell = sheet.getRow(6).getCell(59);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String InsurerMiddleName = cell.getStringCellValue();
						       System.out.println(InsurerMiddleName);	
						       Insurer_MiddleName.sendKeys(InsurerMiddleName);
					       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name");
					       
					       Thread.sleep(1000);
							Marital_Status = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MaritalStatus));
							cell = sheet.getRow(6).getCell(60);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String MaritalStatus = cell.getStringCellValue();
						       System.out.println(MaritalStatus);	
						       Select Marital_Status_Dropdown = new Select(Marital_Status);
						       Marital_Status_Dropdown.selectByValue("M");
					       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
					      
					       Thread.sleep(1000);
							Father_Spouse_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
							cell = sheet.getRow(6).getCell(61);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FatherSpouse_Name = cell.getStringCellValue();
						       System.out.println(FatherSpouse_Name);	
						       Father_Spouse_Name.sendKeys(FatherSpouse_Name);
						       Extent_Reporting.Log_Pass("Entering Father/Spouse Name ","Entered Father/Spouse Name as "+FatherSpouse_Name);
								Thread.sleep(1000);

						     //Scroll
								JavascriptExecutor jse8 = (JavascriptExecutor)driver;
								jse8.executeScript("window.scrollBy(0,50)", "");
								Thread.sleep(1000);
						       
						       Thread.sleep(1000);
								Place_Of_Birth_State = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
								cell = sheet.getRow(6).getCell(62);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String Place_OfBirth_State = cell.getStringCellValue();
							       System.out.println(Place_OfBirth_State);	
							       Place_Of_Birth_State.sendKeys(Place_OfBirth_State);
							       Thread.sleep(1000);
							       Place_Of_Birth_State2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
							       Place_Of_Birth_State2.click();
					       Extent_Reporting.Log_Pass("Entering Place of Birth (State) ","Entered Place of Birth (State) as "+Place_OfBirth_State);
					      
					       Thread.sleep(1000);
							Place_Of_Birth_City = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthCity));
							cell = sheet.getRow(6).getCell(63);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String Place_OfBirth_City = cell.getStringCellValue();
						       System.out.println(Place_OfBirth_City);	
						       Place_Of_Birth_City.sendKeys(Place_OfBirth_City);
				       Extent_Reporting.Log_Pass("Entering Place of Birth (City) ","Entered Place of Birth (City) as "+Place_OfBirth_City);
				      
				       Citizenship_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Citizenship_NO));
				       Citizenship_Toggle_No.click();
				       Thread.sleep(1000);

			       Tax_Resident_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tax_Resident_NO));
			       Tax_Resident_Toggle_No.click();
			       Thread.sleep(1000);
		      
		      //Professional Details
			       Proffesional_Details = driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
			       Proffesional_Details.click();
			       Thread.sleep(1000);
			       
			       Qualification = driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
			       cell = sheet.getRow(6).getCell(67);
			       cell.setCellType(Cell.CELL_TYPE_STRING);
			       String qualification = cell.getStringCellValue();
			       System.out.println(qualification);	
			       Select qualification_ins = new Select(Qualification);
			       qualification_ins.selectByValue("G");
		       Extent_Reporting.Log_Pass("Selecting Qualification","Selected Qualification as Graduate");
		      
		       Occupation = driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
		       cell = sheet.getRow(6).getCell(69);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String occupation = cell.getStringCellValue();
		       System.out.println(occupation);	
		       Select occupation_ins = new Select(Occupation);
		       occupation_ins.selectByValue("97");
		       Extent_Reporting.Log_Pass("Selecting Occupation","Selected Occupation as Service");
		   		Thread.sleep(2000);
		  
		  	Proposer_Employer = driver.findElement(By.xpath(EApp_LandingPage.SerEmployerName));
			cell = sheet.getRow(6).getCell(71);
		     cell.setCellType(Cell.CELL_TYPE_STRING);
		     String ProposerEmployer = cell.getStringCellValue();
		     System.out.println(ProposerEmployer);	
		     Proposer_Employer.sendKeys(ProposerEmployer);
			Extent_Reporting.Log_Pass("Entering Name of Employer ","Entered Name of Employer as "+ProposerEmployer);
			
			Proposer_Designation = driver.findElement(By.xpath(EApp_LandingPage.designation));
			cell = sheet.getRow(6).getCell(72);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerDesignation = cell.getStringCellValue();
			 System.out.println(ProposerDesignation);	
			 Proposer_Designation.sendKeys(ProposerDesignation);
			Extent_Reporting.Log_Pass("Entering Designation ","Entered Designation as "+ProposerDesignation);
			
			Proposer_TypeOfOrganization = driver.findElement(By.xpath(EApp_LandingPage.SerOrganizationType));
			cell = sheet.getRow(6).getCell(73);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerTypeOfOrganization = cell.getStringCellValue();
			 System.out.println(ProposerTypeOfOrganization);	
			 Select TypeOfOrganization = new Select(Proposer_TypeOfOrganization);
			 TypeOfOrganization.selectByValue("H");	
		     Extent_Reporting.Log_Pass("Entering Type Of Organization ","Entered Type Of Organization as "+ProposerTypeOfOrganization);
			
			Proposer_NatureOfDuties = driver.findElement(By.xpath(EApp_LandingPage.SerNatureOfDuty));
			cell = sheet.getRow(6).getCell(74);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerNatureOfDuties = cell.getStringCellValue();
			 System.out.println(ProposerNatureOfDuties);	
			 Proposer_NatureOfDuties.sendKeys(ProposerNatureOfDuties);
			Extent_Reporting.Log_Pass("Entering Nature Of Duties ","Entered Nature Of Duties as "+ProposerNatureOfDuties);
			
			Proposer_YearsWithEmployer = driver.findElement(By.xpath(EApp_LandingPage.SerExperience));
			cell = sheet.getRow(6).getCell(75);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerYearsWithEmployer = cell.getStringCellValue();
			 System.out.println(ProposerYearsWithEmployer);	
			 Proposer_YearsWithEmployer.sendKeys(ProposerYearsWithEmployer);
			Extent_Reporting.Log_Pass("Entering Years With Employer ","Entered Years With Employer as "+ProposerYearsWithEmployer);
			
			Proposer_AnnualIncome = driver.findElement(By.xpath(EApp_LandingPage.SerAnnualIncome));
			cell = sheet.getRow(6).getCell(86);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerAnnualIncome = cell.getStringCellValue();
			 System.out.println(ProposerAnnualIncome);	
			 Proposer_AnnualIncome.sendKeys(ProposerAnnualIncome);
			Extent_Reporting.Log_Pass("Entering Annual Income ","Entered Annual Income as "+ProposerAnnualIncome);
			
			Proposer_PAN = driver.findElement(By.xpath(EApp_LandingPage.pan));
			cell = sheet.getRow(6).getCell(87);
			 cell.setCellType(Cell.CELL_TYPE_STRING);
			 String ProposerPAN = cell.getStringCellValue();
			 System.out.println(ProposerPAN);	
			 Proposer_PAN.sendKeys(ProposerPAN);
			Extent_Reporting.Log_Pass("Entering PAN ","Entered PAN as "+ProposerPAN);
			
			Validate_PAN = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
			Validate_PAN.click();
			Thread.sleep(1000);
			
			//Scroll
			JavascriptExecutor jse2 = (JavascriptExecutor)driver;
			jse2.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(1000);

		//Communication details
			Communication_Details = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
			Communication_Details.click();
		    Thread.sleep(1000);
		    
		  //Scroll
		  	JavascriptExecutor jse9 = (JavascriptExecutor)driver;
		  	jse9.executeScript("window.scrollBy(0,-150)", "");
		  	Thread.sleep(1000);
		  	
			Address1_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address1));
			cell = sheet.getRow(6).getCell(115);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String Address1Ins = cell.getStringCellValue();
			System.out.println(Address1Ins);	
			Address1_Ins.sendKeys(Address1Ins);
			Extent_Reporting.Log_Pass("Entering Address1 ","Entered Address1 as "+Address1Ins);
			
			Address3_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address3));
			cell = sheet.getRow(6).getCell(117);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String Address3Ins = cell.getStringCellValue();
			System.out.println(Address3Ins);	
			Address3_Ins.sendKeys(Address3Ins);
			Extent_Reporting.Log_Pass("Entering Address3 ","Entered Address3 as "+Address3Ins);

				
			Area_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Area));
			cell = sheet.getRow(6).getCell(118);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String AreaIns = cell.getStringCellValue();
			System.out.println(AreaIns);	
			Area_Ins.sendKeys(AreaIns);
			Extent_Reporting.Log_Pass("Entering Area ","Entered Area as "+AreaIns);


			City_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_city));
			cell = sheet.getRow(6).getCell(119);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String CityIns = cell.getStringCellValue();
			System.out.println(CityIns);	
			City_Ins.sendKeys(CityIns);
			Extent_Reporting.Log_Pass("Entering City ","Entered City as "+CityIns);
/*
			State_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_State));
			String StateIns = "MAHARASHTRA";
			System.out.println(StateIns);	
			State_Ins.sendKeys(StateIns);
			Thread.sleep(1000);
			StateIns2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
			StateIns2.click();
			Extent_Reporting.Log_Pass("Entering State ","Entered State as "+StateIns);
*/
			PIN_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Pin));
			cell = sheet.getRow(6).getCell(120);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String PINIns = cell.getStringCellValue();
			System.out.println(PINIns);	
			PIN_Ins.sendKeys(PINIns);
			Extent_Reporting.Log_Pass("Entering PIN ","Entered PIN as "+PINIns);

			Tel_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tel_Number));
			cell = sheet.getRow(6).getCell(121);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String TelNo_Ins = cell.getStringCellValue();
			System.out.println(TelNo_Ins);	
			Tel_No_Ins.sendKeys(TelNo_Ins);
			Extent_Reporting.Log_Pass("Entering Tel No ","Entered Tel No as "+TelNo_Ins);

			Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_mobile_Number));
			cell = sheet.getRow(6).getCell(122);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String MobileNo_Ins = cell.getStringCellValue();
			System.out.println(MobileNo_Ins);	
			Mobile_No_Ins.sendKeys(MobileNo_Ins);
			Extent_Reporting.Log_Pass("Entering Mobile No ","Entered Mobile No as "+MobileNo_Ins);

			// Scroll Up 
			JavascriptExecutor jse4 = (JavascriptExecutor)driver;
			jse4.executeScript("window.scrollBy(0,150)", "");
			Thread.sleep(1000);
			 
			Alt_Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Alternate_Number));
			cell = sheet.getRow(6).getCell(123);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String AltMobile_No_Ins = cell.getStringCellValue();
			System.out.println(AltMobile_No_Ins);	
			Alt_Mobile_No_Ins.sendKeys(AltMobile_No_Ins);
			Extent_Reporting.Log_Pass("Entering Alternate Mobile No ","Entered Alternate Mobile No as "+AltMobile_No_Ins);

			Email_Ins = driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
			cell = sheet.getRow(6).getCell(124);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String EmailIns = cell.getStringCellValue();
			System.out.println(EmailIns);	
			Email_Ins.sendKeys(EmailIns);
			Extent_Reporting.Log_Pass("Entering Email Address ","Entered Email Address as "+EmailIns);

			Email_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
			Email_Toogle.click();
			Thread.sleep(1000);
			
			//Scroll
				JavascriptExecutor jse3 = (JavascriptExecutor)driver;
				jse3.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(1000);

				//EIA Details
				EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
				EIA_Details.click();
				Thread.sleep(1000);
				
				EIA_NO = driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
				EIA_NO.click();
				Thread.sleep(1000);
				
				//Other Details
				
				Other_Details = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Other_Details));
				Other_Details.click();
				Thread.sleep(1000);
				
				PEP_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
				PEP_Toogle.click();
				Thread.sleep(1000);

				Risk = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
				Risk.click();
				Thread.sleep(1000);
				
				IAgree = driver.findElement(By.xpath(EApp_LandingPage.Basic_Details_Agree));
				IAgree.click();
				Thread.sleep(1000);
			
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
		
				
				//To be Insured Same ULIP
						@SuppressWarnings("deprecation")
						public void Basic_Details_To_Be_Insured_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
							try {
								Thread.sleep(1000);
								System.out.println("Eapp Policy Tab");
								FileInputStream finput = new FileInputStream(src);
								  workbook = new XSSFWorkbook(finput);
								  sheet= workbook.getSheetAt(2);
								
								       //Toggle - Existing BSLI policy
								       Thread.sleep(1000);
								       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
								       Existing_BSLI_Policy_Toggle_No.click();
								       System.out.println("clickcing_Existing_BSLI_Policy_Toggle_No");
								       	
								       Thread.sleep(1000);
										System.out.println("Toggle");

								       
									Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Insurer_UID));
									cell = sheet.getRow(6).getCell(54);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String AadharUID = cell.getStringCellValue();
								       System.out.println(AadharUID);	
								       Aadhar_UID.sendKeys(AadharUID);
								
									Thread.sleep(1000);
									Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
									Personal_Details.click();
									
									//Personal Details
									Thread.sleep(1000);
									Insurer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
									cell = sheet.getRow(6).getCell(56);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String InsurerMiddleName = cell.getStringCellValue();
								       System.out.println(InsurerMiddleName);	
								       Insurer_MiddleName.sendKeys(InsurerMiddleName);
							       Extent_Reporting.Log_Pass("Entering Insurer's Middle Name","Entered Insurer's Middle Name");
							       
							       Thread.sleep(1000);
									Marital_Status = driver.findElement(By.xpath(EApp_LandingPage.Insurer_MaritalStatus));
									cell = sheet.getRow(6).getCell(57);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MaritalStatus = cell.getStringCellValue();
								       System.out.println(MaritalStatus);	
								       Select Marital_Status_Dropdown = new Select(Marital_Status);
								       Marital_Status_Dropdown.selectByValue("M");
							       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
							      
							       Thread.sleep(1000);
									Father_Spouse_Name = driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
									cell = sheet.getRow(6).getCell(58);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String FatherSpouse_Name = cell.getStringCellValue();
								       System.out.println(FatherSpouse_Name);	
								       Father_Spouse_Name.sendKeys(FatherSpouse_Name);
								       Extent_Reporting.Log_Pass("Entering Father/Spouse Name ","Entered Father/Spouse Name as "+FatherSpouse_Name);
										Thread.sleep(1000);

								     //Scroll
										JavascriptExecutor jse8 = (JavascriptExecutor)driver;
										jse8.executeScript("window.scrollBy(0,50)", "");
										Thread.sleep(1000);
								       
								       Thread.sleep(1000);
										Place_Of_Birth_State = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
										cell = sheet.getRow(6).getCell(59);
									       cell.setCellType(Cell.CELL_TYPE_STRING);
									       String Place_OfBirth_State = cell.getStringCellValue();
									       System.out.println(Place_OfBirth_State);	
									       Place_Of_Birth_State.sendKeys(Place_OfBirth_State);
									       Thread.sleep(1000);
									       Place_Of_Birth_State2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
									       Place_Of_Birth_State2.click();
							       Extent_Reporting.Log_Pass("Entering Place of Birth (State) ","Entered Place of Birth (State) as "+Place_OfBirth_State);
							      
							       Thread.sleep(1000);
									Place_Of_Birth_City = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthCity));
									cell = sheet.getRow(6).getCell(60);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String Place_OfBirth_City = cell.getStringCellValue();
								       System.out.println(Place_OfBirth_City);	
								       Place_Of_Birth_City.sendKeys(Place_OfBirth_City);
						       Extent_Reporting.Log_Pass("Entering Place of Birth (City) ","Entered Place of Birth (City) as "+Place_OfBirth_City);
						      
						       Citizenship_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Citizenship_NO));
						       Citizenship_Toggle_No.click();
						       Thread.sleep(1000);

					       Tax_Resident_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tax_Resident_NO));
					       Tax_Resident_Toggle_No.click();
					       Thread.sleep(1000);
				      
				      //Professional Details
					       Proffesional_Details = driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
					       Proffesional_Details.click();
					       Thread.sleep(1000);
					       
					       Qualification = driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
					       cell = sheet.getRow(6).getCell(64);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String qualification = cell.getStringCellValue();
					       System.out.println(qualification);	
					       Select qualification_ins = new Select(Qualification);
					       qualification_ins.selectByValue("G");
				       Extent_Reporting.Log_Pass("Selecting Qualification","Selected Qualification as Graduate");
				      
				       Occupation = driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
				       cell = sheet.getRow(6).getCell(66);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String occupation = cell.getStringCellValue();
				       System.out.println(occupation);	
				       Select occupation_ins = new Select(Occupation);
				       occupation_ins.selectByValue("97");
				       Extent_Reporting.Log_Pass("Selecting Occupation","Selected Occupation as Service");
				   		Thread.sleep(2000);
				  
				  	Proposer_Employer = driver.findElement(By.xpath(EApp_LandingPage.SerEmployerName));
					cell = sheet.getRow(6).getCell(68);
				     cell.setCellType(Cell.CELL_TYPE_STRING);
				     String ProposerEmployer = cell.getStringCellValue();
				     System.out.println(ProposerEmployer);	
				     Proposer_Employer.sendKeys(ProposerEmployer);
					Extent_Reporting.Log_Pass("Entering Name of Employer ","Entered Name of Employer as "+ProposerEmployer);
					
					Proposer_Designation = driver.findElement(By.xpath(EApp_LandingPage.designation));
					cell = sheet.getRow(6).getCell(69);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerDesignation = cell.getStringCellValue();
					 System.out.println(ProposerDesignation);	
					 Proposer_Designation.sendKeys(ProposerDesignation);
					Extent_Reporting.Log_Pass("Entering Designation ","Entered Designation as "+ProposerDesignation);
					
					Proposer_TypeOfOrganization = driver.findElement(By.xpath(EApp_LandingPage.SerOrganizationType));
					cell = sheet.getRow(6).getCell(70);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerTypeOfOrganization = cell.getStringCellValue();
					 System.out.println(ProposerTypeOfOrganization);	
					 Select TypeOfOrganization = new Select(Proposer_TypeOfOrganization);
					 TypeOfOrganization.selectByValue("H");	
				     Extent_Reporting.Log_Pass("Entering Type Of Organization ","Entered Type Of Organization as "+ProposerTypeOfOrganization);
					
					Proposer_NatureOfDuties = driver.findElement(By.xpath(EApp_LandingPage.SerNatureOfDuty));
					cell = sheet.getRow(6).getCell(71);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerNatureOfDuties = cell.getStringCellValue();
					 System.out.println(ProposerNatureOfDuties);	
					 Proposer_NatureOfDuties.sendKeys(ProposerNatureOfDuties);
					Extent_Reporting.Log_Pass("Entering Nature Of Duties ","Entered Nature Of Duties as "+ProposerNatureOfDuties);
					
					Proposer_YearsWithEmployer = driver.findElement(By.xpath(EApp_LandingPage.SerExperience));
					cell = sheet.getRow(6).getCell(72);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerYearsWithEmployer = cell.getStringCellValue();
					 System.out.println(ProposerYearsWithEmployer);	
					 Proposer_YearsWithEmployer.sendKeys(ProposerYearsWithEmployer);
					Extent_Reporting.Log_Pass("Entering Years With Employer ","Entered Years With Employer as "+ProposerYearsWithEmployer);
					
					Proposer_AnnualIncome = driver.findElement(By.xpath(EApp_LandingPage.SerAnnualIncome));
					cell = sheet.getRow(6).getCell(83);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerAnnualIncome = cell.getStringCellValue();
					 System.out.println(ProposerAnnualIncome);	
					 Proposer_AnnualIncome.sendKeys(ProposerAnnualIncome);
					Extent_Reporting.Log_Pass("Entering Annual Income ","Entered Annual Income as "+ProposerAnnualIncome);
					
					Proposer_PAN = driver.findElement(By.xpath(EApp_LandingPage.pan));
					cell = sheet.getRow(6).getCell(84);
					 cell.setCellType(Cell.CELL_TYPE_STRING);
					 String ProposerPAN = cell.getStringCellValue();
					 System.out.println(ProposerPAN);	
					 Proposer_PAN.sendKeys(ProposerPAN);
					Extent_Reporting.Log_Pass("Entering PAN ","Entered PAN as "+ProposerPAN);
					
					Validate_PAN = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
					Validate_PAN.click();
					Thread.sleep(1000);
					
					//Scroll
					JavascriptExecutor jse2 = (JavascriptExecutor)driver;
					jse2.executeScript("window.scrollBy(0,250)", "");
					Thread.sleep(1000);

				//Communication details
					Communication_Details = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
					Communication_Details.click();
				    Thread.sleep(1000);
				    
				  //Scroll
				  	JavascriptExecutor jse9 = (JavascriptExecutor)driver;
				  	jse9.executeScript("window.scrollBy(0,-150)", "");
				  	Thread.sleep(1000);
				  	
					Address1_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address1));
					cell = sheet.getRow(6).getCell(112);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String Address1Ins = cell.getStringCellValue();
					System.out.println(Address1Ins);	
					Address1_Ins.sendKeys(Address1Ins);
					Extent_Reporting.Log_Pass("Entering Address1 ","Entered Address1 as "+Address1Ins);
					
					Address3_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Address3));
					cell = sheet.getRow(6).getCell(114);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String Address3Ins = cell.getStringCellValue();
					System.out.println(Address3Ins);	
					Address3_Ins.sendKeys(Address3Ins);
					Extent_Reporting.Log_Pass("Entering Address3 ","Entered Address3 as "+Address3Ins);

						
					Area_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Area));
					cell = sheet.getRow(6).getCell(115);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AreaIns = cell.getStringCellValue();
					System.out.println(AreaIns);	
					Area_Ins.sendKeys(AreaIns);
					Extent_Reporting.Log_Pass("Entering Area ","Entered Area as "+AreaIns);


					City_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_city));
					cell = sheet.getRow(6).getCell(116);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String CityIns = cell.getStringCellValue();
					System.out.println(CityIns);	
					City_Ins.sendKeys(CityIns);
					Extent_Reporting.Log_Pass("Entering City ","Entered City as "+CityIns);
		/*
					State_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_State));
					String StateIns = "MAHARASHTRA";
					System.out.println(StateIns);	
					State_Ins.sendKeys(StateIns);
					Thread.sleep(1000);
					StateIns2 = driver.findElement(By.xpath("//li[text()='MAHARASHTRA']"));
					StateIns2.click();
					Extent_Reporting.Log_Pass("Entering State ","Entered State as "+StateIns);
		*/
					PIN_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Pin));
					cell = sheet.getRow(6).getCell(117);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String PINIns = cell.getStringCellValue();
					System.out.println(PINIns);	
					PIN_Ins.sendKeys(PINIns);
					Extent_Reporting.Log_Pass("Entering PIN ","Entered PIN as "+PINIns);

					Tel_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Tel_Number));
					cell = sheet.getRow(6).getCell(118);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String TelNo_Ins = cell.getStringCellValue();
					System.out.println(TelNo_Ins);	
					Tel_No_Ins.sendKeys(TelNo_Ins);
					Extent_Reporting.Log_Pass("Entering Tel No ","Entered Tel No as "+TelNo_Ins);

					Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_mobile_Number));
					cell = sheet.getRow(6).getCell(119);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String MobileNo_Ins = cell.getStringCellValue();
					System.out.println(MobileNo_Ins);	
					Mobile_No_Ins.sendKeys(MobileNo_Ins);
					Extent_Reporting.Log_Pass("Entering Mobile No ","Entered Mobile No as "+MobileNo_Ins);

					// Scroll Up 
					JavascriptExecutor jse4 = (JavascriptExecutor)driver;
					jse4.executeScript("window.scrollBy(0,150)", "");
					Thread.sleep(1000);
					 
					Alt_Mobile_No_Ins = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Alternate_Number));
					cell = sheet.getRow(6).getCell(120);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AltMobile_No_Ins = cell.getStringCellValue();
					System.out.println(AltMobile_No_Ins);	
					Alt_Mobile_No_Ins.sendKeys(AltMobile_No_Ins);
					Extent_Reporting.Log_Pass("Entering Alternate Mobile No ","Entered Alternate Mobile No as "+AltMobile_No_Ins);

					Email_Ins = driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
					cell = sheet.getRow(6).getCell(121);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String EmailIns = cell.getStringCellValue();
					System.out.println(EmailIns);	
					Email_Ins.sendKeys(EmailIns);
					Extent_Reporting.Log_Pass("Entering Email Address ","Entered Email Address as "+EmailIns);

					Email_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
					Email_Toogle.click();
					Thread.sleep(1000);
					
					//Scroll
						JavascriptExecutor jse3 = (JavascriptExecutor)driver;
						jse3.executeScript("window.scrollBy(0,250)", "");
						Thread.sleep(1000);

						//EIA Details
						EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
						EIA_Details.click();
						Thread.sleep(1000);
						
						EIA_NO = driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
						EIA_NO.click();
						Thread.sleep(1000);
						
						//Other Details
						
						Other_Details = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Other_Details));
						Other_Details.click();
						Thread.sleep(1000);
						
						PEP_Toogle = driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
						PEP_Toogle.click();
						Thread.sleep(1000);

						Risk = driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
						Risk.click();
						Thread.sleep(1000);
						
						IAgree = driver.findElement(By.xpath(EApp_LandingPage.Basic_Details_Agree));
						IAgree.click();
						Thread.sleep(1000);
					
							}
							catch(Exception e)
							{
								Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
								e.printStackTrace();
							}
						}
				
						   @SuppressWarnings({ "deprecation", "unused" })
							public void To_be_insured_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
								{
								   try
								   {
								
								   //to be insured
								   Proposer_mname=driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
								   cell = sheet.getRow(6).getCell(47);
								   cell.setCellType(Cell.CELL_TYPE_STRING);
								   String insurerMiddleName = cell.getStringCellValue();
								   System.out.println(insurerMiddleName);	
								   Proposer_mname.sendKeys(insurerMiddleName);
								 	Thread.sleep(1000);
								 	Insurer_MiddleName= driver.findElement(By.xpath(EApp_LandingPage.Insurer_MiddleName));
								   Proposer_mname.click();
								 	Thread.sleep(1000);
								   Extent_Reporting.Log_Pass("Entering insured mname","Entered insured mname");
								   
								   
								   
								   Birth_State=driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
								   cell = sheet.getRow(6).getCell(13);
								   cell.setCellType(Cell.CELL_TYPE_STRING);
								   String birthstate = cell.getStringCellValue();
								   System.out.println(birthstate);	
								   Birth_State.sendKeys(birthstate);
									Thread.sleep(1000);
									Birth_State2 = driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthState));
									Birth_State2.click();
									Thread.sleep(1000);
								   Extent_Reporting.Log_Pass("Entering Birth State","Entered Birth State");
								Extent_Reporting.Log_Pass_with_Screenshot("Entering Client Details", "Entered Client Details", driver);
								   
							
							
							
							
								PlaceOfBirth=driver.findElement(By.xpath(EApp_LandingPage.Insurer_BirthCity));
								cell = sheet.getRow(6).getCell(3);
								cell.setCellType(Cell.CELL_TYPE_STRING);
								String place = cell.getStringCellValue();
								System.out.println(place);	
								first_Name.sendKeys(place);
								Extent_Reporting.Log_Pass("Enterng place","Entered place Successfully");
							
							
							
							
								Fathermothername=driver.findElement(By.xpath(EApp_LandingPage.Insurer_FatherName));
								cell = sheet.getRow(6).getCell(3);
								cell.setCellType(Cell.CELL_TYPE_STRING);
								String fathermothername = cell.getStringCellValue();
								System.out.println(fathermothername);	
								first_Name.sendKeys(fathermothername);
								Extent_Reporting.Log_Pass("Enterng fathermothername","Entered fathermothername Successfully");
							
								//Select nationality
								Nationality_Dropdown=driver.findElement(By.xpath(EApp_LandingPage.Nationality));
								   cell = sheet.getRow(6).getCell(8);
								   cell.setCellType(Cell.CELL_TYPE_STRING);
								   String nationality = cell.getStringCellValue();
								   System.out.println(nationality);	
								   Select nationality_Dropdown = new Select(Nationality_Dropdown);
								   nationality_Dropdown.selectByValue("Indian");
								   Extent_Reporting.Log_Pass("Selecting Nationality","Selected Nationality");
								   
								   //minor living with
									Minorliving_Dropdown=driver.findElement(By.xpath(EApp_LandingPage.Minorlivingwith));
									   cell = sheet.getRow(6).getCell(8);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String minor = cell.getStringCellValue();
								      System.out.println(minor);	
								      Select minorliving_Dropdown = new Select(Minorliving_Dropdown);
								      minorliving_Dropdown.selectByValue("Parents");
								      Extent_Reporting.Log_Pass("Selecting Minorlivingwith","Selected Minorlivingwith");
								      
								//studying in
								      Studyingin_Radiobutton=driver.findElement(By.xpath(EApp_LandingPage.Studyin));
									   cell = sheet.getRow(6).getCell(8);
								     cell.setCellType(Cell.CELL_TYPE_STRING);
								     String studying = cell.getStringCellValue();
								     System.out.println(studying);	
								     Studyingin_Radiobutton.sendKeys(studying);
								     Extent_Reporting.Log_Pass("Enterng studying","Entered studying Successfully");
							
								     //comm add
							
								     
								     Thread.sleep(1000);
								     Proposer_Address_Radiobutton= driver.findElement(By.xpath(EApp_LandingPage.CommunicationAddRadiobutton));
								cell = sheet.getRow(6).getCell(81);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String proposer_Address  = cell.getStringCellValue();
								      System.out.println(proposer_Address); 
								      Select proposer_Address_Radiobutton = new Select(Proposer_Address_Radiobutton);
								      minorliving_Dropdown.selectByValue("Yes");
								     Extent_Reporting.Log_Pass("Selecting radiobutton","Selected"); 
								     /*
								     
								     //mobile no
								     
								     Thread.sleep(1000);
								     Proposer_mobNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_mobile_Number));
								cell = sheet.getRow(6).getCell(82);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String proposerMobNo  = cell.getStringCellValue();
								      System.out.println(ProposerMobNo); 
								      Proposer_mobNo.sendKeys(ProposerMobNo);
								     Extent_Reporting.Log_Pass("Entering Proposer's Mob No","Entered Proposer's Mob No"); 
								     
								     //alt mob no
								     
								     Thread.sleep(1000);
								     Proposer_AltmobNo = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Alternate_Number));
								cell = sheet.getRow(6).getCell(83);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String proposerAltMobNo  = cell.getStringCellValue();
								      System.out.println(ProposerAltMobNo); 
								      Proposer_AltmobNo.sendKeys(ProposerAltMobNo);
								     Extent_Reporting.Log_Pass("Entering Proposer's Alt Mob No","Entered Proposer's Alt Mob No"); 
								     //iagee
								     
								     */
								     
								     
								     //concurrent app
								     
								     
								     
								  Exposed_Radiobutton= driver.findElement(By.xpath(EApp_LandingPage.Insurer_PEP_Toggle_NO));
								cell = sheet.getRow(6).getCell(88);
								      cell.setCellType(Cell.CELL_TYPE_STRING);
								      String exposed_Radiobutton  = cell.getStringCellValue();
								      System.out.println(exposed_Radiobutton); 
								      Select Exposed_Radio= new Select(Exposed_Radiobutton);
								      minorliving_Dropdown.selectByValue("No");
								     Extent_Reporting.Log_Pass("Selecting radiobutton","Selected"); 
								     
							     
							     //purpose
							     
							     Purpose_Radiobutton= driver.findElement(By.xpath(EApp_LandingPage.Insurer_Purpose_Risk));
							     cell = sheet.getRow(6).getCell(88);
							           cell.setCellType(Cell.CELL_TYPE_STRING);
							           String purpose_Radio  = cell.getStringCellValue();
							           System.out.println(purpose_Radio); 
							           Select Purpose_Radio= new Select(Purpose_Radiobutton);
							           Purpose_Radio.selectByValue("Risk");
							          Extent_Reporting.Log_Pass("Selecting radiobutton","Selected"); 
							          
							          
							          
							          Agree= driver.findElement(By.xpath(EApp_LandingPage.Iagree4));
							          Agree.click();
							          //Existing policies
								   }
							      	catch(Exception e)
									{
										Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
										e.printStackTrace();
									}
								}
				
		//Nominee
				@SuppressWarnings("deprecation")
				public void Basic_Details_Nominee_NRI(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(3);
		Nominee_First_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeFirstNam));
		cell = sheet.getRow(6).getCell(94);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nominee_FirstName = cell.getStringCellValue();
		System.out.println(Nominee_FirstName);	
		Nominee_First_Name.sendKeys(Nominee_FirstName);
		Extent_Reporting.Log_Pass("Entering Nominee First Name ","Entered Nominee First Name as "+Nominee_FirstName);

		Nominee_Last_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeLastNam));
		cell = sheet.getRow(6).getCell(95);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nominee_LastName = cell.getStringCellValue();
		System.out.println(Nominee_LastName);	
		Nominee_Last_Name.sendKeys(Nominee_LastName);
		Extent_Reporting.Log_Pass("Entering Nominee Last Name ","Entered Nominee Last Name as "+Nominee_LastName);

		Nominee_DoB = driver.findElement(By.xpath(EApp_LandingPage.NomineeDOB));
		cell = sheet.getRow(6).getCell(96);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeDoB = cell.getStringCellValue();
		System.out.println(NomineeDoB);	
		Nominee_DoB.sendKeys(NomineeDoB);
		Extent_Reporting.Log_Pass("Entering Nominee DoB ","Entered Nominee DoB as "+NomineeDoB);

		Nominee_Relationship = driver.findElement(By.xpath(EApp_LandingPage.Relationship));
		cell = sheet.getRow(6).getCell(97);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nomineerelationship = cell.getStringCellValue();
		System.out.println(Nomineerelationship);	
		Select NomineeRelationship = new Select(Nominee_Relationship);
		NomineeRelationship.selectByValue("SPOUS");	
		Extent_Reporting.Log_Pass("Entering Nominee Relationship ","Entered Nominee Relationship as "+Nomineerelationship);

		Nominee_Share = driver.findElement(By.xpath(EApp_LandingPage.NomineeShare));
		cell = sheet.getRow(6).getCell(98);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeShare = cell.getStringCellValue();
		System.out.println(Nomineerelationship);	
		Nominee_Share.sendKeys(NomineeShare);
		Extent_Reporting.Log_Pass("Entering Nominee Share ","Entered Nominee Share as "+NomineeShare);

		Nominee_Contact = driver.findElement(By.xpath(EApp_LandingPage.NomineeContact));
		cell = sheet.getRow(6).getCell(99);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeContact = cell.getStringCellValue();
		System.out.println(NomineeContact);	
		Nominee_Contact.sendKeys(NomineeContact);
		Extent_Reporting.Log_Pass("Entering Nominee Contact ","Entered Nominee Contact as "+NomineeContact);

		Nominee_Add = driver.findElement(By.xpath(EApp_LandingPage.NomineeAdd));
		Nominee_Add.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Nominee Add ","Clicked Nominee Add");

		Nominee_Agree = driver.findElement(By.xpath(EApp_LandingPage.Nominee_IAgree));
		Nominee_Agree.click();
		Thread.sleep(2000);
		Extent_Reporting.Log_Pass("Clicking Nominee Agree ","Clicked Nominee Agree");

					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
				
				//Nominee Same ULIP
				@SuppressWarnings("deprecation")
				public void Basic_Details_Nominee_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(2);
		Nominee_First_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeFirstNam));
		cell = sheet.getRow(6).getCell(129);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nominee_FirstName = cell.getStringCellValue();
		System.out.println(Nominee_FirstName);	
		Nominee_First_Name.sendKeys(Nominee_FirstName);
		Extent_Reporting.Log_Pass("Entering Nominee First Name ","Entered Nominee First Name as "+Nominee_FirstName);

		Nominee_Last_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeLastNam));
		cell = sheet.getRow(6).getCell(130);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nominee_LastName = cell.getStringCellValue();
		System.out.println(Nominee_LastName);	
		Nominee_Last_Name.sendKeys(Nominee_LastName);
		Extent_Reporting.Log_Pass("Entering Nominee Last Name ","Entered Nominee Last Name as "+Nominee_LastName);

		Nominee_DoB = driver.findElement(By.xpath(EApp_LandingPage.NomineeDOB));
		cell = sheet.getRow(6).getCell(131);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeDoB = cell.getStringCellValue();
		System.out.println(NomineeDoB);	
		Nominee_DoB.sendKeys(NomineeDoB);
		Extent_Reporting.Log_Pass("Entering Nominee DoB ","Entered Nominee DoB as "+NomineeDoB);

		Nominee_Relationship = driver.findElement(By.xpath(EApp_LandingPage.Relationship));
		cell = sheet.getRow(6).getCell(132);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Nomineerelationship = cell.getStringCellValue();
		System.out.println(Nomineerelationship);	
		Select NomineeRelationship = new Select(Nominee_Relationship);
		NomineeRelationship.selectByValue("SPOUS");	
		Extent_Reporting.Log_Pass("Entering Nominee Relationship ","Entered Nominee Relationship as "+Nomineerelationship);

		Nominee_Share = driver.findElement(By.xpath(EApp_LandingPage.NomineeShare));
		cell = sheet.getRow(6).getCell(133);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeShare = cell.getStringCellValue();
		System.out.println(Nomineerelationship);	
		Nominee_Share.sendKeys(NomineeShare);
		Extent_Reporting.Log_Pass("Entering Nominee Share ","Entered Nominee Share as "+NomineeShare);

		Nominee_Contact = driver.findElement(By.xpath(EApp_LandingPage.NomineeContact));
		cell = sheet.getRow(6).getCell(134);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NomineeContact = cell.getStringCellValue();
		System.out.println(NomineeContact);	
		Nominee_Contact.sendKeys(NomineeContact);
		Extent_Reporting.Log_Pass("Entering Nominee Contact ","Entered Nominee Contact as "+NomineeContact);

		Nominee_Add = driver.findElement(By.xpath(EApp_LandingPage.NomineeAdd));
		Nominee_Add.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Nominee Add ","Clicked Nominee Add");

		Nominee_Agree = driver.findElement(By.xpath(EApp_LandingPage.Nominee_IAgree));
		Nominee_Agree.click();
		Thread.sleep(2000);
		Extent_Reporting.Log_Pass("Clicking Nominee Agree ","Clicked Nominee Agree");

					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
				
	//Same_Medical
				@SuppressWarnings("deprecation")
				public void Basic_Details_Nominee_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(4);
						  
							Nominee_First_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeFirstNam));
							cell = sheet.getRow(6).getCell(91);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nominee_FirstName = cell.getStringCellValue();
							System.out.println(Nominee_FirstName);	
							Nominee_First_Name.sendKeys(Nominee_FirstName);
							Extent_Reporting.Log_Pass("Entering Nominee First Name ","Entered Nominee First Name as "+Nominee_FirstName);
					
							Nominee_Last_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeLastNam));
							cell = sheet.getRow(6).getCell(92);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nominee_LastName = cell.getStringCellValue();
							System.out.println(Nominee_LastName);	
							Nominee_Last_Name.sendKeys(Nominee_LastName);
							Extent_Reporting.Log_Pass("Entering Nominee Last Name ","Entered Nominee Last Name as "+Nominee_LastName);
					
							Nominee_DoB = driver.findElement(By.xpath(EApp_LandingPage.NomineeDOB));
							cell = sheet.getRow(6).getCell(93);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeDoB = cell.getStringCellValue();
							System.out.println(NomineeDoB);	
							Nominee_DoB.sendKeys(NomineeDoB);
							Extent_Reporting.Log_Pass("Entering Nominee DoB ","Entered Nominee DoB as "+NomineeDoB);
					
							Nominee_Relationship = driver.findElement(By.xpath(EApp_LandingPage.Relationship));
							cell = sheet.getRow(6).getCell(94);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nomineerelationship = cell.getStringCellValue();
							System.out.println(Nomineerelationship);	
							Select NomineeRelationship = new Select(Nominee_Relationship);
							NomineeRelationship.selectByValue("SPOUS");	
							Extent_Reporting.Log_Pass("Entering Nominee Relationship ","Entered Nominee Relationship as "+Nomineerelationship);
					
							Nominee_Share = driver.findElement(By.xpath(EApp_LandingPage.NomineeShare));
							cell = sheet.getRow(6).getCell(95);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeShare = cell.getStringCellValue();
							System.out.println(Nomineerelationship);	
							Nominee_Share.sendKeys(NomineeShare);
							Extent_Reporting.Log_Pass("Entering Nominee Share ","Entered Nominee Share as "+NomineeShare);
					
							Nominee_Contact = driver.findElement(By.xpath(EApp_LandingPage.NomineeContact));
							cell = sheet.getRow(6).getCell(96);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeContact = cell.getStringCellValue();
							System.out.println(NomineeContact);	
							Nominee_Contact.sendKeys(NomineeContact);
							Extent_Reporting.Log_Pass("Entering Nominee Contact ","Entered Nominee Contact as "+NomineeContact);
					
							Nominee_Add = driver.findElement(By.xpath(EApp_LandingPage.NomineeAdd));
							Nominee_Add.click();
							Thread.sleep(1000);
							Extent_Reporting.Log_Pass("Clicking Nominee Add ","Clicked Nominee Add");
					
							Nominee_Agree = driver.findElement(By.xpath(EApp_LandingPage.Nominee_IAgree));
							Nominee_Agree.click();
							Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Clicking Nominee Agree ","Clicked Nominee Agree");

					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
				//Nominee Same
				@SuppressWarnings("deprecation")
				public void Basic_Details_Nominee_Same(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(1);
						  
							Nominee_First_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeFirstNam));
							cell = sheet.getRow(6).getCell(132);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nominee_FirstName = cell.getStringCellValue();
							System.out.println(Nominee_FirstName);	
							Nominee_First_Name.sendKeys(Nominee_FirstName);
							Extent_Reporting.Log_Pass("Entering Nominee First Name ","Entered Nominee First Name as "+Nominee_FirstName);
					
							Nominee_Last_Name = driver.findElement(By.xpath(EApp_LandingPage.NomineeLastNam));
							cell = sheet.getRow(6).getCell(133);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nominee_LastName = cell.getStringCellValue();
							System.out.println(Nominee_LastName);	
							Nominee_Last_Name.sendKeys(Nominee_LastName);
							Extent_Reporting.Log_Pass("Entering Nominee Last Name ","Entered Nominee Last Name as "+Nominee_LastName);
					
							Nominee_DoB = driver.findElement(By.xpath(EApp_LandingPage.NomineeDOB));
							cell = sheet.getRow(6).getCell(134);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeDoB = cell.getStringCellValue();
							System.out.println(NomineeDoB);	
							Nominee_DoB.sendKeys(NomineeDoB);
							Extent_Reporting.Log_Pass("Entering Nominee DoB ","Entered Nominee DoB as "+NomineeDoB);
					
							Nominee_Relationship = driver.findElement(By.xpath(EApp_LandingPage.Relationship));
							cell = sheet.getRow(6).getCell(135);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String Nomineerelationship = cell.getStringCellValue();
							System.out.println(Nomineerelationship);	
							Select NomineeRelationship = new Select(Nominee_Relationship);
							NomineeRelationship.selectByValue("SPOUS");	
							Extent_Reporting.Log_Pass("Entering Nominee Relationship ","Entered Nominee Relationship as "+Nomineerelationship);
					
							Nominee_Share = driver.findElement(By.xpath(EApp_LandingPage.NomineeShare));
							cell = sheet.getRow(6).getCell(136);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeShare = cell.getStringCellValue();
							System.out.println(Nomineerelationship);	
							Nominee_Share.sendKeys(NomineeShare);
							Extent_Reporting.Log_Pass("Entering Nominee Share ","Entered Nominee Share as "+NomineeShare);
					
							Nominee_Contact = driver.findElement(By.xpath(EApp_LandingPage.NomineeContact));
							cell = sheet.getRow(6).getCell(137);
							cell.setCellType(Cell.CELL_TYPE_STRING);
							String NomineeContact = cell.getStringCellValue();
							System.out.println(NomineeContact);	
							Nominee_Contact.sendKeys(NomineeContact);
							Extent_Reporting.Log_Pass("Entering Nominee Contact ","Entered Nominee Contact as "+NomineeContact);
					
							Nominee_Add = driver.findElement(By.xpath(EApp_LandingPage.NomineeAdd));
							Nominee_Add.click();
							Thread.sleep(1000);
							Extent_Reporting.Log_Pass("Clicking Nominee Add ","Clicked Nominee Add");
					
							Nominee_Agree = driver.findElement(By.xpath(EApp_LandingPage.Nominee_IAgree));
							Nominee_Agree.click();
							Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Clicking Nominee Agree ","Clicked Nominee Agree");

					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}

		
		
		//Previous Policy Details
				@SuppressWarnings("deprecation")
				public void Previous_Policy_Details(WebDriver driver) throws IOException, InterruptedException {
					try {
		Concurrent_Toggle = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyNo));
		Concurrent_Toggle.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Concurrent Toggle ","Clicked Concurrent Toggle");

		Refused_Link = driver.findElement(By.xpath(EApp_LandingPage.PlusSign6));
		Refused_Link.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Refused Link ","Clicked Refused Link");

		Refused_Toggle = driver.findElement(By.xpath(EApp_LandingPage.Refused_No));
		Refused_Toggle.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Refused Toggle ","Clicked Refused Toggle");

		PPD_Iagree = driver.findElement(By.xpath(EApp_LandingPage.PPD_Iagree));
		PPD_Iagree.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Previous Policy Details Agree ","Previous Policy Details Agree");
}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}
				// Same_Medical
				@SuppressWarnings("deprecation")
				public void Previous_Policy_Details_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
					try {
		Concurrent_Toggle = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyNo));
		Concurrent_Toggle.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Concurrent Toggle ","Clicked Concurrent Toggle");

		Refused_Link = driver.findElement(By.xpath(EApp_LandingPage.PlusSign6));
		Refused_Link.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Refused Link ","Clicked Refused Link");

		Refused_Toggle = driver.findElement(By.xpath(EApp_LandingPage.Refused_No));
		Refused_Toggle.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Refused Toggle ","Clicked Refused Toggle");

		PPD_Iagree = driver.findElement(By.xpath(EApp_LandingPage.PPD_Iagree));
		PPD_Iagree.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Previous Policy Details Agree ","Previous Policy Details Agree");
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
				}
				// Same
						@SuppressWarnings("deprecation")
						public void Previous_Policy_Details_Same(WebDriver driver) throws IOException, InterruptedException {
							try {
				Concurrent_Toggle = driver.findElement(By.xpath(EApp_LandingPage.ExistingPolicyNo));
				Concurrent_Toggle.click();
				Thread.sleep(1000);
				Extent_Reporting.Log_Pass("Clicking Concurrent Toggle ","Clicked Concurrent Toggle");

				Refused_Link = driver.findElement(By.xpath(EApp_LandingPage.PlusSign6));
				Refused_Link.click();
				Thread.sleep(1000);
				Extent_Reporting.Log_Pass("Clicking Refused Link ","Clicked Refused Link");

				Refused_Toggle = driver.findElement(By.xpath(EApp_LandingPage.Refused_No));
				Refused_Toggle.click();
				Thread.sleep(1000);
				Extent_Reporting.Log_Pass("Clicking Refused Toggle ","Clicked Refused Toggle");

				PPD_Iagree = driver.findElement(By.xpath(EApp_LandingPage.PPD_Iagree));
				PPD_Iagree.click();
				Thread.sleep(1000);
				Extent_Reporting.Log_Pass("Clicking Previous Policy Details Agree ","Previous Policy Details Agree");
		}
		catch(Exception e)
		{
			Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
			e.printStackTrace();
		}
		}
				
				
				//Bank Details NRI
				@SuppressWarnings("deprecation")
				public void Bank_Details_NRI(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(3);		
				
		
		Account_Holder_Name = driver.findElement(By.xpath(EApp_LandingPage.AccountHolderNam));
		cell = sheet.getRow(6).getCell(105);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Account_HolderName = cell.getStringCellValue();
		System.out.println(Account_HolderName);	
		Account_Holder_Name.sendKeys(Account_HolderName);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+Account_HolderName);

		Account_Number = driver.findElement(By.xpath(EApp_LandingPage.AccountNum));
		cell = sheet.getRow(6).getCell(106);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String AccountNumber = cell.getStringCellValue();
		System.out.println(AccountNumber);	
		Account_Number.sendKeys(AccountNumber);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+AccountNumber);
	
		

		IFSC = driver.findElement(By.xpath(EApp_LandingPage.IFSC));
		cell = sheet.getRow(6).getCell(108);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String ifsc = cell.getStringCellValue();
		System.out.println(ifsc);	
		IFSC.sendKeys(ifsc);
		Extent_Reporting.Log_Pass("Entering IFSC ","Entered IFSC "+ifsc);
	
		Savings = driver.findElement(By.xpath(EApp_LandingPage.AccountType_Savings));
		Savings.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Savings Account Type ","Clicked Savings Account Type as Savings");
		
		Thread.sleep(1000);
		
		Premium_Link = driver.findElement(By.xpath(EApp_LandingPage.Renewal_Premium_Link));
		Premium_Link.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Renewal Premium Payment Details Link","Clicked Renewal Premium Payment Details Link");
		
		DirectBill = driver.findElement(By.xpath(EApp_LandingPage.DirectBill));
		DirectBill.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking DirectBill","Clicked DirectBill");
		
		BankDetails_Iagree = driver.findElement(By.xpath(EApp_LandingPage.BankDetails_Iagree));
		BankDetails_Iagree.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking BankDetails Iagree","Clicked BankDetails Iagree");
		
}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}
				//Bank Details Same
				@SuppressWarnings("deprecation")
				public void Bank_Details_Same(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(1);		
				
		
		Account_Holder_Name = driver.findElement(By.xpath(EApp_LandingPage.AccountHolderNam));
		cell = sheet.getRow(6).getCell(143);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Account_HolderName = cell.getStringCellValue();
		System.out.println(Account_HolderName);	
		Account_Holder_Name.sendKeys(Account_HolderName);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+Account_HolderName);

		Account_Number = driver.findElement(By.xpath(EApp_LandingPage.AccountNum));
		cell = sheet.getRow(6).getCell(144);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String AccountNumber = cell.getStringCellValue();
		System.out.println(AccountNumber);	
		Account_Number.sendKeys(AccountNumber);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+AccountNumber);
	
		

		IFSC = driver.findElement(By.xpath(EApp_LandingPage.IFSC));
		cell = sheet.getRow(6).getCell(146);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String ifsc = cell.getStringCellValue();
		System.out.println(ifsc);	
		IFSC.sendKeys(ifsc);
		Extent_Reporting.Log_Pass("Entering IFSC ","Entered IFSC "+ifsc);
	
		Savings = driver.findElement(By.xpath(EApp_LandingPage.AccountType_Savings));
		Savings.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Savings Account Type ","Clicked Savings Account Type as Savings");
		
		Thread.sleep(1000);
		
		Premium_Link = driver.findElement(By.xpath(EApp_LandingPage.Renewal_Premium_Link));
		Premium_Link.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Renewal Premium Payment Details Link","Clicked Renewal Premium Payment Details Link");
		
		DirectBill = driver.findElement(By.xpath(EApp_LandingPage.DirectBill));
		DirectBill.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking DirectBill","Clicked DirectBill");
		
		BankDetails_Iagree = driver.findElement(By.xpath(EApp_LandingPage.BankDetails_Iagree));
		BankDetails_Iagree.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking BankDetails Iagree","Clicked BankDetails Iagree");
		
}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}
				
				//Bank Details Same - ULIP
				@SuppressWarnings("deprecation")
				public void Bank_Details_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(2);		
				
		
		Account_Holder_Name = driver.findElement(By.xpath(EApp_LandingPage.AccountHolderNam));
		cell = sheet.getRow(6).getCell(140);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Account_HolderName = cell.getStringCellValue();
		System.out.println(Account_HolderName);	
		Account_Holder_Name.sendKeys(Account_HolderName);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+Account_HolderName);

		Account_Number = driver.findElement(By.xpath(EApp_LandingPage.AccountNum));
		cell = sheet.getRow(6).getCell(141);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String AccountNumber = cell.getStringCellValue();
		System.out.println(AccountNumber);	
		Account_Number.sendKeys(AccountNumber);
		Extent_Reporting.Log_Pass("Entering Account Holder Name ","Entered Account Holder Name as "+AccountNumber);
	
		

		IFSC = driver.findElement(By.xpath(EApp_LandingPage.IFSC));
		cell = sheet.getRow(6).getCell(143);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String ifsc = cell.getStringCellValue();
		System.out.println(ifsc);	
		IFSC.sendKeys(ifsc);
		Extent_Reporting.Log_Pass("Entering IFSC ","Entered IFSC "+ifsc);
	
		Savings = driver.findElement(By.xpath(EApp_LandingPage.AccountType_Savings));
		Savings.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Savings Account Type ","Clicked Savings Account Type as Savings");
		
		Thread.sleep(1000);
		
		Premium_Link = driver.findElement(By.xpath(EApp_LandingPage.Renewal_Premium_Link));
		Premium_Link.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Renewal Premium Payment Details Link","Clicked Renewal Premium Payment Details Link");
		
		DirectBill = driver.findElement(By.xpath(EApp_LandingPage.DirectBill));
		DirectBill.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking DirectBill","Clicked DirectBill");
		
		BankDetails_Iagree = driver.findElement(By.xpath(EApp_LandingPage.BankDetails_Iagree));
		BankDetails_Iagree.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking BankDetails Iagree","Clicked BankDetails Iagree");
		
}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}
				
	//Health Details
				//NRI
				@SuppressWarnings("deprecation")
				public void Health_Details_NRI(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(3);		
				
		
		Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
		cell = sheet.getRow(6).getCell(112);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightFeet = cell.getStringCellValue();
		System.out.println(HeightFeet);	
		Height_Feet.sendKeys(HeightFeet);
		Extent_Reporting.Log_Pass("Entering Height (Feet) ","Entered Height (Feet) "+HeightFeet);
	
		
		Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
		cell = sheet.getRow(6).getCell(113);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightInch = cell.getStringCellValue();
		System.out.println(HeightInch);	
		Height_Inch.sendKeys(HeightInch);
		Extent_Reporting.Log_Pass("Entering Height (Inch) ","Entered Height (Inch) "+HeightInch);
	
		Weight_Kg = driver.findElement(By.xpath(EApp_LandingPage.Weight));
		cell = sheet.getRow(6).getCell(114);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String WeightKg = cell.getStringCellValue();
		System.out.println(WeightKg);	
		Weight_Kg.sendKeys(WeightKg);
		Extent_Reporting.Log_Pass("Entering Weight (Kg) ","Entered Weight (Kg) "+WeightKg);
	
		Weight_Change_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Weight_Change_Toggle));
		Weight_Change_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Weight Change Toggle (No) ","Clicked Weight Change Toggle (No)");
		
		Lifestyle_Information = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Information));
		Lifestyle_Information.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Information ","Clicked Lifestyle Information");
		
		Lifestyle_Toggle1_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle1_No));
		Lifestyle_Toggle1_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle1 (No) ","Clicked Lifestyle Toggle1 (No)");
		
		Lifestyle_Toggle2_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle2_No));
		Lifestyle_Toggle2_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle2 (No) ","Clicked Lifestyle Toggle2 (No)");
		
		Lifestyle_Toggle3_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle3_No));
		Lifestyle_Toggle3_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle3 (No) ","Clicked Lifestyle Toggle3 (No)");
		
		Lifestyle_Toggle4_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle4_No));
		Lifestyle_Toggle4_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle4 (No) ","Clicked Lifestyle Toggle4 (No)");
		
		        //Scroll
				JavascriptExecutor jse10 = (JavascriptExecutor)driver;
				jse10.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(1000);
		
				Lifestyle_Toggle5_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle5_No));
				Lifestyle_Toggle5_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle5 (No) ","Clicked Lifestyle Toggle5 (No)");
		
		//Family Medical History
		
		Family_Medical_History = driver.findElement(By.xpath(EApp_LandingPage.Family_Medical_History));
		Family_Medical_History.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		Family_Medical_History_None = driver.findElement(By.xpath(EApp_LandingPage.FMHNone));
		Family_Medical_History_None.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		FatherAge = driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
		cell = sheet.getRow(6).getCell(125);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Father_Age = cell.getStringCellValue();
		System.out.println("Father Age"+Father_Age);	
		FatherAge.sendKeys(Father_Age);
		Extent_Reporting.Log_Pass("Entering Father Age","Entered Father Age"+Father_Age);
	
		Father_Health = driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
		cell = sheet.getRow(6).getCell(126);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String FatherHealth = cell.getStringCellValue();
		System.out.println(FatherHealth);
		Select Father_State_Health = new Select(Father_Health);
		Father_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Father Health State","Selected Father Health State as "+FatherHealth);

		Thread.sleep(1000);
		
		MotherAge = driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
		cell = sheet.getRow(6).getCell(128);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Mother_Age = cell.getStringCellValue();
		System.out.println("Mother Age"+Mother_Age);	
		MotherAge.sendKeys(Mother_Age);
		//MotherAge.sendKeys(Mother_Age);

		Extent_Reporting.Log_Pass("Entering Mother Age","Entered Mother Age"+Mother_Age);
		Mother_Health = driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
		cell = sheet.getRow(6).getCell(129);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String MotherHealth = cell.getStringCellValue();
		System.out.println(MotherHealth);
		Select Mother_State_Health = new Select(Mother_Health);
		Mother_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+MotherHealth);

		Brother_Toggle_NO = driver.findElement(By.xpath(EApp_LandingPage.Brother_Toggle_No));
		Brother_Toggle_NO.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Brother Toggle (No) ","Clicked Brother Toggle (No)");

		Sister_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Sister_Toggle_No));
		Sister_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Sister Toggle (No) ","Clicked Sister Toggle (No)");

		//Scroll
		JavascriptExecutor jse5 = (JavascriptExecutor)driver;
		jse5.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory));
		MedicalHistory.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History ","Clicked Medical History");

		Thread.sleep(2000);
		
		//Scroll
				JavascriptExecutor jse11 = (JavascriptExecutor)driver;
				jse11.executeScript("window.scrollBy(0,-70)", "");
				Thread.sleep(1000);
		
		MedicalHistory_Toggle1 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle1));
		MedicalHistory_Toggle1.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle1 ","Clicked Medical History Toggle1");
		
		MedicalHistory_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle2));
		MedicalHistory_Toggle2.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle2 ","Clicked Medical History Toggle2");
		
		MedicalHistory_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle3));
		MedicalHistory_Toggle3.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle3 ","Clicked Medical History Toggle3");
		
		MedicalHistory_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle4));
		MedicalHistory_Toggle4.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle4 ","Clicked Medical History Toggle4");
		
		MedicalHistory_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle5));
		MedicalHistory_Toggle5.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle5 ","Clicked Medical History Toggle5");
		

        //Scroll
		JavascriptExecutor jse7 = (JavascriptExecutor)driver;
		jse7.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory_Checkbox_NoDisease = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Checkbox_NoDisease));
		MedicalHistory_Checkbox_NoDisease.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Checkbox No Disease ","Clicked Medical History Checkbox No Disease");
		
		MedicalHistory_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle6));
		MedicalHistory_Toggle6.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle6 ","Clicked Medical History Toggle6");
		
		MedicalHistory_Toggle7 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle7));
		MedicalHistory_Toggle7.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle7 ","Clicked Medical History Toggle7");
		
		MedicalHistory_Toggle8 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle8));
		MedicalHistory_Toggle8.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle8 ","Clicked Medical History Toggle8");
		
		MedicalHistory_Toggle9 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle9));
		MedicalHistory_Toggle9.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle9 ","Clicked Medical History Toggle9");
		
		MedicalHistory_Toggle10 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle10));
		MedicalHistory_Toggle10.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle10 ","Clicked Medical History Toggle10");
		

		MedicalHistory_IAgree = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_IAgree));
		MedicalHistory_IAgree.click();
		Thread.sleep(2000);
		Extent_Reporting.Log_Pass("Clicking Medical History I Agree ","Clicked Medical History I agree");
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
					}
		
			
			// Same
								
				@SuppressWarnings("deprecation")
				public void Health_Details_Same(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(1);		
				
		
		Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
		cell = sheet.getRow(6).getCell(150);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightFeet = cell.getStringCellValue();
		System.out.println(HeightFeet);	
		Height_Feet.sendKeys(HeightFeet);
		Extent_Reporting.Log_Pass("Entering Height (Feet) ","Entered Height (Feet) "+HeightFeet);
	
		
		Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
		cell = sheet.getRow(6).getCell(151);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightInch = cell.getStringCellValue();
		System.out.println(HeightInch);	
		Height_Inch.sendKeys(HeightInch);
		Extent_Reporting.Log_Pass("Entering Height (Inch) ","Entered Height (Inch) "+HeightInch);
	
		Weight_Kg = driver.findElement(By.xpath(EApp_LandingPage.Weight));
		cell = sheet.getRow(6).getCell(152);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String WeightKg = cell.getStringCellValue();
		System.out.println(WeightKg);	
		Weight_Kg.sendKeys(WeightKg);
		Extent_Reporting.Log_Pass("Entering Weight (Kg) ","Entered Weight (Kg) "+WeightKg);
	
		Weight_Change_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Weight_Change_Toggle));
		Weight_Change_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Weight Change Toggle (No) ","Clicked Weight Change Toggle (No)");
		
		Lifestyle_Information = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Information));
		Lifestyle_Information.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Information ","Clicked Lifestyle Information");
		
		Lifestyle_Toggle1_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle1_No));
		Lifestyle_Toggle1_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle1 (No) ","Clicked Lifestyle Toggle1 (No)");
		
		Lifestyle_Toggle2_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle2_No));
		Lifestyle_Toggle2_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle2 (No) ","Clicked Lifestyle Toggle2 (No)");
		
		Lifestyle_Toggle3_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle3_No));
		Lifestyle_Toggle3_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle3 (No) ","Clicked Lifestyle Toggle3 (No)");
		
		Lifestyle_Toggle4_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle4_No));
		Lifestyle_Toggle4_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle4 (No) ","Clicked Lifestyle Toggle4 (No)");
		
		        //Scroll
				JavascriptExecutor jse10 = (JavascriptExecutor)driver;
				jse10.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(1000);
		
				Lifestyle_Toggle5_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle5_No));
				Lifestyle_Toggle5_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle5 (No) ","Clicked Lifestyle Toggle5 (No)");
		
		//Family Medical History
		
		Family_Medical_History = driver.findElement(By.xpath(EApp_LandingPage.Family_Medical_History));
		Family_Medical_History.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		Family_Medical_History_None = driver.findElement(By.xpath(EApp_LandingPage.FMHNone));
		Family_Medical_History_None.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		FatherAge = driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
		cell = sheet.getRow(6).getCell(163);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Father_Age = cell.getStringCellValue();
		System.out.println("Father Age"+Father_Age);	
		FatherAge.sendKeys(Father_Age);
		Extent_Reporting.Log_Pass("Entering Father Age","Entered Father Age"+Father_Age);
	
		Father_Health = driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
		cell = sheet.getRow(6).getCell(164);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String FatherHealth = cell.getStringCellValue();
		System.out.println(FatherHealth);
		Select Father_State_Health = new Select(Father_Health);
		Father_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Father Health State","Selected Father Health State as "+FatherHealth);

		Thread.sleep(1000);
		
		MotherAge = driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
		cell = sheet.getRow(6).getCell(166);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Mother_Age = cell.getStringCellValue();
		System.out.println("Mother Age"+Mother_Age);	
		MotherAge.sendKeys(Mother_Age);
		//MotherAge.sendKeys(Mother_Age);

		Extent_Reporting.Log_Pass("Entering Mother Age","Entered Mother Age"+Mother_Age);
		Mother_Health = driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
		cell = sheet.getRow(6).getCell(167);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String MotherHealth = cell.getStringCellValue();
		System.out.println(MotherHealth);
		Select Mother_State_Health = new Select(Mother_Health);
		Mother_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+MotherHealth);

		Brother_Toggle_NO = driver.findElement(By.xpath(EApp_LandingPage.Brother_Toggle_No));
		Brother_Toggle_NO.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Brother Toggle (No) ","Clicked Brother Toggle (No)");

		Sister_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Sister_Toggle_No));
		Sister_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Sister Toggle (No) ","Clicked Sister Toggle (No)");

		//Scroll
		JavascriptExecutor jse5 = (JavascriptExecutor)driver;
		jse5.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory));
		MedicalHistory.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History ","Clicked Medical History");

		Thread.sleep(2000);
		
		//Scroll
				JavascriptExecutor jse11 = (JavascriptExecutor)driver;
				jse11.executeScript("window.scrollBy(0,-70)", "");
				Thread.sleep(1000);
		
		MedicalHistory_Toggle1 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle1));
		MedicalHistory_Toggle1.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle1 ","Clicked Medical History Toggle1");
		
		MedicalHistory_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle2));
		MedicalHistory_Toggle2.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle2 ","Clicked Medical History Toggle2");
		
		MedicalHistory_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle3));
		MedicalHistory_Toggle3.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle3 ","Clicked Medical History Toggle3");
		
		MedicalHistory_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle4));
		MedicalHistory_Toggle4.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle4 ","Clicked Medical History Toggle4");
		
		MedicalHistory_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle5));
		MedicalHistory_Toggle5.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle5 ","Clicked Medical History Toggle5");
		

        //Scroll
		JavascriptExecutor jse7 = (JavascriptExecutor)driver;
		jse7.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory_Checkbox_NoDisease = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Checkbox_NoDisease));
		MedicalHistory_Checkbox_NoDisease.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Checkbox No Disease ","Clicked Medical History Checkbox No Disease");
		
		MedicalHistory_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle6));
		MedicalHistory_Toggle6.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle6 ","Clicked Medical History Toggle6");
		
		MedicalHistory_Toggle7 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle7));
		MedicalHistory_Toggle7.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle7 ","Clicked Medical History Toggle7");
		
		MedicalHistory_Toggle8 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle8));
		MedicalHistory_Toggle8.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle8 ","Clicked Medical History Toggle8");
		
		MedicalHistory_Toggle9 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle9));
		MedicalHistory_Toggle9.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle9 ","Clicked Medical History Toggle9");
		
		MedicalHistory_Toggle10 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle10));
		MedicalHistory_Toggle10.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle10 ","Clicked Medical History Toggle10");
		

		MedicalHistory_IAgree = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_IAgree));
		MedicalHistory_IAgree.click();
		Thread.sleep(2000);
		Extent_Reporting.Log_Pass("Clicking Medical History I Agree ","Clicked Medical History I agree");
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
					}
		
	//Same_ULIP
				@SuppressWarnings("deprecation")
				public void Health_Details_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
					try {
						FileInputStream finput = new FileInputStream(src);
						  workbook = new XSSFWorkbook(finput);
						  sheet= workbook.getSheetAt(2);		
				
		
		Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
		cell = sheet.getRow(6).getCell(147);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightFeet = cell.getStringCellValue();
		System.out.println(HeightFeet);	
		Height_Feet.sendKeys(HeightFeet);
		Extent_Reporting.Log_Pass("Entering Height (Feet) ","Entered Height (Feet) "+HeightFeet);
	
		
		Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
		cell = sheet.getRow(6).getCell(148);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String HeightInch = cell.getStringCellValue();
		System.out.println(HeightInch);	
		Height_Inch.sendKeys(HeightInch);
		Extent_Reporting.Log_Pass("Entering Height (Inch) ","Entered Height (Inch) "+HeightInch);
	
		Weight_Kg = driver.findElement(By.xpath(EApp_LandingPage.Weight));
		cell = sheet.getRow(6).getCell(149);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String WeightKg = cell.getStringCellValue();
		System.out.println(WeightKg);	
		Weight_Kg.sendKeys(WeightKg);
		Extent_Reporting.Log_Pass("Entering Weight (Kg) ","Entered Weight (Kg) "+WeightKg);
	
		Weight_Change_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Weight_Change_Toggle));
		Weight_Change_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Weight Change Toggle (No) ","Clicked Weight Change Toggle (No)");
		
		Lifestyle_Information = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Information));
		Lifestyle_Information.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Information ","Clicked Lifestyle Information");
		
		Lifestyle_Toggle1_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle1_No));
		Lifestyle_Toggle1_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle1 (No) ","Clicked Lifestyle Toggle1 (No)");
		
		Lifestyle_Toggle2_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle2_No));
		Lifestyle_Toggle2_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle2 (No) ","Clicked Lifestyle Toggle2 (No)");
		
		Lifestyle_Toggle3_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle3_No));
		Lifestyle_Toggle3_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle3 (No) ","Clicked Lifestyle Toggle3 (No)");
		
		Lifestyle_Toggle4_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle4_No));
		Lifestyle_Toggle4_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle4 (No) ","Clicked Lifestyle Toggle4 (No)");
		
		        //Scroll
				JavascriptExecutor jse10 = (JavascriptExecutor)driver;
				jse10.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(1000);
		
				Lifestyle_Toggle5_No = driver.findElement(By.xpath(EApp_LandingPage.Lifestyle_Toggle5_No));
				Lifestyle_Toggle5_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Lifestyle Toggle5 (No) ","Clicked Lifestyle Toggle5 (No)");
		
		//Family Medical History
		
		Family_Medical_History = driver.findElement(By.xpath(EApp_LandingPage.Family_Medical_History));
		Family_Medical_History.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		Family_Medical_History_None = driver.findElement(By.xpath(EApp_LandingPage.FMHNone));
		Family_Medical_History_None.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Family Medical History ","Clicked Family Medical History");

		FatherAge = driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
		cell = sheet.getRow(6).getCell(160);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Father_Age = cell.getStringCellValue();
		System.out.println("Father Age"+Father_Age);	
		FatherAge.sendKeys(Father_Age);
		Extent_Reporting.Log_Pass("Entering Father Age","Entered Father Age"+Father_Age);
	
		Father_Health = driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
		cell = sheet.getRow(6).getCell(161);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String FatherHealth = cell.getStringCellValue();
		System.out.println(FatherHealth);
		Select Father_State_Health = new Select(Father_Health);
		Father_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Father Health State","Selected Father Health State as "+FatherHealth);

		Thread.sleep(1000);
		
		MotherAge = driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
		cell = sheet.getRow(6).getCell(163);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String Mother_Age = cell.getStringCellValue();
		System.out.println("Mother Age"+Mother_Age);	
		MotherAge.sendKeys(Mother_Age);
		//MotherAge.sendKeys(Mother_Age);

		Extent_Reporting.Log_Pass("Entering Mother Age","Entered Mother Age"+Mother_Age);
		Mother_Health = driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
		cell = sheet.getRow(6).getCell(164);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String MotherHealth = cell.getStringCellValue();
		System.out.println(MotherHealth);
		Select Mother_State_Health = new Select(Mother_Health);
		Mother_State_Health.selectByValue("O");	
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+MotherHealth);

		Brother_Toggle_NO = driver.findElement(By.xpath(EApp_LandingPage.Brother_Toggle_No));
		Brother_Toggle_NO.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Brother Toggle (No) ","Clicked Brother Toggle (No)");

		Sister_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Sister_Toggle_No));
		Sister_Toggle_No.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Sister Toggle (No) ","Clicked Sister Toggle (No)");

		//Scroll
		JavascriptExecutor jse5 = (JavascriptExecutor)driver;
		jse5.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory));
		MedicalHistory.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History ","Clicked Medical History");

		Thread.sleep(2000);
		
		//Scroll
				JavascriptExecutor jse11 = (JavascriptExecutor)driver;
				jse11.executeScript("window.scrollBy(0,-70)", "");
				Thread.sleep(1000);
		
		MedicalHistory_Toggle1 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle1));
		MedicalHistory_Toggle1.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle1 ","Clicked Medical History Toggle1");
		
		MedicalHistory_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle2));
		MedicalHistory_Toggle2.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle2 ","Clicked Medical History Toggle2");
		
		MedicalHistory_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle3));
		MedicalHistory_Toggle3.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle3 ","Clicked Medical History Toggle3");
		
		MedicalHistory_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle4));
		MedicalHistory_Toggle4.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle4 ","Clicked Medical History Toggle4");
		
		MedicalHistory_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle5));
		MedicalHistory_Toggle5.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle5 ","Clicked Medical History Toggle5");
		

        //Scroll
		JavascriptExecutor jse7 = (JavascriptExecutor)driver;
		jse7.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);
		
		MedicalHistory_Checkbox_NoDisease = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Checkbox_NoDisease));
		MedicalHistory_Checkbox_NoDisease.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Checkbox No Disease ","Clicked Medical History Checkbox No Disease");
		
		MedicalHistory_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle6));
		MedicalHistory_Toggle6.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle6 ","Clicked Medical History Toggle6");
		
		MedicalHistory_Toggle7 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle7));
		MedicalHistory_Toggle7.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle7 ","Clicked Medical History Toggle7");
		
		MedicalHistory_Toggle8 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle8));
		MedicalHistory_Toggle8.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle8 ","Clicked Medical History Toggle8");
		
		MedicalHistory_Toggle9 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle9));
		MedicalHistory_Toggle9.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle9 ","Clicked Medical History Toggle9");
		
		MedicalHistory_Toggle10 = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_Toggle10));
		MedicalHistory_Toggle10.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Medical History Toggle10 ","Clicked Medical History Toggle10");
		

		MedicalHistory_IAgree = driver.findElement(By.xpath(EApp_LandingPage.MedicalHistory_IAgree));
		MedicalHistory_IAgree.click();
		Thread.sleep(2000);
		Extent_Reporting.Log_Pass("Clicking Medical History I Agree ","Clicked Medical History I agree");
					}
					catch(Exception e)
					{
						Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
						e.printStackTrace();
					}
					}
		
//LifeStyle_MandateForm	
				
				//Same_Medical
					
					@SuppressWarnings("deprecation")
					public void LifeStyle_PersonalDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(4);		
					
			
			Height_Feet = driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
			cell = sheet.getRow(6).getCell(150);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String HeightFeet = cell.getStringCellValue();
			System.out.println(HeightFeet);	
			Height_Feet.sendKeys(HeightFeet);
			Extent_Reporting.Log_Pass("Entering Height (Feet) ","Entered Height (Feet) "+HeightFeet);
		
			
			Height_Inch = driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
			cell = sheet.getRow(6).getCell(151);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String HeightInch = cell.getStringCellValue();
			System.out.println(HeightInch);	
			Height_Inch.sendKeys(HeightInch);
			Extent_Reporting.Log_Pass("Entering Height (Inch) ","Entered Height (Inch) "+HeightInch);
		
			Weight_Kg = driver.findElement(By.xpath(EApp_LandingPage.Weight));
			cell = sheet.getRow(6).getCell(152);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String WeightKg = cell.getStringCellValue();
			System.out.println(WeightKg);	
			Weight_Kg.sendKeys(WeightKg);
			Extent_Reporting.Log_Pass("Entering Weight (Kg) ","Entered Weight (Kg) "+WeightKg);
		
			Weight_Change_Toggle_No = driver.findElement(By.xpath(EApp_LandingPage.Weight_Change_Toggle));
			Weight_Change_Toggle_No.click();
			Thread.sleep(1000);
			Extent_Reporting.Log_Pass("Clicking Weight Change Toggle (No) ","Clicked Weight Change Toggle (No)");
			
					
						}
						catch(Exception e)
						{
							Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							e.printStackTrace();
						}
						}
					
		
					@SuppressWarnings("deprecation")
					public void LifeStyle_ResidenceDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(4);		
					
			
							  LIS_traveloutside_Yes=driver.findElement(By.xpath(EApp_LandingPage.Toggle_LIS_Travel));
								LIS_traveloutside_Yes.click();
								Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Clicking LIS_traveloutside_Yes","Clicking LIS_traveloutside_Yes");
								
								
								LIS_Travel_Countries= driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Countries));
								cell = sheet.getRow(6).getCell(113);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_TravelCountries = cell.getStringCellValue();
							       System.out.println(LIS_Travel_Countries);	
								   LIS_Travel_Countries.sendKeys(LIS_TravelCountries);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Countries Name","Adding LIS_Travel_Countries Name");
								
								
								LIS_Travel_City= driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_City));
								cell = sheet.getRow(6).getCell(114);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LISTravel_City = cell.getStringCellValue();
							       System.out.println(LIS_Travel_City);	
								   LIS_Travel_City.sendKeys(LISTravel_City);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_City Name","Adding LIS_Travel_City Name");
								
								LIS_Travel_Date_Arriving=driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Date));
								cell = sheet.getRow(6).getCell(115);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_DateArriving = cell.getStringCellValue();
							       System.out.println(LIS_Travel_DateArriving);	
								   LIS_Travel_Date_Arriving.sendKeys(LIS_Travel_DateArriving);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Date_Arriving","Adding LIS_Date_Arriving");
								
									LIS_Travel_Date_Departure=driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Date));
								cell = sheet.getRow(6).getCell(116);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_DateDeparture = cell.getStringCellValue();
							       System.out.println(LIS_Travel_DateDeparture);	
								   LIS_Travel_Date_Departure.sendKeys(LIS_Travel_DateDeparture);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Date_Departure","Adding LIS_Date_Departur");
								
							 LIS_Travel_Visa=driver.findElement(By.xpath(EApp_LandingPage.LIS_Visa));
								cell = sheet.getRow(6).getCell(117);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_TravelVisa = cell.getStringCellValue();
							       System.out.println(LIS_TravelVisa);	
							       LIS_Travel_Visa.sendKeys(LIS_TravelVisa);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Visa Name","Adding LIS_Travel_Visa Name");
								
							 LIS_Travel_ADD =driver.findElement(By.xpath(EApp_LandingPage.LIS_ADD));
								LIS_Travel_ADD.click();
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Clicking LIS_Travel_ADD ","Clicking LIS_Travel_ADD");
								
								
								
								LIS_Travel1_Countries = driver.findElement(By.xpath(EApp_LandingPage.LIS_12M_Countries));
								cell = sheet.getRow(6).getCell(118);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel1Countries = cell.getStringCellValue();
							       System.out.println(LIS_Travel1Countries);	
								   LIS_Travel1_Countries.sendKeys(LIS_Travel1Countries);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_12M_Countries Name","Adding LIS_12M_Countries Name");
								
								
								LIS_Travel1_City= driver.findElement(By.xpath(EApp_LandingPage.LIS_12M_Cities));
								cell = sheet.getRow(6).getCell(119);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel1City = cell.getStringCellValue();
							       System.out.println(LIS_Travel1City);	
								   LIS_Travel1_City.sendKeys(LIS_Travel1City);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_City Name","Adding LIS_Travel_City Name");
								
								LIS_Travel1_Date_Arriving=driver.findElement(By.xpath(EApp_LandingPage.LIS_Date_arriving));
								cell = sheet.getRow(6).getCell(120);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel1_DateArriving = cell.getStringCellValue();
							       System.out.println(LIS_Travel1_DateArriving);	
								   LIS_Travel1_Date_Arriving.sendKeys(LIS_Travel1_DateArriving);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Date_Arriving","Adding LIS_Date_Arriving");
								
									LIS_Travel1_Date_Departure=driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Date));
								cell = sheet.getRow(6).getCell(121);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel1_DateDeparture = cell.getStringCellValue();
							       System.out.println(LIS_Travel1_DateDeparture);	
								   LIS_Travel1_Date_Departure.sendKeys(LIS_Travel1_DateDeparture);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Date_Departure","Adding LIS_Date_Departur");
								
									LIS_Travel1_Visa=driver.findElement(By.xpath(EApp_LandingPage.LIS_12M_Visa));
								cell = sheet.getRow(6).getCell(122);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel1Visa = cell.getStringCellValue();
							       System.out.println(LIS_Travel1Visa);	
								   LIS_Travel1_Visa.sendKeys(LIS_Travel1Visa);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Visa Name","Adding LIS_Travel_Visa Name");
								
								LIS_Travel1_ADD=driver.findElement(By.xpath(EApp_LandingPage.LIS_12M_ADD));
								cell = sheet.getRow(6).getCell(123);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_TravelADD = cell.getStringCellValue();
							       System.out.println(LIS_TravelADD);	
								   LIS_Travel1_ADD.sendKeys(LIS_TravelADD);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Clicking LIS_Travel_ADD ","Clicking LIS_Travel_ADD");
								
									LIS_Travel_Nationality=driver.findElement(By.xpath(EApp_LandingPage.LIS_Nationality));
								cell = sheet.getRow(6).getCell(124);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_TravelNationality = cell.getStringCellValue();
							       System.out.println(LIS_TravelNationality);	
								   LIS_Travel_Nationality.sendKeys(LIS_TravelNationality);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Nationality ","Adding LIS_Travel_Nationality");
								
								LIS_travel_PropertYES=driver.findElement(By.xpath(EApp_LandingPage.Toggle_LIS_Property_Yes));
								LIS_travel_PropertYES.click();
								Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Clicking LIS_travel_PropertyNO","Clicking LIS_travel_PropertyNO");
								
								
								LIS_travel_PropertDetails=driver.findElement(By.xpath(EApp_LandingPage.LIS_Property_Details));
								cell = sheet.getRow(6).getCell(126);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_travel_Propert_Details = cell.getStringCellValue();
							       System.out.println(LIS_travel_Propert_Details);	
								   LIS_travel_PropertDetails.sendKeys(LIS_travel_Propert_Details);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Property_Details ","Adding LIS_Property_Details");
								
								LIS_toggle_ofResidence =driver.findElement(By.xpath(EApp_LandingPage.LIS_Reside_longer));
								LIS_toggle_ofResidence.click();
								Extent_Reporting.Log_Pass("Clicking LIS_toggle_ofResidence","Clicking LIS_toggle_ofResidence");
								Thread.sleep(2000);
								
								LIS_toggle_ofResidenctype =driver.findElement(By.xpath(EApp_LandingPage.LIS_Reside_Type));
								cell = sheet.getRow(6).getCell(128);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Types_of_Residence = cell.getStringCellValue();
							       System.out.println(LIS_Types_of_Residence);	
								   LIS_toggle_ofResidenctype.sendKeys(LIS_Types_of_Residence);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Types_of_Residence ","Adding LIS_Types_of_Residence");
								
								
								LIS_toggle_ofResidenceAddress =driver.findElement(By.xpath(EApp_LandingPage.LIS_Reside_Address));
								cell = sheet.getRow(6).getCell(129);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_toggle_of_Residence_Address = cell.getStringCellValue();
							       System.out.println(LIS_toggle_of_Residence_Address);	
								   LIS_toggle_ofResidenceAddress.sendKeys(LIS_toggle_of_Residence_Address);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_toggle_of_Residence_Address ","Adding LIS_toggle_of_Residence_Address");
								
								LIS_toggle_Medical_facilities =driver.findElement(By.xpath(EApp_LandingPage.LIS_Reside_MedicalFacilities));
								cell = sheet.getRow(6).getCell(129);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_toggle_Medicalfacilities = cell.getStringCellValue();
							       System.out.println(LIS_toggle_Medicalfacilities);	
								   LIS_toggle_Medical_facilities.sendKeys(LIS_toggle_Medicalfacilities);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_toggle_Medicalfacilities ","Adding LIS_Types_of_Residence");
								
								LIS_Toggle_travelbusiness =driver.findElement(By.xpath(EApp_LandingPage.LIS_travel_business));
								LIS_Toggle_travelbusiness.click();
								Extent_Reporting.Log_Pass("Clicking LIS_Toggle_travelbusiness","Clicking LIS_Toggle_travelbusiness");
								Thread.sleep(2000);
								
								LIS_TravelName =driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Name));
								cell = sheet.getRow(6).getCell(130);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_Name = cell.getStringCellValue();
							       System.out.println(LIS_TravelName);	
								   LIS_TravelName.sendKeys(LIS_Travel_Name);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Name ","Adding LIS_Travel_Name");
							      
								 LIS_Travelrenum =driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_renum));
								cell = sheet.getRow(6).getCell(131);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_renum = cell.getStringCellValue();
							       System.out.println(LIS_Travel_renum);	
								   LIS_Travelrenum.sendKeys(LIS_Travel_renum);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_renum ","Adding LIS_Travel_renum"); 
								
								 LIS_HealthCare =driver.findElement(By.xpath(EApp_LandingPage.LIS_Health_Care));
								cell = sheet.getRow(6).getCell(132);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Health_Care = cell.getStringCellValue();
							       System.out.println(LIS_Health_Care);	
								   LIS_HealthCare.sendKeys(LIS_Health_Care);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Health_Care ","Adding LIS_Health_Care"); 
								
								 LIS_TravelPrec =driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Prec));
								cell = sheet.getRow(6).getCell(133);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_Prec = cell.getStringCellValue();
							       System.out.println(LIS_Travel_Prec);	
								   LIS_HealthCare.sendKeys(LIS_Travel_Prec);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Prec ","Adding LIS_Travel_Prec"); 
								
								
								   LIS_ModeTravel = driver.findElement(By.xpath(EApp_LandingPage.LIS_Mode_Travel));
								cell = sheet.getRow(6).getCell(134);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_ModeTravel = cell.getStringCellValue();
							       System.out.println(LIS_ModeTravel);	
								   LIS_HealthCare.sendKeys(LIS_ModeTravel);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Mode_Travel ","Adding LIS_Mode_Travel"); 
								
								 LIS_TravelResp = driver.findElement(By.xpath(EApp_LandingPage.LIS_Travel_Resp));
								cell = sheet.getRow(6).getCell(135);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Travel_Resp = cell.getStringCellValue();
							       System.out.println(LIS_Travel_Resp);	
								   LIS_TravelResp.sendKeys(LIS_Travel_Resp);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Travel_Resp ","Adding LIS_Travel_Resp"); 
								
								 LIS_ContractInfoYes = driver.findElement(By.xpath(EApp_LandingPage.LIS_ContractInfo_Yes));
								LIS_ContractInfoYes.click();
								 Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_ContractInfo_Yes ","Adding LIS_ContractInfo_Yes"); 
								
								 LIS_Date_ofCommencement = driver.findElement(By.xpath(EApp_LandingPage.LIS_Date_of_Commencement));
								cell = sheet.getRow(6).getCell(137);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Date_of_Commencement = cell.getStringCellValue();
							       System.out.println(LIS_Date_of_Commencement);	
								   LIS_Date_ofCommencement.sendKeys(LIS_Date_of_Commencement);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Date_of_Commencement ","Adding LIS_Date_of_Commencement"); 
								
								
								LISDurations = driver.findElement(By.xpath(EApp_LandingPage.LIS_Durations));
								cell = sheet.getRow(6).getCell(138);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Durations = cell.getStringCellValue();
							       System.out.println(LIS_Durations);	
								   LIS_Date_ofCommencement.sendKeys(LIS_Durations);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Durations ","Adding LIS_Durations"); 
								
								
								LIS_AddInfo = driver.findElement(By.xpath(EApp_LandingPage.LIS_Add_Info));
								LIS_AddInfo.click();
								cell = sheet.getRow(6).getCell(138);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Add_Info = cell.getStringCellValue();
							       System.out.println(LIS_Add_Info);
								   LIS_AddInfo.sendKeys(LIS_Add_Info);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Add_Info ","Adding LIS_Add_Info"); 
								
								LIS_Add_InfoDetails = driver.findElement(By.xpath(EApp_LandingPage.LIS_Add_Info_Details));
								cell = sheet.getRow(6).getCell(138);
							       cell.setCellType(Cell.CELL_TYPE_STRING);
							       String LIS_Add_Info_Details = cell.getStringCellValue();
							       System.out.println(LIS_Add_Info_Details);	
								   LIS_Add_InfoDetails.sendKeys(LIS_Add_Info_Details);
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Adding LIS_Add_Info_Details ","Adding LIS_Add_Info_Details"); 
								
								
								LISSubmit= driver.findElement(By.xpath(EApp_LandingPage.LIS_Submit));
												   LISSubmit.click();
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("clicking LIS_Submit ","clicking LIS_Submit"); 
			
					
						}
						catch(Exception e)
						{
							Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							e.printStackTrace();
						}
						}
				
					@SuppressWarnings("deprecation")
					public void LifeStyle_DivingDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(4);		
					
							  LIS_Toggle_Diving= driver.findElement(By.xpath(EApp_LandingPage.Toggle19));
							   LIS_Toggle_Diving.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_Diving ","clicking LIS_Toggle_Diving"); 
			
			
			LIS_Free_Diving= driver.findElement(By.xpath(EApp_LandingPage.FreeDivingSelection));
							 cell = sheet.getRow(6).getCell(142);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_FreeDiving = cell.getStringCellValue();
		       System.out.println(LIS_FreeDiving);	
			   LIS_Free_Diving.sendKeys(LIS_FreeDiving);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Free_Diving ","Adding LIS_Free_Diving"); 
			
								
			LIS_FreeDiving_Date= driver.findElement(By.xpath(EApp_LandingPage.FreeDivingDate));
					cell = sheet.getRow(6).getCell(143);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Free_Diving_Date = cell.getStringCellValue();
		       System.out.println(LIS_Free_Diving_Date);	
			   LIS_FreeDiving_Date.sendKeys(LIS_Free_Diving_Date);
			   Thread.sleep(3000);
			Extent_Reporting.Log_Pass("Adding LIS_Free_Diving_Date ","Adding LIS_Free_Diving_Date"); 
			
			
			LIS_FreeDiving_Freq= driver.findElement(By.xpath(EApp_LandingPage.FreeDivingFreq));
					cell = sheet.getRow(6).getCell(144);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Free_Diving_Freq = cell.getStringCellValue();
		       System.out.println(LIS_Free_Diving_Freq);	
			   LIS_FreeDiving_Freq.sendKeys(LIS_Free_Diving_Freq);
			   Thread.sleep(3000);
			Extent_Reporting.Log_Pass("Adding LIS_Free_Diving_Freq ","Adding LIS_Free_Diving_Freq"); 
			
			LIS_FreeDiving_Intention= driver.findElement(By.xpath(EApp_LandingPage.FreeDivingIntention));
					cell = sheet.getRow(6).getCell(143);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Free_Diving_Intention = cell.getStringCellValue();
		       System.out.println(LIS_Free_Diving_Intention);	
			   LIS_FreeDiving_Intention.sendKeys(LIS_Free_Diving_Intention);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Free_Diving_Intention ","Adding LIS_Free_Diving_Intention"); 
			
//SkinDiving	
			LIS_Toggle_SkinDiving= driver.findElement(By.xpath(EApp_LandingPage.SkinDiving));
							   LIS_Toggle_SkinDiving.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_SkinDiving ","clicking LIS_Toggle_SkinDiving"); 
			
			LIS_SkinDiving_Loc= driver.findElement(By.xpath(EApp_LandingPage.SkinDivingLoc));
					cell = sheet.getRow(6).getCell(145);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Skin_Diving_Loc = cell.getStringCellValue();
		       System.out.println(LIS_Skin_Diving_Loc);	
			   LIS_SkinDiving_Loc.sendKeys(LIS_Skin_Diving_Loc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Skin_Diving_Loc ","Adding LIS_Skin_Diving_Loc"); 
			
			LIS_SkinDivingDate= driver.findElement(By.xpath(EApp_LandingPage.SkinDivingDate));
					cell = sheet.getRow(6).getCell(145);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_SkinDiving_Date = cell.getStringCellValue();
		       System.out.println(LIS_SkinDiving_Date);	
			   LIS_SkinDivingDate.sendKeys(LIS_SkinDiving_Date);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_SkinDiving_Date ","Adding LIS_SkinDiving_Date"); 
			
			
			LIS_Skin_Diving_Freq= driver.findElement(By.xpath(EApp_LandingPage.SkinDivingFreq));
					cell = sheet.getRow(6).getCell(146);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String Skin_Diving_Freq = cell.getStringCellValue();
		       System.out.println(Skin_Diving_Freq);	
			   LIS_Skin_Diving_Freq.sendKeys(Skin_Diving_Freq);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_SkinDiving_Date ","Adding LIS_SkinDiving_Date"); 
			
			
			LIS_SkinDiving_Intention= driver.findElement(By.xpath(EApp_LandingPage.SkinDivingIntention));
					cell = sheet.getRow(6).getCell(147);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String SkinDiving_Intention = cell.getStringCellValue();
		       System.out.println(SkinDiving_Intention);	
			   LIS_SkinDiving_Intention.sendKeys(SkinDiving_Intention);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_SkinDiving_Intention ","Adding LIS_SkinDiving_Intention"); 
			
// Scuba Diving
		LIS_Toggle_ScubaDiving= driver.findElement(By.xpath(EApp_LandingPage.ScubaDiving));
							   LIS_Toggle_ScubaDiving.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_ScubaDiving ","clicking LIS_Toggle_ScubaDiving");
			
		LIS_ScubaDiving45To100_Sel= driver.findElement(By.xpath(EApp_LandingPage.ScubaDiving45To100Sel));
					cell = sheet.getRow(6).getCell(152);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String ScubaDiving_45To100Sel = cell.getStringCellValue();
		       System.out.println(ScubaDiving_45To100Sel);	
			   LIS_ScubaDiving45To100_Sel.sendKeys(ScubaDiving_45To100Sel);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_SkinDiving_Intention ","Adding LIS_SkinDiving_Intention"); 	
			
				LIS_ScubaDivingLoc= driver.findElement(By.xpath(EApp_LandingPage.ScubaDivingLoc));
					cell = sheet.getRow(6).getCell(153);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_ScubaDiving_Loc = cell.getStringCellValue();
		       System.out.println(LIS_ScubaDiving_Loc);	
			   LIS_ScubaDivingLoc.sendKeys(LIS_ScubaDiving_Loc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_ScubaDiving_Loc ","Adding LIS_ScubaDiving_Loc"); 	
			
			
			LIS_ScubaDivingDate= driver.findElement(By.xpath(EApp_LandingPage.ScubaDivingDate));
					cell = sheet.getRow(6).getCell(154);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_ScubaDiving_Date = cell.getStringCellValue();
		       System.out.println(LIS_ScubaDiving_Date);	
			   LIS_ScubaDivingLoc.sendKeys(LIS_ScubaDiving_Date);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_ScubaDiving_Date ","Adding LIS_ScubaDiving_Date"); 	
			
			
			LIS_ScubaDiving_Freq= driver.findElement(By.xpath(EApp_LandingPage.ScubaDivingFreq));
				cell = sheet.getRow(6).getCell(155);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_ScubaDivingFreq = cell.getStringCellValue();
		       System.out.println(LIS_ScubaDivingFreq);	
			   LIS_ScubaDiving_Freq.sendKeys(LIS_ScubaDivingFreq);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_ScubaDiving_Freq ","Adding LIS_ScubaDiving_Freq"); 	
			
			
			LIS_ScubaDiving_Intention= driver.findElement(By.xpath(EApp_LandingPage.ScubaDivingIntention));
				cell = sheet.getRow(6).getCell(156);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_ScubaDivingIntention = cell.getStringCellValue();
		       System.out.println(LIS_ScubaDivingIntention);	
			   LIS_ScubaDiving_Intention.sendKeys(LIS_ScubaDivingIntention);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_ScubaDiving_Intention ","Adding LIS_ScubaDiving_Intention"); 	
			
//CliffDiving
			LIS_Toggle_CliffDiving= driver.findElement(By.xpath(EApp_LandingPage.CliffDiving));
							   LIS_Toggle_CliffDiving.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_CliffDiving ","clicking LIS_Toggle_CliffDiving");
				
				
				LIS_CliffDiving_Loc= driver.findElement(By.xpath(EApp_LandingPage.CliffDivingLoc));
				cell = sheet.getRow(6).getCell(160);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_CliffDivingLoc = cell.getStringCellValue();
		       System.out.println(LIS_CliffDivingLoc);	
			   LIS_CliffDiving_Loc.sendKeys(LIS_CliffDivingLoc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_CliffDiving_Loc ","Adding LIS_CliffDiving_Loc"); 	
			
			
				LIS_CliffDiving_Date= driver.findElement(By.xpath(EApp_LandingPage.CliffDivingDate));
				cell = sheet.getRow(6).getCell(161);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_CliffDivingDate = cell.getStringCellValue();
		       System.out.println(LIS_CliffDivingDate);	
			   LIS_CliffDiving_Date.sendKeys(LIS_CliffDivingDate);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_CliffDiving_Date ","Adding LIS_CliffDiving_Date"); 	
			
			
			LIS_CliffDiving_Date= driver.findElement(By.xpath(EApp_LandingPage.CliffDivingDate));
				cell = sheet.getRow(6).getCell(162);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Cliff_DivingDate = cell.getStringCellValue();
		       System.out.println(LIS_Cliff_DivingDate);	
			   LIS_CliffDiving_Date.sendKeys(LIS_Cliff_DivingDate);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_CliffDiving_Date ","Adding LIS_CliffDiving_Date"); 
			
			
			LIS_Cliff_DivingFreq= driver.findElement(By.xpath(EApp_LandingPage.CliffDivingFreq));
				cell = sheet.getRow(6).getCell(163);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String Cliff_DivingFreq = cell.getStringCellValue();
		       System.out.println(Cliff_DivingFreq);	
			   LIS_CliffDiving_Date.sendKeys(Cliff_DivingFreq);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Cliff_DivingFreq ","Adding LIS_Cliff_DivingFreq"); 	
			
			
			
			LIS_CliffDiving_Intention= driver.findElement(By.xpath(EApp_LandingPage.CliffDivingIntention));
				cell = sheet.getRow(6).getCell(163);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String CliffDiving_Intention = cell.getStringCellValue();
		       System.out.println(CliffDiving_Intention);	
			   LIS_CliffDiving_Intention.sendKeys(CliffDiving_Intention);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_CliffDiving_Intention ","Adding LIS_CliffDiving_Intention"); 	
//Platform and Springboard

			
				LIS_Toggle_Platform= driver.findElement(By.xpath(EApp_LandingPage.Platform));
							   LIS_Toggle_Platform.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_Platform ","clicking LIS_Toggle_Platform");
			
			
			LIS_PlatformComp= driver.findElement(By.xpath(EApp_LandingPage.PlatformComp));
				cell = sheet.getRow(6).getCell(167);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Platform_Comp = cell.getStringCellValue();
		       System.out.println(LIS_Platform_Comp);	
			   LIS_PlatformComp.sendKeys(LIS_Platform_Comp);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_PlatformComp ","Adding LIS_PlatformComp"); 
			
			
				LIS_PlatformLoc= driver.findElement(By.xpath(EApp_LandingPage.PlatformLoc));
				cell = sheet.getRow(6).getCell(168);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Platform_Loc = cell.getStringCellValue();
		       System.out.println(LIS_Platform_Loc);	
			   LIS_PlatformLoc.sendKeys(LIS_Platform_Loc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_PlatformLoc ","Adding LIS_PlatformLoc"); 
			
			
		LIS_PlatformDate= driver.findElement(By.xpath(EApp_LandingPage.PlatformDate));
				cell = sheet.getRow(6).getCell(169);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Platform_Date = cell.getStringCellValue();
		       System.out.println(LIS_Platform_Date);	
			   LIS_PlatformDate.sendKeys(LIS_Platform_Date);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_PlatformDate ","Adding LIS_PlatformDate"); 
			
		LIS_PlatformFreq= driver.findElement(By.xpath(EApp_LandingPage.PlatformFreq));
				cell = sheet.getRow(6).getCell(170);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_Platform_Freq = cell.getStringCellValue();
		       System.out.println(LIS_Platform_Freq);	
			   LIS_PlatformFreq.sendKeys(LIS_Platform_Freq);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_PlatformFreq ","Adding LIS_PlatformFreq"); 
			
		LIS_Platform_Intention= driver.findElement(By.xpath(EApp_LandingPage.PlatformIntention));
				cell = sheet.getRow(6).getCell(171);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_PlatformIntention = cell.getStringCellValue();
		       System.out.println(LIS_PlatformIntention);	
			   LIS_Platform_Intention.sendKeys(LIS_PlatformIntention);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Platform_Intention ","Adding LIS_Platform_Intention"); 
			
			
		
//Diving Certificcations Questions

			LIS_Toggle_Yes6= driver.findElement(By.xpath(EApp_LandingPage.Platform));
				LIS_Toggle_Yes6.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_DivingQuestion ","clicking LIS_Toggle_DivingQuestion");
			
			LIS_Diving_Qualification= driver.findElement(By.xpath(EApp_LandingPage.DivingQualification));
				cell = sheet.getRow(6).getCell(173);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingQualification = cell.getStringCellValue();
		       System.out.println(LIS_DivingQualification);	
			   LIS_Diving_Qualification.sendKeys(LIS_DivingQualification);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingQualification ","Adding LIS_DivingQualification");
			
			
			LIS_DivingQualificationObtained_Date= driver.findElement(By.xpath(EApp_LandingPage.DivingQualificationObtainedDate));
				cell = sheet.getRow(6).getCell(174);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingQualificationObtainedDate = cell.getStringCellValue();
		       System.out.println(LIS_DivingQualificationObtainedDate);	
			   LIS_DivingQualificationObtained_Date.sendKeys(LIS_DivingQualificationObtainedDate);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingQualificationObtained_Date ","Adding LIS_DivingQualificationObtained_Date");
			
			
			LIS_DivingQualification_Add= driver.findElement(By.xpath(EApp_LandingPage.DivingQualificationAdd));
				cell = sheet.getRow(6).getCell(175);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingQualificationAdd = cell.getStringCellValue();
		       System.out.println(LIS_DivingQualificationAdd);	
			   LIS_DivingQualification_Add.sendKeys(LIS_DivingQualificationAdd);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingQualification_Add ","Adding LIS_DivingQualification_Add");
			
//Driving History
			LIS_DivingAvgDepth= driver.findElement(By.xpath(EApp_LandingPage.DivingAvgDepth));
				LIS_DivingAvgDepth.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_DivingAvgDepth ","clicking LIS_DivingAvgDepth");
			
			
			LIS_DivingAvgDepthLoc= driver.findElement(By.xpath(EApp_LandingPage.DivingAvgDepthLoc));
				cell = sheet.getRow(6).getCell(177);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingAvgDepth_Loc = cell.getStringCellValue();
		       System.out.println(LIS_DivingAvgDepth_Loc);	
			   LIS_DivingAvgDepthLoc.sendKeys(LIS_DivingAvgDepth_Loc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingAvgDepthLoc ","Adding LIS_DivingAvgDepthLoc");
			
			
			LIS_DivingAvgDepth_LastMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingAvgDepthLastMonth));
				cell = sheet.getRow(6).getCell(178);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingAvgDepthLastMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingAvgDepthLastMonth);	
			   LIS_DivingAvgDepth_LastMonth.sendKeys(LIS_DivingAvgDepthLastMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingAvgDepth_LastMonth ","Adding LIS_DivingAvgDepth_LastMonth");
			
			
			LIS_DivingAvgDepth_NextMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingAvgDepthNextMonth));
				cell = sheet.getRow(6).getCell(179);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingAvgDepthNextMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingAvgDepthNextMonth);	
			   LIS_DivingAvgDepth_NextMonth.sendKeys(LIS_DivingAvgDepthNextMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingAvgDepth_NextMonth ","Adding LIS_DivingAvgDepth_NextMonth");
			
			LIS_DivingMax_Depth= driver.findElement(By.xpath(EApp_LandingPage.DivingMaxDepth));
				LIS_DivingMax_Depth.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_DivingMax_Depth ","clicking LIS_DivingMax_Depth");
			
			
			LIS_DivingMaxDepth_Loc= driver.findElement(By.xpath(EApp_LandingPage.DivingMaxDepthLoc));
				cell = sheet.getRow(6).getCell(181);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingMaxDepthLoc = cell.getStringCellValue();
		       System.out.println(LIS_DivingMaxDepthLoc);	
			   LIS_DivingMaxDepth_Loc.sendKeys(LIS_DivingMaxDepthLoc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingMaxDepth_Loc ","Adding LIS_DivingMaxDepth_Loc");
			
			LIS_DivingMaxDepth_LastMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingMaxDepthLastMonth));
				cell = sheet.getRow(6).getCell(182);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingMaxDepthLastMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingMaxDepthLastMonth);	
			   LIS_DivingMaxDepth_LastMonth.sendKeys(LIS_DivingMaxDepthLastMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingMaxDepthLastMonth ","Adding LIS_DivingMaxDepthLastMonth");
			
			LIS_DivingmaxDepth_NextMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingmaxDepthNextMonth));
				cell = sheet.getRow(6).getCell(183);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingmaxDepthNextMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingmaxDepthNextMonth);	
			   LIS_DivingmaxDepth_NextMonth.sendKeys(LIS_DivingmaxDepthNextMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingmaxDepth_NextMonth ","Adding LIS_DivingmaxDepth_NextMonth");
			
			
		LIS_Divingnumb= driver.findElement(By.xpath(EApp_LandingPage.Divingnumb));
		LIS_Divingnumb.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Number_of_Dives ","clicking LIS_Number_of_Dives");
			
			LIS_DivingNumbLoc= driver.findElement(By.xpath(EApp_LandingPage.DivingNumbLoc));
				cell = sheet.getRow(6).getCell(184);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingNumb_Loc = cell.getStringCellValue();
		       System.out.println(LIS_DivingNumb_Loc);	
			   LIS_DivingNumbLoc.sendKeys(LIS_DivingNumb_Loc);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingNumbLoc ","Adding LIS_DivingNumbLoc");
			
				LIS_DivingNumb_LastMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingNumbLastMonth));
				cell = sheet.getRow(6).getCell(185);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingNumbLastMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingNumbLastMonth);	
			   LIS_DivingNumb_LastMonth.sendKeys(LIS_DivingNumbLastMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingNumbLastMonth ","Adding LIS_DivingNumbLastMonth");
			
				LIS_DivingNumb_NextMonth= driver.findElement(By.xpath(EApp_LandingPage.DivingNumbNextMonth));
				cell = sheet.getRow(6).getCell(186);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DivingNumbNextMonth = cell.getStringCellValue();
		       System.out.println(LIS_DivingNumbNextMonth);	
			   LIS_DivingNumb_NextMonth.sendKeys(LIS_DivingNumbNextMonth);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DivingNumb_NextMonth ","Adding LIS_DivingNumb_NextMonth");
					
			
// Medical Incidents
			
			LIS_Toggle_Incident_Yes7= driver.findElement(By.xpath(EApp_LandingPage.Toggle_Yes7));
				LIS_Toggle_Incident_Yes7.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_Incident_Yes7 ","clicking LIS_Toggle_Incident_Yes7");
			
			
				LIS_Dive_Incident= driver.findElement(By.xpath(EApp_LandingPage.DiveIncident));
				cell = sheet.getRow(6).getCell(187);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DiveIncident = cell.getStringCellValue();
		       System.out.println(LIS_DiveIncident);	
			   LIS_Dive_Incident.sendKeys(LIS_DiveIncident);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_Dive_Incident ","Adding LIS_Dive_Incident");
			
			
				LIS_DiveIncident_Date= driver.findElement(By.xpath(EApp_LandingPage.DiveIncidentDate));
				cell = sheet.getRow(6).getCell(188);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DiveIncidentDate = cell.getStringCellValue();
		       System.out.println(LIS_DiveIncidentDate);	
			   LIS_DiveIncident_Date.sendKeys(LIS_DiveIncidentDate);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DiveIncident_Date ","Adding LIS_DiveIncident_Date");
			
//Additional Information
			
			LIS_Toggle_Additional= driver.findElement(By.xpath(EApp_LandingPage.Toggle_Yes8));
				LIS_Toggle_Additional.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Toggle_Additional ","clicking LIS_Toggle_Additional");
			
		LIS_DDiveAddInfo= driver.findElement(By.xpath(EApp_LandingPage.DiveAddInfo));
				cell = sheet.getRow(6).getCell(190);
		       cell.setCellType(Cell.CELL_TYPE_STRING);
		       String LIS_DDiveAdd_Info = cell.getStringCellValue();
		       System.out.println(LIS_DDiveAdd_Info);	
			   LIS_DDiveAddInfo.sendKeys(LIS_DDiveAdd_Info);
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("Adding LIS_DDiveAddInfo ","Adding LIS_DDiveAddInfo");
			
			LIS_Diving_MandateSubmit= driver.findElement(By.xpath(EApp_LandingPage.Diving_Mandate_Submit));
				LIS_Diving_MandateSubmit.click();
			   Thread.sleep(2000);
			Extent_Reporting.Log_Pass("clicking LIS_Diving_MandateSubmit ","clicking LIS_Diving_MandateSubmit");
						}
						catch(Exception e)
						{
							Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							e.printStackTrace();
						}
						}
					
					
					@SuppressWarnings("deprecation")
					public void LifeStyle_MedicalDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(4);		
					

								LIS_Toggle_NarcoticSubstance_Yes= driver.findElement(By.xpath(EApp_LandingPage.Toggle20));
								LIS_Toggle_NarcoticSubstance_Yes.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("clicking LIS_Toggle_NarcoticSubstance_Yes ","clicking LIS_Toggle_NarcoticSubstance_Yes");
							
						LIS_NarcoticsInfo= driver.findElement(By.xpath(EApp_LandingPage.NarcoticsInfo));
								cell = sheet.getRow(6).getCell(193);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_Narcotics_Info = cell.getStringCellValue();
						       System.out.println(LIS_Narcotics_Info);	
							   LIS_NarcoticsInfo.sendKeys(LIS_Narcotics_Info);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NarcoticsInfo ","Adding LIS_NarcoticsInfo");
							
			//Alcohol Mandate
			
			
						LIS_Toggle_AlcoholMandate_Yes= driver.findElement(By.xpath(EApp_LandingPage.Toggle21));
								LIS_Toggle_AlcoholMandate_Yes.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("clicking LIS_Toggle_AlcoholMandate_Yes ","clicking LIS_Toggle_AlcoholMandate_Yes");
							
								LIS_AlcoBeerSel= driver.findElement(By.xpath(EApp_LandingPage.AlcoBeerSel));
								LIS_AlcoBeerSel.click();
								Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoBeer_Sel ","Adding LIS_AlcoBeer_Sel");
							
								
							LIS_AlcoBeerQuant= driver.findElement(By.xpath(EApp_LandingPage.AlcoBeerQuant));
								cell = sheet.getRow(6).getCell(197);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String AlcoBeer_Quant = cell.getStringCellValue();
						       System.out.println(AlcoBeer_Quant);	
							   LIS_AlcoBeerQuant.sendKeys(AlcoBeer_Quant);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoBeerQuant ","Adding LIS_AlcoBeerQuant");
							
							
						LIS_AlcoWine_Sel= driver.findElement(By.xpath(EApp_LandingPage.AlcoWineSel));
								LIS_AlcoWine_Sel.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoWine_Sel ","Adding LIS_AlcoWine_Sel");
							
							LIS_AlcoWineQuant= driver.findElement(By.xpath(EApp_LandingPage.AlcoWineQuant));
								cell = sheet.getRow(6).getCell(200);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String AlcoWine_Quant = cell.getStringCellValue();
						       System.out.println(AlcoWine_Quant);	
							   LIS_AlcoWineQuant.sendKeys(AlcoWine_Quant);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoWineQuant ","Adding LIS_AlcoWineQuant");
							
							
							LIS_Alcoliquor= driver.findElement(By.xpath(EApp_LandingPage.Alcoliquor));
								LIS_Alcoliquor.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_Alcoliquor ","Adding LIS_Alcoliquor");
							
							LIS_AlcoliquorQuant= driver.findElement(By.xpath(EApp_LandingPage.AlcoliquorQuant));
								cell = sheet.getRow(6).getCell(202);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LISAlcoliquorQuant = cell.getStringCellValue();
						       System.out.println(LISAlcoliquorQuant);	
							   LIS_AlcoliquorQuant.sendKeys(LISAlcoliquorQuant);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoliquorQuant ","Adding LIS_AlcoliquorQuant");
							
							//Consult doctor
							LIS_Alco_ConsultYes= driver.findElement(By.xpath(EApp_LandingPage.Alco_Consult_Yes));
								LIS_Alco_ConsultYes.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_Alco_ConsultYes ","Adding LIS_Alco_ConsultYes");
							
							LIS_AlcoDoc_Nam= driver.findElement(By.xpath(EApp_LandingPage.AlcoDocNam));
								cell = sheet.getRow(6).getCell(204);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String AlcoDoc_Nam = cell.getStringCellValue();
						       System.out.println(AlcoDoc_Nam);	
							   LIS_AlcoDoc_Nam.sendKeys(AlcoDoc_Nam);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoDoc_Nam ","Adding LIS_AlcoDoc_Nam");
							
							LIS_AlcoIntakeReason= driver.findElement(By.xpath(EApp_LandingPage.AlcoIntakeReason));
								cell = sheet.getRow(6).getCell(205);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_AlcoIntake_Reason = cell.getStringCellValue();
						       System.out.println(LIS_AlcoIntake_Reason);	
							   LIS_AlcoIntakeReason.sendKeys(LIS_AlcoIntake_Reason);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoIntakeReason ","Adding LIS_AlcoIntakeReason");
							
									LIS_AlcoTreatmntDate= driver.findElement(By.xpath(EApp_LandingPage.AlcoTreatmntDate));
								cell = sheet.getRow(6).getCell(206);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_AlcoTreatmnt_Date = cell.getStringCellValue();
						       System.out.println(LIS_AlcoTreatmnt_Date);	
							   LIS_AlcoTreatmntDate.sendKeys(LIS_AlcoTreatmnt_Date);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoTreatmnt_Date ","Adding LIS_AlcoTreatmnt_Date");
							
								LIS_AlcoholTreatmntAdd= driver.findElement(By.xpath(EApp_LandingPage.AlcoholTreatmntAdd));
								LIS_AlcoholTreatmntAdd.click();
							Extent_Reporting.Log_Pass("Adding LIS_AlcoholTreatmntAdd ","Adding LIS_AlcoholTreatmntAdd");
							
			//Alcohol Anonymous
			
								LIS_Toggle_Alcohol_Anonymous= driver.findElement(By.xpath(EApp_LandingPage.Toggle_Alcohol_Anonymous));
								LIS_Toggle_Alcohol_Anonymous.click();
							Extent_Reporting.Log_Pass("Adding LIS_Toggle_Alcohol_Anonymous ","Adding LIS_Toggle_Alcohol_Anonymous");
							
							
			// Alcohol Additional
			
							LIS_Toggle_Yes11= driver.findElement(By.xpath(EApp_LandingPage.Toggle_Yes11));
								LIS_Toggle_Yes11.click();
							Extent_Reporting.Log_Pass("Adding LIS_Toggle_Alcohol_Additional ","Adding LIS_Toggle_Alcohol_Additional");
			
							LIS_AlcoAdd_Info= driver.findElement(By.xpath(EApp_LandingPage.AlcoAddInfo));
								cell = sheet.getRow(6).getCell(210);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_Alco_Add_Info = cell.getStringCellValue();
						       System.out.println(LIS_Alco_Add_Info);	
							   LIS_AlcoAdd_Info.sendKeys(LIS_Alco_Add_Info);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_Alco_Add_Info ","Adding LIS_Alco_Add_Info");
							
							LIS_AlcoMandate_Submit= driver.findElement(By.xpath(EApp_LandingPage.AlcoMandate_Submit));
								LIS_AlcoMandate_Submit.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_AlcoMandateSubmit ","Adding LIS_AlcoMandateSubmit");
			
			//Nicotine Questions
			
				LIS_Toggle_Yes22= driver.findElement(By.xpath(EApp_LandingPage.Toggle22_Yes));
								LIS_Toggle_Yes22.click();
							Extent_Reporting.Log_Pass("Adding LIS_Toggle_Alcohol_Additional ","Adding LIS_Toggle_Alcohol_Additional");
							
							LIS_NicotineCigSel= driver.findElement(By.xpath(EApp_LandingPage.NicotineCigSel));
							   LIS_NicotineCigSel.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineCigSel ","Adding LIS_NicotineCigSel");
							
							
							LIS_NicotineCigPerDay= driver.findElement(By.xpath(EApp_LandingPage.NicotineCigPerDay));
								cell = sheet.getRow(6).getCell(214);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineCig_PerDay = cell.getStringCellValue();
						       System.out.println(LIS_NicotineCig_PerDay);	
							   LIS_NicotineCigPerDay.sendKeys(LIS_NicotineCig_PerDay);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineCig_PerDay ","Adding LIS_NicotineCig_PerDay");
			
							LIS_NicotineCigNoOfYear= driver.findElement(By.xpath(EApp_LandingPage.NicotineCigNoOfYear));
								cell = sheet.getRow(6).getCell(215);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineCig_NoOfYear = cell.getStringCellValue();
						       System.out.println(LIS_NicotineCig_NoOfYear);	
							   LIS_NicotineCigNoOfYear.sendKeys(LIS_NicotineCig_NoOfYear);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineCig_NoOfYear ","Adding LIS_NicotineCig_NoOfYear");
			
							
							LIS_NicotineBidiSel= driver.findElement(By.xpath(EApp_LandingPage.NicotineBidiSel));
							   LIS_NicotineBidiSel.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineBidiSel ","Adding LIS_NicotineBidiSel");
							
							LIS_NicotineBidiPerDay= driver.findElement(By.xpath(EApp_LandingPage.NicotineBidiPerDay));
								cell = sheet.getRow(6).getCell(217);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineBidi_PerDay = cell.getStringCellValue();
						       System.out.println(LIS_NicotineBidi_PerDay);	
							   LIS_NicotineBidiPerDay.sendKeys(LIS_NicotineBidi_PerDay);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineBidiPerDay ","Adding LIS_NicotineBidiPerDay");
							
							
							LIS_NicotineBidiNoOfYear= driver.findElement(By.xpath(EApp_LandingPage.NicotineBidiNoOfYear));
								cell = sheet.getRow(6).getCell(218);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineBidi_NoOfYear = cell.getStringCellValue();
						       System.out.println(LIS_NicotineBidi_NoOfYear);	
							   LIS_NicotineBidiNoOfYear.sendKeys(LIS_NicotineBidi_NoOfYear);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineCig_NoOfYear ","Adding LIS_NicotineCig_NoOfYear");
							
							LIS_NicotinePaanSel= driver.findElement(By.xpath(EApp_LandingPage.NicotinePaanSel));
							   LIS_NicotinePaanSel.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotinePaanSel ","Adding LIS_NicotinePaanSel");
							
							LIS_NicotinePaanPerDay= driver.findElement(By.xpath(EApp_LandingPage.NicotinePaanPerDay));
								cell = sheet.getRow(6).getCell(220);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotinePaan_PerDay = cell.getStringCellValue();
						       System.out.println(LIS_NicotinePaan_PerDay);	
							   LIS_NicotinePaanPerDay.sendKeys(LIS_NicotinePaan_PerDay);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotinePaanPerDay ","Adding LIS_NicotinePaanPerDay");
							
							
							LIS_NicotinePaan_NoOfYear= driver.findElement(By.xpath(EApp_LandingPage.NicotinePaanNoOfYear));
								cell = sheet.getRow(6).getCell(221);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotinePaanNoOfYear = cell.getStringCellValue();
						       System.out.println(LIS_NicotinePaanNoOfYear);	
							   LIS_NicotinePaan_NoOfYear.sendKeys(LIS_NicotinePaanNoOfYear);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotinePaan_NoOfYear ","Adding LIS_NicotinePaan_NoOfYear");
							
							
							LIS_NicotineTobaccoSel= driver.findElement(By.xpath(EApp_LandingPage.NicotineTobaccoSel));
							   LIS_NicotineTobaccoSel.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineTobaccoSel ","Adding LIS_NicotineTobaccoSel");
							
							LIS_NicotineTobaccoPerDay= driver.findElement(By.xpath(EApp_LandingPage.NicotineTobaccoPerDay));
								cell = sheet.getRow(6).getCell(222);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineTobacco_PerDay = cell.getStringCellValue();
						       System.out.println(LIS_NicotineTobacco_PerDay);	
							   LIS_NicotineTobaccoPerDay.sendKeys(LIS_NicotineTobacco_PerDay);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineTobaccoPerDay ","Adding LIS_NicotineTobaccoPerDay");
							
							
							LIS_NicotineTobacco_NoOfYear= driver.findElement(By.xpath(EApp_LandingPage.NicotineTobaccoNoOfYear));
								cell = sheet.getRow(6).getCell(223);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_NicotineTobaccoNoOfYear = cell.getStringCellValue();
						       System.out.println(LIS_NicotineTobaccoNoOfYear);	
							   LIS_NicotineTobacco_NoOfYear.sendKeys(LIS_NicotineTobaccoNoOfYear);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_NicotineTobaccoNoOfYear ","Adding LIS_NicotineTobaccoNoOfYear");
							
							
						
							LIS_Toggle_Suggestion_Physician = driver.findElement(By.xpath(EApp_LandingPage.Toggle_Suggestion_Physician));
							   LIS_Toggle_Suggestion_Physician.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_Toggle_Suggestion_Physician ","Adding LIS_Toggle_Suggestion_Physician");
							
							
							LIS_Suggestion_Physician_Info= driver.findElement(By.xpath(EApp_LandingPage.Suggestion_Physician_Info));
								cell = sheet.getRow(6).getCell(225);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String LIS_Suggestion_PhysicianInfo = cell.getStringCellValue();
						       System.out.println(LIS_Suggestion_PhysicianInfo);	
							   LIS_Suggestion_Physician_Info.sendKeys(LIS_Suggestion_PhysicianInfo);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding LIS_Suggestion_PhysicianInfo ","Adding LIS_Suggestion_PhysicianInfo");
							
						}
						catch(Exception e)
						{
							Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							e.printStackTrace();
						}
						}
			   
					
			@SuppressWarnings("deprecation")
					public void LifeStyle_FamilyMedicalDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(4);	
					
							//Family Medical History

								FMH_PlusSign9= driver.findElement(By.xpath(EApp_LandingPage.PlusSign9));
							   FMH_PlusSign9.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_PlusSign9 ","Adding FMH_PlusSign9");
							
							
							FMH_HereditaryDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_Hereditary));
								FMH_HereditaryDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_Hereditary_Disorder ","Adding FMH_Hereditary_Disorder");
							
							
							FMH_HereditaryDisorderinfo= driver.findElement(By.xpath(EApp_LandingPage.FMH_HereditaryDetails));
								cell = sheet.getRow(6).getCell(228);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FMH_HereditaryDisorder_info = cell.getStringCellValue();
						       System.out.println(FMH_HereditaryDisorder_info);	
							   FMH_HereditaryDisorderinfo.sendKeys(FMH_HereditaryDisorder_info);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_HereditaryDisorder_info ","Adding FMH_HereditaryDisorder_info");
							
							FMH_ChronicDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_Chronic));
								FMH_ChronicDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_ChronicDisorder ","Adding FMH_ChronicDisorder");
							
								FMH_HeartDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_Heart));
								FMH_HeartDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_HeartDisorder ","Adding FMH_HeartDisorder");
							
								FMH_HBPDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_BP));
								FMH_HBPDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_HBPDisorder ","Adding FMH_HBPDisorder");
							
								FMH_CancerDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_Cancer));
								FMH_CancerDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_CancerDisorder ","Adding FMH_CancerDisorder");
							
							FMH_DiabetesDisorder= driver.findElement(By.xpath(EApp_LandingPage.FMH_Diabetes));
								FMH_DiabetesDisorder.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_DiabetesDisorder ","Adding FMH_DiabetesDisorder");
							
							
			//Living Details
			
					FMH_Living_FatherAge= driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
								cell = sheet.getRow(6).getCell(234);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FMH_Hereditary_Disorder_info = cell.getStringCellValue();
						       System.out.println(FMH_Hereditary_Disorder_info);	
							   FMH_Living_FatherAge.sendKeys(FMH_Hereditary_Disorder_info);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_HereditaryDisorder_info ","Adding FMH_HereditaryDisorder_info");
							
					FMH_Living_FatherHealthState= driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
								cell = sheet.getRow(6).getCell(236);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FMH_Living_Father_HealthState = cell.getStringCellValue();
						       System.out.println(FMH_Living_Father_HealthState);	
							  Select Living_Father_Health_State = new Select(FMH_Living_FatherHealthState);
								Living_Father_Health_State.selectByValue("0");
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_Living_Father_HealthState ","Adding FMH_Living_Father_HealthState");
							
					FMH_Living_MotherAge= driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
								cell = sheet.getRow(6).getCell(239);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FMH_Living_Mother_Age = cell.getStringCellValue();
						       System.out.println(FMH_Living_Mother_Age);	
							   FMH_Living_MotherAge.sendKeys(FMH_Living_Mother_Age);
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_Living_MotherAge ","Adding FMH_Living_MotherAge");
							
					FMH_Living_MotherHealthState= driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
								cell = sheet.getRow(6).getCell(241);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String FMH_Living_FatherHealth_State = cell.getStringCellValue();
						       System.out.println(FMH_Living_FatherHealth_State);	
							  Select FMH_Living_MotherHealth_State1 = new Select(FMH_Living_MotherHealthState);
								FMH_Living_MotherHealth_State1.selectByValue("0");
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Adding FMH_Living_Father_HealthState ","Adding FMH_Living_Father_HealthState");
							
							
						FMH_Toggle23_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle23));
								FMH_Toggle23_No.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Clicking FMH_BrothersHealth_No ","clicking FMH_BrothersHealth_No");
							
							
						FMH_Toggle24_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle24));
								FMH_Toggle24_No.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("clicking FMH_SistersHealth_No ","clicking FMH_SistersHealth_No");
						
						}
						catch(Exception e)
						{
							Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
							e.printStackTrace();
						}
						}
					
			
			public void LifeStyle_HealthMandateDetails_Same_Medical(WebDriver driver) throws IOException, InterruptedException {
					try {
					FileInputStream finput = new FileInputStream(src);
					  workbook = new XSSFWorkbook(finput);
					  sheet= workbook.getSheetAt(4);	
					  
						
						//Medical History
						
								MH_Toggle_MedicalHistory= driver.findElement(By.xpath(EApp_LandingPage.PlusSign10));
										MH_Toggle_MedicalHistory.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Toggle_MedicalHistory ","clicking MH_Toggle_MedicalHistory");
									
								MH_RA_Symptoms_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle25));
										MH_RA_Symptoms_No.click();
										Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_RA_Symptoms_No ","clicking MH_RA_Symptoms_No");
									
								MH_Clinic_Investigation_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle26));
										MH_Clinic_Investigation_No.click();
										Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Clinic_Investigation_No ","clicking MH_Clinic_Investigation_No");
									
								MH_IsOnDiet_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle27));
										MH_IsOnDiet_No.click();
										Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_IsOnDiet_No ","clicking MH_IsOnDiet_No");
									
									//Scroll
				                JavascriptExecutor jse28 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								MH_UT_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle28));
										MH_UT_No.click();
										Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_UT_No ","clicking MH_UT_No");
								
								MH_AS_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle29));
										MH_AS_No.click();
										Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_AS_No ","clicking MH_AS_No");
									
								//Chest Pain
								//Scroll
				                JavascriptExecutor jse50 = (JavascriptExecutor)driver;
				                jse50.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								
								MH_Chestpain_MedicalHistory= driver.findElement(By.xpath(EApp_LandingPage.Chestpain));
										MH_Chestpain_MedicalHistory.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_MedicalHistory ","clicking MH_Chestpain_MedicalHistory");
									
									
									
								MH_Chestpain_angina= driver.findElement(By.xpath(EApp_LandingPage.angina));
										MH_Chestpain_angina.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_angina ","clicking MH_Chestpain_angina");
									
									
									
									MH_Chestpain_Date= driver.findElement(By.xpath(EApp_LandingPage.date_ChestPain));
										cell = sheet.getRow(6).getCell(293);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ChestpainDate = cell.getStringCellValue();
								       System.out.println(MH_ChestpainDate);	
									   MH_Chestpain_Date.sendKeys(MH_ChestpainDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_Date ","Adding MH_Chestpain_Date");
									
									MH_Chestpain_recurrenceinfo= driver.findElement(By.xpath(EApp_LandingPage.recurrenceinfo_yes));
										cell = sheet.getRow(6).getCell(294);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpainrecurrenceinfo = cell.getStringCellValue();
								       System.out.println(MH_Chestpainrecurrenceinfo);	
									   MH_Chestpain_recurrenceinfo.sendKeys(MH_Chestpainrecurrenceinfo);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_recurrenceinfo ","Adding MH_Chestpain_recurrenceinfo ");
									
									
								MH_Chestpain_recurrence_notebox= driver.findElement(By.xpath(EApp_LandingPage.recurrence_notebox));
										cell = sheet.getRow(6).getCell(295);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_recurrencenotebox = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_recurrencenotebox);	
									   MH_Chestpain_recurrence_notebox.sendKeys(MH_Chestpain_recurrencenotebox);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_recurrence_notebox ","Adding MH_Chestpain_recurrenceinfo ");
									
									
									MH_Chestpain_investigations_yes= driver.findElement(By.xpath(EApp_LandingPage.investigations_yes));
										MH_Chestpain_investigations_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_investigations_yes ","clicking MH_Chestpain_investigations_yes");
									
									
									
									MH_Chestpain_investigation_box= driver.findElement(By.xpath(EApp_LandingPage.investigation_box));
										cell = sheet.getRow(6).getCell(297);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_investigationbox = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_investigationbox);	
									   MH_Chestpain_investigation_box.sendKeys(MH_Chestpain_investigationbox);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_investigation_box ","Adding MH_Chestpain_investigation_box ");
									
										MH_Chestpain_investigation_date= driver.findElement(By.xpath(EApp_LandingPage.investigation_date));
										cell = sheet.getRow(6).getCell(298);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_investigationdate = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_investigationdate);	
									   MH_Chestpain_investigation_date.sendKeys(MH_Chestpain_investigationdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_investigation_date ","Adding MH_Chestpain_investigation_date ");
									
										MH_Chestpain_investigation_results= driver.findElement(By.xpath(EApp_LandingPage.investigation_results));
										cell = sheet.getRow(6).getCell(299);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpaininvestigation_results = cell.getStringCellValue();
								       System.out.println(MH_Chestpaininvestigation_results);	
									   MH_Chestpain_investigation_results.sendKeys(MH_Chestpaininvestigation_results);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_investigation_results ","Adding MH_Chestpain_investigation_results ");
									
										MH_Chestpain_investigation_add= driver.findElement(By.xpath(EApp_LandingPage.investigation_add));
										MH_Chestpain_investigation_add.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_investigation_add ","clicking MH_Chestpain_investigation_add");
									
					//Scroll
				                JavascriptExecutor jse49 = (JavascriptExecutor)driver;
				                jse49.executeScript("window.scrollBy(0,150)", "");
				                Thread.sleep(2000);
									
									
									MH_Chestpain_medication_taken_Yes= driver.findElement(By.xpath(EApp_LandingPage.medication_taken_Yes));
										MH_Chestpain_medication_taken_Yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_medication_taken_Yes ","clicking MH_Chestpain_medication_taken_Yes");
									
									MH_Chestpain_medication_box= driver.findElement(By.xpath(EApp_LandingPage.medication_box));
										cell = sheet.getRow(6).getCell(300);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_medicationbox = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_medicationbox);	
									   MH_Chestpain_medication_box.sendKeys(MH_Chestpain_medicationbox);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_investigation_results ","Adding MH_Chestpain_investigation_results ");
									
									MH_Chestpain_medication_dose= driver.findElement(By.xpath(EApp_LandingPage.medication_dose));
										cell = sheet.getRow(6).getCell(301);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_medicationdose = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_medicationdose);	
									   MH_Chestpain_medication_dose.sendKeys(MH_Chestpain_medicationdose);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_medication_dose ","Adding MH_Chestpain_medication_dose ");
									
									MH_Chestpain_medication_date= driver.findElement(By.xpath(EApp_LandingPage.medication_date));
										cell = sheet.getRow(6).getCell(302);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_medicationdate = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_medicationdate);	
									   MH_Chestpain_medication_date.sendKeys(MH_Chestpain_medicationdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_medication_date ","Adding MH_Chestpain_medication_date ");
									
									MH_Chestpain_medication_ADD= driver.findElement(By.xpath(EApp_LandingPage.medication_ADD));
										MH_Chestpain_medication_ADD.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_medication_ADD ","clicking MH_Chestpain_medication_ADD");
									
									
										MH_Chestpain_patient_treatmentYes= driver.findElement(By.xpath(EApp_LandingPage.patient_treatmentYes));
										MH_Chestpain_patient_treatmentYes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_patient_treatmentYes ","clicking MH_Chestpain_patient_treatmentYes");
									
									MH_Chestpain_admitted_to_hospital_details= driver.findElement(By.xpath(EApp_LandingPage.admitted_to_hospital_details));
										cell = sheet.getRow(6).getCell(300);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_admitted_tohospitaldetails = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_admitted_tohospitaldetails);	
									   MH_Chestpain_admitted_to_hospital_details.sendKeys(MH_Chestpain_admitted_tohospitaldetails);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_admitted_to_hospital_details ","Adding MH_Chestpain_admitted_to_hospital_details ");
									
									MH_Chestpain_admitted_to_hospital= driver.findElement(By.xpath(EApp_LandingPage.admitted_to_hospital));
										cell = sheet.getRow(6).getCell(301);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_admittedtohospital = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_admittedtohospital);	
									   MH_Chestpain_admitted_to_hospital.sendKeys(MH_Chestpain_admittedtohospital);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_admitted_to_hospital ","Adding MH_Chestpain_admitted_to_hospital ");
									
									MH_Chestpain_admitted_date = driver.findElement(By.xpath(EApp_LandingPage.admitted_date));
										cell = sheet.getRow(6).getCell(302);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_admitteddate = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_admitteddate);	
									   MH_Chestpain_admitted_date.sendKeys(MH_Chestpain_admitteddate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_admitted_date ","Adding MH_Chestpain_admitted_date ");
									
									
										MH_Chestpain_admitted_add= driver.findElement(By.xpath(EApp_LandingPage.admitted_add));
										MH_Chestpain_admitted_add.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_admitted_add ","clicking MH_Chestpain_admitted_add");
									
									
									MH_Chestpain_treatment_followup_Yes= driver.findElement(By.xpath(EApp_LandingPage.treatment_followup_Yes));
										MH_Chestpain_treatment_followup_Yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_treatment_followup_Yes ","clicking MH_Chestpain_treatment_followup_Yes");
									
									
									MH_Chestpain_treatment_followup_details= driver.findElement(By.xpath(EApp_LandingPage.treatment_followup_details));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_treatment_followupdetails = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_treatment_followupdetails);	
									   MH_Chestpain_treatment_followup_details.sendKeys(MH_Chestpain_treatment_followupdetails);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_treatment_followup_details ","Adding MH_Chestpain_treatment_followup_details ");
									
										MH_Chestpain_additional_information_Yes_chestPain= driver.findElement(By.xpath(EApp_LandingPage.additional_information_yes_chestPain));
										MH_Chestpain_additional_information_Yes_chestPain.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_additional_information_Yes_chestPain ","clicking MH_Chestpain_additional_information_Yes_chestPain");
									
									
									MH_Chestpain_additonal_information_notes= driver.findElement(By.xpath(EApp_LandingPage.additonal_information_notes));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Chestpain_additonal_informationnotes = cell.getStringCellValue();
								       System.out.println(MH_Chestpain_additonal_informationnotes);	
									   MH_Chestpain_additonal_information_notes.sendKeys(MH_Chestpain_additonal_informationnotes);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Chestpain_additonal_information_notes ","Adding MH_Chestpain_additonal_information_notes ");
									
									
									MH_Chestpain_Submit= driver.findElement(By.xpath(EApp_LandingPage.Chestpain_Submit));
										MH_Chestpain_Submit.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Chestpain_Submit ","clicking MH_Chestpain_Submit");
									
					// Asthma

					//Scroll
				                JavascriptExecutor jse40 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
							Asthma_Checkbox= driver.findElement(By.xpath(EApp_LandingPage.AsthmaRadio));
										Asthma_Checkbox.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking Asthma_Checkbox ","clicking Asthma_Checkbox");
									
									
									MH_Asthma_condition= driver.findElement(By.xpath(EApp_LandingPage.condition));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthmacondition = cell.getStringCellValue();
								       System.out.println(MH_Asthmacondition);	
									   MH_Asthma_condition.sendKeys(MH_Asthmacondition);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_condition ","Adding MH_Asthma_condition ");
									
									MH_Asthma_diagnose_date= driver.findElement(By.xpath(EApp_LandingPage.diagnose_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_diagnosedate = cell.getStringCellValue();
								       System.out.println(MH_Asthma_diagnosedate);	
									   MH_Asthma_diagnose_date.sendKeys(MH_Asthma_diagnosedate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_diagnose_date ","Adding MH_Asthma_diagnose_date ");
									
									MH_Asthma_smoker_Yes= driver.findElement(By.xpath(EApp_LandingPage.smoker_Yes));
										MH_Asthma_smoker_Yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_smoker_Yes ","clicking MH_Asthma_smoker_Yes");
									
										MH_Asthma_smoker_Notes= driver.findElement(By.xpath(EApp_LandingPage.smoker_Notes));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_smokerNotes = cell.getStringCellValue();
								       System.out.println(MH_Asthma_smokerNotes);	
									   MH_Asthma_smoker_Notes.sendKeys(MH_Asthma_smokerNotes);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_smoker_Notes ","Adding MH_Asthma_smoker_Notes ");
									
									MH_Asthma_frequent_symptons= driver.findElement(By.xpath(EApp_LandingPage.frequent_symptons));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_frequentsymptons = cell.getStringCellValue();
								       System.out.println(MH_Asthma_frequentsymptons);	
									   MH_Asthma_frequent_symptons.sendKeys(MH_Asthma_frequentsymptons);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_frequent_symptons ","Adding MH_Asthma_frequent_symptons ");
									
										MH_Asthma_percipitated_symptomReasonInfo= driver.findElement(By.xpath(EApp_LandingPage.percipitated_symptomReasonInfo));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_percipitatedsymptomReasonInfo = cell.getStringCellValue();
								       System.out.println(MH_Asthma_percipitatedsymptomReasonInfo);	
									   MH_Asthma_percipitated_symptomReasonInfo.sendKeys(MH_Asthma_percipitatedsymptomReasonInfo);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_percipitated_symptomReasonInfo ","Adding MH_Asthma_percipitated_symptomReasonInfo ");
									
									MH_Asthma_last_sympton_date= driver.findElement(By.xpath(EApp_LandingPage.last_sympton_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_last_symptondate = cell.getStringCellValue();
								       System.out.println(MH_Asthma_last_symptondate);	
									   MH_Asthma_last_sympton_date.sendKeys(MH_Asthma_last_symptondate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_last_sympton_date ","Adding MH_Asthma_last_sympton_date ");
									
									
									//Scroll
				                JavascriptExecutor jse41 = (JavascriptExecutor)driver;
				                jse41.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
											MH_Asthma_other_treatment_Yess= driver.findElement(By.xpath(EApp_LandingPage.other_treatment_Yes));
										MH_Asthma_other_treatment_Yess.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_other_treatment_Yess ","clicking MH_Asthma_other_treatment_Yess");
									
									
									MH_Asthma_other_treatment_medication= driver.findElement(By.xpath(EApp_LandingPage.other_treatment_medication));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_other_treatmentmedication = cell.getStringCellValue();
								       System.out.println(MH_Asthma_other_treatmentmedication);	
									   MH_Asthma_other_treatment_medication.sendKeys(MH_Asthma_other_treatmentmedication);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_other_treatment_medication ","Adding MH_Asthma_other_treatment_medication ");
									
									
									
									MH_Asthma_other_treatment_Dose= driver.findElement(By.xpath(EApp_LandingPage.other_treatment_Dose));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_other_treatmentDose = cell.getStringCellValue();
								       System.out.println(MH_Asthma_other_treatmentDose);	
									   MH_Asthma_other_treatment_Dose.sendKeys(MH_Asthma_other_treatmentDose);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_other_treatment_Dose ","Adding MH_Asthma_other_treatment_Dose ");
									
									
									MH_Asthma_other_treatment_frequent= driver.findElement(By.xpath(EApp_LandingPage.other_treatment_frequent));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_other_treatmentfrequent = cell.getStringCellValue();
								       System.out.println(MH_Asthma_other_treatmentfrequent);	
									   MH_Asthma_other_treatment_frequent.sendKeys(MH_Asthma_other_treatmentfrequent);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_other_treatment_frequent ","Adding MH_Asthma_other_treatment_frequent ");
									
									
									MH_Asthma_other_treatment_ADD= driver.findElement(By.xpath(EApp_LandingPage.other_treatment_ADD));
										MH_Asthma_other_treatment_ADD.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_other_treatment_ADD ","clicking MH_Asthma_other_treatment_ADD");
									
									
									MH_Asthma_undergone_investogone_Yes= driver.findElement(By.xpath(EApp_LandingPage.undergone_investogone_Yes));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_undergone_investogoneYes = cell.getStringCellValue();
								       System.out.println(MH_Asthma_undergone_investogoneYes);	
									   MH_Asthma_undergone_investogone_Yes.sendKeys(MH_Asthma_undergone_investogoneYes);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_undergone_investogone_Yes ","Adding MH_Asthma_undergone_investogone_Yes ");
									
														
									MH_Asthma_undergone_investigone_notest= driver.findElement(By.xpath(EApp_LandingPage.undergone_investigone_notest));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_undergone_investigonenotest = cell.getStringCellValue();
								       System.out.println(MH_Asthma_undergone_investigonenotest);	
									   MH_Asthma_undergone_investigone_notest.sendKeys(MH_Asthma_undergone_investigonenotest);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_undergone_investigone_notest ","Adding MH_Asthma_undergone_investigone_notest ");
									
									
									MH_Asthma_doctors_name= driver.findElement(By.xpath(EApp_LandingPage.doctors_name));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_doctorsname = cell.getStringCellValue();
								       System.out.println(MH_Asthma_doctorsname);	
									   MH_Asthma_doctors_name.sendKeys(MH_Asthma_doctorsname);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_doctors_name ","Adding MH_Asthma_doctors_name ");
									
									
									MH_Asthma_doctors_address= driver.findElement(By.xpath(EApp_LandingPage.doctors_address));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_doctorsaddress = cell.getStringCellValue();
								       System.out.println(MH_Asthma_doctorsaddress);	
									   MH_Asthma_doctors_address.sendKeys(MH_Asthma_doctorsaddress);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_doctors_address ","Adding MH_Asthma_doctors_address ");
									
									
									
									MH_Asthma_doctors_date= driver.findElement(By.xpath(EApp_LandingPage.doctors_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_doctorsdate = cell.getStringCellValue();
								       System.out.println(MH_Asthma_doctorsdate);	
									   MH_Asthma_doctors_date.sendKeys(MH_Asthma_doctorsdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_doctors_date ","Adding MH_Asthma_doctors_date ");
									
											
									MH_Asthma_doctors_add= driver.findElement(By.xpath(EApp_LandingPage.doctors_add));
										MH_Asthma_doctors_add.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_doctors_add ","clicking MH_Asthma_doctors_add");
									
														
									MH_Asthma_time_off_work_Yes= driver.findElement(By.xpath(EApp_LandingPage.time_off_work_Yes));
										MH_Asthma_time_off_work_Yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_time_off_work_Yes ","clicking MH_Asthma_time_off_work_Yes");
									
									
									MH_Asthma_time_off_work_details = driver.findElement(By.xpath(EApp_LandingPage.time_off_work_details));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_time_off_workdetails = cell.getStringCellValue();
								       System.out.println(MH_Asthma_time_off_workdetails);	
									   MH_Asthma_time_off_work_details.sendKeys(MH_Asthma_time_off_workdetails);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_time_off_work_details ","Adding MH_Asthma_time_off_work_details");
									
														
											MH_Asthma_additional_information_yes= driver.findElement(By.xpath(EApp_LandingPage.additional_information_yes));
										MH_Asthma_additional_information_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_additional_information_yes ","clicking MH_Asthma_additional_information_yes");
									
									MH_Asthma_addtional_information_notes= driver.findElement(By.xpath(EApp_LandingPage.addtional_information_notes));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Asthma_addtionalinformation_notes = cell.getStringCellValue();
								       System.out.println(MH_Asthma_addtionalinformation_notes);	
									   MH_Asthma_addtional_information_notes.sendKeys(MH_Asthma_addtionalinformation_notes);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Asthma_addtional_information_notes ","Adding MH_Asthma_addtional_information_notes");
									
									MH_Asthma_Submit= driver.findElement(By.xpath(EApp_LandingPage.tick));
										MH_Asthma_Submit.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Asthma_Submit ","clicking MH_Asthma_Submit");
					//Diabtetic	
									
									//Scroll
				                JavascriptExecutor jse42 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
									
									
										MH_Diabtetic_Check= driver.findElement(By.xpath(EApp_LandingPage.DiabetesRadio));
										MH_Diabtetic_Check.click();
									   Thread.sleep(2000);
									   Extent_Reporting.Log_Pass("clicking MH_Diabtetic_Check ","clicking MH_Diabtetic_Check");
									
									
					
									MH_Diabtetic_detectdate= driver.findElement(By.xpath(EApp_LandingPage.detectdate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Diabteticdetectdate = cell.getStringCellValue();
								       System.out.println(MH_Diabteticdetectdate);	
									   MH_Diabtetic_detectdate.sendKeys(MH_Diabteticdetectdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Diabtetic_detectdate ","Adding MH_Diabtetic_detectdate");
									
									
									MH_Diabtetic_smokeoption_yes= driver.findElement(By.xpath(EApp_LandingPage.smokeoption_yes));
										MH_Diabtetic_smokeoption_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_smokeoption_yes ","clicking MH_Diabtetic_smokeoption_yes");
									
												
									MH_Diabtetic_diet_yes= driver.findElement(By.xpath(EApp_LandingPage.diet_yes));
										MH_Diabtetic_diet_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_diet_yes ","clicking MH_Diabtetic_diet_yes");
									
									//Scroll
				                JavascriptExecutor jse43 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
									
									MH_Diabtetic_checkbox1_HeartDisease= driver.findElement(By.xpath(EApp_LandingPage.checkbox1_HeartDisease));
										MH_Diabtetic_checkbox1_HeartDisease.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_checkbox1_HeartDisease ","clicking MH_Diabtetic_checkbox1_HeartDisease");
									
									
									MH_Diabtetic_textbox_HeartDisease= driver.findElement(By.xpath(EApp_LandingPage.textbox_HeartDisease));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Diabtetic_textboxHeartDisease = cell.getStringCellValue();
								       System.out.println(MH_Diabtetic_textboxHeartDisease);	
									   MH_Diabtetic_textbox_HeartDisease.sendKeys(MH_Diabtetic_textboxHeartDisease);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Diabtetic_textbox_HeartDisease ","Adding MH_Diabtetic_textbox_HeartDisease");
									
									
									MH_Diabtetic_checkbox2_Albumin= driver.findElement(By.xpath(EApp_LandingPage.checkbox2_Albumin));
										MH_Diabtetic_checkbox2_Albumin.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_checkbox2_Albumin ","clicking MH_Diabtetic_checkbox2_Albumin");
									
									
										MH_Diabtetic_textbox_Albumin= driver.findElement(By.xpath(EApp_LandingPage.textbox_Albumin));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Diabtetic_textboxAlbumin = cell.getStringCellValue();
								       System.out.println(MH_Diabtetic_textboxAlbumin);	
									   MH_Diabtetic_textbox_Albumin.sendKeys(MH_Diabtetic_textboxAlbumin);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Diabtetic_textbox_Albumin ","Adding MH_Diabtetic_textbox_Albumin");
									
									
									MH_Diabtetic_checkbox3_Blood_Pressure= driver.findElement(By.xpath(EApp_LandingPage.checkbox3_Blood_Pressure));
										MH_Diabtetic_checkbox3_Blood_Pressure.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_checkbox3_Blood_Pressure ","clicking MH_Diabtetic_checkbox3_Blood_Pressure");
									
									
									
										MH_Diabtetic_textbox_Blood_Pressure= driver.findElement(By.xpath(EApp_LandingPage.textbox_Blood_Pressure));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Diabtetic_textbox_BloodPressure = cell.getStringCellValue();
								       System.out.println(MH_Diabtetic_textbox_BloodPressure);	
									   MH_Diabtetic_textbox_Blood_Pressure.sendKeys(MH_Diabtetic_textbox_BloodPressure);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Diabtetic_textbox_Blood_Pressure ","Adding MH_Diabtetic_textbox_Blood_Pressure");
									
								
									MH_Diabtetic_add_Info_yes= driver.findElement(By.xpath(EApp_LandingPage.add_Info_yes));
										MH_Diabtetic_add_Info_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabtetic_add_Info_yes ","clicking MH_Diabtetic_add_Info_yes");
									
								
									MH_Diabtetic_addinfobox= driver.findElement(By.xpath(EApp_LandingPage.addinfobox));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Diabtetic_add_infobox = cell.getStringCellValue();
								       System.out.println(MH_Diabtetic_add_infobox);	
									   MH_Diabtetic_addinfobox.sendKeys(MH_Diabtetic_add_infobox);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Diabtetic_addinfobox ","Adding MH_Diabtetic_addinfobox");
									
									
									MH_Diabetes_Save_Button= driver.findElement(By.xpath(EApp_LandingPage.Diabetes_Save_Button));
										MH_Diabetes_Save_Button.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Diabetes_Save_Button ","clicking MH_Diabetes_Save_Button");
									
								//Protein 

								//Scroll
				                JavascriptExecutor jse46 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								MH_ProteinCheck=driver.findElement(By.xpath(EApp_LandingPage.ProteinRadio));
										MH_ProteinCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_ProteinCheck ","clicking MH_ProteinCheck");
									
									
												
									MH_ProteinCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.ProteinCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ProteinCurrent_Symp = cell.getStringCellValue();
								       System.out.println(MH_ProteinCurrent_Symp);	
									   MH_ProteinCurrentSymp.sendKeys(MH_ProteinCurrent_Symp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinCurrentSymp ","Adding MH_ProteinCurrentSymp");
												
									MH_ProteinDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.ProteinDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ProteinDoctor_Detail = cell.getStringCellValue();
								       System.out.println(MH_ProteinDoctor_Detail);	
									   MH_ProteinDoctorDetail.sendKeys(MH_ProteinDoctor_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinDoctor_Detail ","Adding MH_ProteinDoctor_Detail");
									
										MH_ProteinDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.ProteinDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Protein_Doctor_Detail = cell.getStringCellValue();
								       System.out.println(MH_Protein_Doctor_Detail);	
									   MH_ProteinDoctorDetail.sendKeys(MH_Protein_Doctor_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinDoctor_Detail ","Adding MH_ProteinDoctor_Detail");
									
									
									MH_ProteinDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.ProteinDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ProteinDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(MH_ProteinDiagnosis_Date);	
									   MH_ProteinDiagnosisDate.sendKeys(MH_ProteinDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinDiagnosis_Date ","Adding MH_ProteinDiagnosis_Date");
									
									
									
									
									MH_ProteinLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.ProteinLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ProteinLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_ProteinLastDate_Consult);	
									   MH_ProteinLastDateConsult.sendKeys(MH_ProteinLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinLastDateConsult ","Adding MH_ProteinLastDateConsult");
									
									
										
									MH_ProteinDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.ProteinDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ProteinDiagnosis_Detail = cell.getStringCellValue();
								       System.out.println(MH_ProteinDiagnosis_Detail);	
									   MH_ProteinDiagnosisDetail.sendKeys(MH_ProteinDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ProteinDiagnosis_Detail ","Adding MH_ProteinDiagnosis_Detail");
							//Ulcer		
									
									//Scroll
				                JavascriptExecutor jse45 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
										MH_UlcerCheck=driver.findElement(By.xpath(EApp_LandingPage.UlcerRadio));
										MH_UlcerCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_UlcerCheck ","clicking MH_UlcerCheck");
									
									
									MH_UlcerCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.UlcerCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_UlcerCurrent_Symp = cell.getStringCellValue();
								       System.out.println(MH_UlcerCurrent_Symp);	
									   MH_UlcerCurrentSymp.sendKeys(MH_UlcerCurrent_Symp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_UlcerCurrent_Symp ","Adding MH_UlcerCurrent_Symp");
									
								
									
									MH_UlcerDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.UlcerDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_UlcerDoctor_Detail = cell.getStringCellValue();
								       System.out.println(MH_UlcerDoctor_Detail);	
									   MH_UlcerDoctorDetail.sendKeys(MH_UlcerDoctor_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_UlcerDoctorDetail ","Adding MH_UlcerDoctorDetail");
									
									
									
									
									MH_UlcerDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.UlcerDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_UlcerDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(MH_UlcerDiagnosis_Date);	
									   MH_UlcerDiagnosisDate.sendKeys(MH_UlcerDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_UlcerDiagnosisDate ","Adding MH_UlcerDiagnosisDate");
									
									
									MH_UlcerLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.UlcerLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_UlcerLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_UlcerLastDate_Consult);	
									   MH_UlcerLastDateConsult.sendKeys(MH_UlcerLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_UlcerLastDateConsult ","Adding MH_UlcerLastDateConsult");
									
									
										MH_UlcerDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.UlcerDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_UlcerDiagnosis_Detail = cell.getStringCellValue();
								       System.out.println(MH_UlcerDiagnosis_Detail);	
									   MH_UlcerDiagnosisDetail.sendKeys(MH_UlcerDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_UlcerDiagnosis_Detail ","Adding MH_UlcerDiagnosis_Detail");
									
							//Tumor

							//Scroll
				                JavascriptExecutor jse51 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
										MH_TumourCheck=driver.findElement(By.xpath(EApp_LandingPage.TumourRadio));
										MH_TumourCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_TumourCheck ","clicking MH_TumourCheck");
									
									
									
										MH_TumourCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.TumourCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TumourCurrent_Symp = cell.getStringCellValue();
								       System.out.println(MH_TumourCurrent_Symp);	
									   MH_TumourCurrentSymp.sendKeys(MH_TumourCurrent_Symp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TumourCurrentSymp ","Adding MH_TumourCurrentSymp");
									
									
									
									MH_TumourDoctor_Detail= driver.findElement(By.xpath(EApp_LandingPage.TumourDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TumourDoctorDetail = cell.getStringCellValue();
								       System.out.println(MH_TumourDoctorDetail);	
									   MH_TumourDoctor_Detail.sendKeys(MH_TumourDoctorDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TumourDoctor_Detail ","Adding MH_TumourDoctor_Detail");
									
									
									
									MH_TumourDiagnosis_Date= driver.findElement(By.xpath(EApp_LandingPage.TumourDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TumourDiagnosisDate = cell.getStringCellValue();
								       System.out.println(MH_TumourDiagnosisDate);	
									   MH_TumourDiagnosis_Date.sendKeys(MH_TumourDiagnosisDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TumourDiagnosis_Date ","Adding MH_TumourDiagnosis_Date");
									
									MH_TumourLastDate_Consult= driver.findElement(By.xpath(EApp_LandingPage.TumourLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TumourLastDateConsult = cell.getStringCellValue();
								       System.out.println(MH_TumourLastDateConsult);	
									   MH_TumourLastDate_Consult.sendKeys(MH_TumourLastDateConsult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TumourLastDateConsult ","Adding MH_TumourLastDateConsult");
									
									MH_TumourDiagnosis_Detail= driver.findElement(By.xpath(EApp_LandingPage.TumourDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TumourDiagnosisDetail = cell.getStringCellValue();
								       System.out.println(MH_TumourDiagnosisDetail);	
									   MH_TumourDiagnosis_Detail.sendKeys(MH_TumourDiagnosisDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TumourDiagnosis_Detail ","Adding MH_TumourDiagnosis_Detail");
						//Thyroid Disorder 			
									
								MH_ThyroidDisorder_Check=driver.findElement(By.xpath(EApp_LandingPage.ThyroidDisorderRadio));
										MH_ThyroidDisorder_Check.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_ThyroidDisorder_Check ","clicking MH_ThyroidDisorder_Check");
									
									
									MH_thyroidDis_Hypothyroidism= driver.findElement(By.xpath(EApp_LandingPage.thyroidDisHypothyroidism));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_thyroid_Dis_Hypothyroidism = cell.getStringCellValue();
								       System.out.println(MH_thyroid_Dis_Hypothyroidism);	
									   MH_thyroidDis_Hypothyroidism.sendKeys(MH_thyroid_Dis_Hypothyroidism);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_thyroid_Dis_Hypothyroidism ","Adding MH_thyroid_Dis_Hypothyroidism");
									
									
										MH_diagnise_date= driver.findElement(By.xpath(EApp_LandingPage.diagnise_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_diagnisedate = cell.getStringCellValue();
								       System.out.println(MH_diagnisedate);	
									   MH_diagnise_date.sendKeys(MH_diagnisedate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_diagnise_date ","Adding MH_diagnise_date");
									
									
										MH_medication_name= driver.findElement(By.xpath(EApp_LandingPage.medication_name));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_medicationname = cell.getStringCellValue();
								       System.out.println(MH_medicationname);	
									   MH_medication_name.sendKeys(MH_medicationname);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_medication_name ","Adding MH_medication_name");
									
									
									MH_Dose_Treat= driver.findElement(By.xpath(EApp_LandingPage.doseTreat));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_DoseTreat = cell.getStringCellValue();
								       System.out.println(MH_DoseTreat);	
									   MH_Dose_Treat.sendKeys(MH_DoseTreat);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Dose_Treat ","Adding MH_Dose_Treat");
									
									MH_frequencyTreat= driver.findElement(By.xpath(EApp_LandingPage.frequencyTreat));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_frequency_Treat = cell.getStringCellValue();
								       System.out.println(MH_frequency_Treat);	
									   MH_frequencyTreat.sendKeys(MH_frequency_Treat);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_frequency_Treat ","Adding MH_frequency_Treat");
									
								
									
									MH_treatment_date= driver.findElement(By.xpath(EApp_LandingPage.treatment_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_treatmentdate = cell.getStringCellValue();
								       System.out.println(MH_treatmentdate);	
									   MH_treatment_date.sendKeys(MH_treatmentdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_treatment_date ","Adding MH_treatment_date");
									
													
									MH_ThyroidaddTreat=driver.findElement(By.xpath(EApp_LandingPage.addTreat));
										MH_ThyroidaddTreat.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_ThyroidaddTreat ","clicking MH_ThyroidaddTreat");
									
														
														
									MH_surgery_undergo_toggle_yes=driver.findElement(By.xpath(EApp_LandingPage.surgery_undergo_toggle_yes));
										MH_surgery_undergo_toggle_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_surgery_undergo_toggle_yes ","clicking MH_surgery_undergo_toggle_yes");
									
									
									MH_thySurgryInput= driver.findElement(By.xpath(EApp_LandingPage.thySurgryInput));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_thySurgry_Input = cell.getStringCellValue();
								       System.out.println(MH_thySurgry_Input);	
									   MH_thySurgryInput.sendKeys(MH_thySurgry_Input);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_thySurgryInput ","Adding MH_thySurgryInput");
									
									
							//Scroll
				                JavascriptExecutor jse47 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								
								
								MH_thyfuncTest_date= driver.findElement(By.xpath(EApp_LandingPage.thyfuncTest_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_thyfuncTestdate = cell.getStringCellValue();
								       System.out.println(MH_thyfuncTestdate);	
									   MH_thyfuncTest_date.sendKeys(MH_thyfuncTestdate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_thyfuncTest_date ","Adding MH_thyfuncTest_date");
									
																								
														
									MH_thyDisord_toggle_yes=driver.findElement(By.xpath(EApp_LandingPage.thyDisord_toggle_yes));
										MH_thyDisord_toggle_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_thyDisord_toggle_yes ","clicking MH_thyDisord_toggle_yes");
									
											
									MH_thyDisordInput= driver.findElement(By.xpath(EApp_LandingPage.thyDisordInput));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_thyDisord_Input = cell.getStringCellValue();
								       System.out.println(MH_thyDisord_Input);	
									   MH_thyDisordInput.sendKeys(MH_thyDisord_Input);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_thyDisordInput ","Adding MH_thyDisordInput");
									
									
									
										MH_weight_LG_toggle_yes=driver.findElement(By.xpath(EApp_LandingPage.weight_LG_toggle_yes));
										MH_weight_LG_toggle_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_weight_LG_toggle_yes ","clicking MH_weight_LG_toggle_yes");
									
									
									MH_thyWeightInput= driver.findElement(By.xpath(EApp_LandingPage.thyWeightInput));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_thyWeight_Input = cell.getStringCellValue();
								       System.out.println(MH_thyWeight_Input);	
									   MH_thyWeightInput.sendKeys(MH_thyWeight_Input);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_thyWeightInput ","Adding MH_thyWeightInput");
									
									
									
									MH_add_info_toggle_yes=driver.findElement(By.xpath(EApp_LandingPage.add_info_toggle_yes));
										MH_add_info_toggle_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_add_info_toggle_yes ","clicking MH_add_info_toggle_yes");
									
									
									
									MH_addit_Input= driver.findElement(By.xpath(EApp_LandingPage.additInput));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_additInput = cell.getStringCellValue();
								       System.out.println(MH_additInput);	
									   MH_addit_Input.sendKeys(MH_additInput);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_addit_Input ","Adding MH_addit_Input");
									
									
									MH_Thyroidpage_Submit=driver.findElement(By.xpath(EApp_LandingPage.Thyroidpage_Submit));
										MH_Thyroidpage_Submit.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Thyroidpage_Submit ","clicking MH_Thyroidpage_Submit");
									
							//Anemia

							//Scroll
				                JavascriptExecutor jse48 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								
							MH_Anemia_Check=driver.findElement(By.xpath(EApp_LandingPage.AnemiaRadio));
										MH_Anemia_Check.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Anemia_Check ","clicking MH_Anemia_Check");
									
									
										MH_AnemiaCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.AnemiaCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Anemia_CurrentSymp = cell.getStringCellValue();
								       System.out.println(MH_Anemia_CurrentSymp);	
									   MH_AnemiaCurrentSymp.sendKeys(MH_Anemia_CurrentSymp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Anemia_CurrentSymp ","Adding MH_Anemia_CurrentSymp");
									
					
						
						MH_AnemiaDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.AnemiaDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Anemia_DoctorDetail = cell.getStringCellValue();
								       System.out.println(MH_Anemia_DoctorDetail);	
									   MH_AnemiaCurrentSymp.sendKeys(MH_Anemia_DoctorDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_AnemiaDoctorDetail ","Adding MH_AnemiaDoctorDetail");
									
									
										MH_AnemiaDiagnosis_Date= driver.findElement(By.xpath(EApp_LandingPage.AnemiaDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_AnemiaDiagnosisDate = cell.getStringCellValue();
								       System.out.println(MH_AnemiaDiagnosisDate);	
									   MH_AnemiaDiagnosis_Date.sendKeys(MH_AnemiaDiagnosisDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_AnemiaDiagnosis_Date ","Adding MH_AnemiaDiagnosis_Date");
									
															
									MH_AnemiaLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.AnemiaLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_AnemiaLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_AnemiaLastDate_Consult);	
									   MH_AnemiaLastDateConsult.sendKeys(MH_AnemiaLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_AnemiaLastDateConsult ","Adding MH_AnemiaLastDateConsult");
						
										MH_AnemiaDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.AnemiaDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_AnemiaDiagnosis_Detail = cell.getStringCellValue();
								       System.out.println(MH_AnemiaDiagnosis_Detail);	
									   MH_AnemiaDiagnosisDetail.sendKeys(MH_AnemiaDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_AnemiaDiagnosisDetail ","Adding MH_AnemiaDiagnosisDetail");
						
						
						// Paralysis
					
						 
						
									EmotionalDisordersRadio=driver.findElement(By.xpath(EApp_LandingPage.EmotionalDisordersRadio));
										EmotionalDisordersRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking EmotionalDisordersRadio ","clicking EmotionalDisordersRadio");
									
									MentalDisorderRadio=driver.findElement(By.xpath(EApp_LandingPage.MentalDisorderRadio));
										MentalDisorderRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MentalDisorderRadio ","clicking MentalDisorderRadio");
							
								StrokeRadio=driver.findElement(By.xpath(EApp_LandingPage.StrokeRadio));
										StrokeRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking StrokeRadio ","clicking StrokeRadio");
							
							FaintingRadio=driver.findElement(By.xpath(EApp_LandingPage.FaintingRadio));
										FaintingRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking FaintingRadio ","clicking FaintingRadio");
							
								MH_Paralysis_Check=driver.findElement(By.xpath(EApp_LandingPage.ParalysisRadio));
										MH_Paralysis_Check.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_Paralysis_Check ","clicking MH_Paralysis_Check");
									
									MH_ParalysisCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.ParalysisCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Paralysis_CurrentSymp = cell.getStringCellValue();
								       System.out.println(MH_Paralysis_CurrentSymp);	
									   MH_AnemiaDiagnosisDetail.sendKeys(MH_Paralysis_CurrentSymp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ParalysisCurrentSymp ","Adding MH_ParalysisCurrentSymp");
									
												
									MH_ParalysisDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.ParalysisDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ParalysisDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(MH_ParalysisDiagnosis_Date);	
									   MH_ParalysisDiagnosisDate.sendKeys(MH_ParalysisDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ParalysisDiagnosisDate ","Adding MH_ParalysisDiagnosisDate");
					
							MH_ParalysisLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.ParalysisLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ParalysisLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_ParalysisLastDate_Consult);	
									   MH_ParalysisLastDateConsult.sendKeys(MH_ParalysisLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ParalysisLastDateConsult ","Adding MH_ParalysisLastDateConsult");
									
									
									MH_ParalysisDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.ParalysisDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_ParalysisDiagnosis_Detail = cell.getStringCellValue();
								       System.out.println(MH_ParalysisDiagnosis_Detail);	
									   MH_ParalysisDiagnosisDetail.sendKeys(MH_ParalysisDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_ParalysisDiagnosisDetail ","Adding MH_ParalysisDiagnosisDetail");
									
							// Kidney		
									
									
									MH_KidneyRadio=driver.findElement(By.xpath(EApp_LandingPage.KidneyRadio));
										MH_KidneyRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_KidneyRadio ","clicking MH_KidneyRadio");
									
										MH_UrinaryRadio=driver.findElement(By.xpath(EApp_LandingPage.UrinaryRadio));
										MH_UrinaryRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_UrinaryRadio ","clicking MH_UrinaryRadio");
									
										MH_BladderRadio=driver.findElement(By.xpath(EApp_LandingPage.BladderRadio));
										MH_BladderRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_BladderRadio ","clicking MH_BladderRadio");
									
										MH_ReproductiveOrganRadio=driver.findElement(By.xpath(EApp_LandingPage.ReproductiveOrganRadio));
										MH_ReproductiveOrganRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_ReproductiveOrganRadio ","clicking MH_ReproductiveOrganRadio");
									
										MH_ProstateRadio=driver.findElement(By.xpath(EApp_LandingPage.ProstateRadio));
										MH_ProstateRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_ProstateRadio ","clicking MH_ProstateRadio");
									
									
									MH_KidneyCurrent_Symp= driver.findElement(By.xpath(EApp_LandingPage.KidneyCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_KidneyCurrentSymp = cell.getStringCellValue();
								       System.out.println(MH_KidneyCurrentSymp);	
									   MH_KidneyCurrent_Symp.sendKeys(MH_KidneyCurrentSymp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyCurrent_Symp ","Adding MH_KidneyCurrent_Symp");
									
										
							MH_KidneyDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.KidneyDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_KidneyDoctor_Detailp = cell.getStringCellValue();
								       System.out.println(MH_KidneyDoctor_Detailp);	
									   MH_KidneyDoctorDetail.sendKeys(MH_KidneyDoctor_Detailp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyDoctor_Detailp ","Adding MH_KidneyDoctor_Detailp");
											
							MH_KidneyDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.KidneyDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String KidneyDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(KidneyDiagnosis_Date);	
									   MH_KidneyDiagnosisDate.sendKeys(KidneyDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyDiagnosisDate ","Adding MH_KidneyDiagnosisDate");
									
									MH_KidneyDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.KidneyDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_KidneyDiagnosis_Detail = cell.getStringCellValue();
								       System.out.println(MH_KidneyDiagnosis_Detail);	
									   MH_KidneyDiagnosisDetail.sendKeys(MH_KidneyDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyDiagnosisDetail ","Adding MH_KidneyDiagnosisDetail");
									
									
									MH_KidneyLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.KidneyLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_KidneyLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_KidneyLastDate_Consult);	
									   MH_KidneyDiagnosisDate.sendKeys(MH_KidneyLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyLastDate_Consult ","Adding MH_KidneyLastDate_Consult");
									
									
									
						//Arthritis		

									MH_arthrities=driver.findElement(By.xpath(EApp_LandingPage.arthrities));
										MH_arthrities.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_arthrities ","clicking MH_arthrities");
									

									MH_condRheumatoid=driver.findElement(By.xpath(EApp_LandingPage.condRheumatoid));
										MH_condRheumatoid.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("clicking MH_condRheumatoid ","clicking MH_condRheumatoid");
									
									MH_KidneyfstExpSympDate= driver.findElement(By.xpath(EApp_LandingPage.fstExpSympDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Kidneyfst_ExpSympDate = cell.getStringCellValue();
								       System.out.println(MH_Kidneyfst_ExpSympDate);	
									   MH_KidneyfstExpSympDate.sendKeys(MH_Kidneyfst_ExpSympDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_KidneyfstExpSympDate ","Adding MH_KidneyfstExpSympDate");
									
									MH_Kidneysymp_OnGoingCheck= driver.findElement(By.xpath(EApp_LandingPage.sympOnGoingCheck));
										  MH_Kidneysymp_OnGoingCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_OnGoingCheck ","Adding MH_Kidneysymp_OnGoingCheck");
									
									
									
										MH_Kidneysymp_worseningCheck= driver.findElement(By.xpath(EApp_LandingPage.worseningCheck));
										MH_Kidneysymp_worseningCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_worseningCheck ","Adding MH_Kidneysymp_worseningCheck");
									
									
									MH_Kidneysymp_lastExp_SympDate= driver.findElement(By.xpath(EApp_LandingPage.lastExpSympDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Kidneysymp_lastExpSympDate = cell.getStringCellValue();
								       System.out.println(MH_Kidneysymp_lastExpSympDate);	
									   MH_Kidneysymp_lastExp_SympDate.sendKeys(MH_Kidneysymp_lastExpSympDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_lastExp_SympDate ","Adding MH_Kidneysymp_lastExp_SympDate");
									
														
									MH_Kidneysymp_affectedJointsInfo= driver.findElement(By.xpath(EApp_LandingPage.affectedJointsInfo));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Kidneysymp_affected_JointsInfo = cell.getStringCellValue();
								       System.out.println(MH_Kidneysymp_affected_JointsInfo);	
									   MH_Kidneysymp_affectedJointsInfo.sendKeys(MH_Kidneysymp_affected_JointsInfo);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_affected_JointsInfo ","Adding MH_Kidneysymp_affected_JointsInfo");
									
														MH_Kidneysymp_dailyActAffctCheck= driver.findElement(By.xpath(EApp_LandingPage.dailyActAffctCheck));
										MH_Kidneysymp_dailyActAffctCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_dailyActAffctCheck ","Adding MH_Kidneysymp_dailyActAffctCheck");
									
									
									MH_Kidneysymp_dailyActAffctInpt= driver.findElement(By.xpath(EApp_LandingPage.dailyActAffctInpt));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Kidneysymp_daily_ActAffctInpt = cell.getStringCellValue();
								       System.out.println(MH_Kidneysymp_daily_ActAffctInpt);	
									   MH_Kidneysymp_dailyActAffctInpt.sendKeys(MH_Kidneysymp_daily_ActAffctInpt);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_daily_ActAffctInpt ","Adding MH_Kidneysymp_daily_ActAffctInpt");
									
									
										MH_Kidneysymp_useWalkStickCheck= driver.findElement(By.xpath(EApp_LandingPage.useWalkStickCheck));
										MH_Kidneysymp_useWalkStickCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_useWalkStickCheck ","Adding MH_Kidneysymp_useWalkStickCheck");
									
									
									MH_Kidneysymp_useWalkStickInpt= driver.findElement(By.xpath(EApp_LandingPage.useWalkStickInpt));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Kidneysymp_useWalkStick_Inpt = cell.getStringCellValue();
								       System.out.println(MH_Kidneysymp_useWalkStick_Inpt);	
									   MH_Kidneysymp_useWalkStickInpt.sendKeys(MH_Kidneysymp_useWalkStick_Inpt);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_useWalkStickInpt ","Adding MH_Kidneysymp_useWalkStickInpt");
									
									
									MH_Kidneysymp_curTakeMedicineCheck= driver.findElement(By.xpath(EApp_LandingPage.curTakeMedicineCheck));
										MH_Kidneysymp_curTakeMedicineCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Kidneysymp_curTakeMedicineCheck ","Adding MH_Kidneysymp_curTakeMedicineCheck");
									
									
									
									
									MH_Arthritis_symp_othertreatment= driver.findElement(By.xpath(EApp_LandingPage.othertreatment));
										MH_Arthritis_symp_othertreatment.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_symp_othertreatment ","Adding MH_Arthritis_symp_othertreatment");
									
									
									MH_Arthritis_arthritis_treatment= driver.findElement(By.xpath(EApp_LandingPage.arthritis_treatment));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Arthritis_arthritistreatment = cell.getStringCellValue();
								       System.out.println(MH_Arthritis_arthritistreatment);	
									   MH_Arthritis_arthritis_treatment.sendKeys(MH_Arthritis_arthritistreatment);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_arthritis_treatment ","Adding MH_Arthritis_arthritis_treatment");
									
										MH_arthritis_treatmentdate = driver.findElement(By.xpath(EApp_LandingPage.arthritis_treatment_date));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_arthritis_treatment_date = cell.getStringCellValue();
								       System.out.println(MH_arthritis_treatment_date);	
									   MH_arthritis_treatmentdate.sendKeys(MH_arthritis_treatment_date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_arthritis_treatment_date ","Adding MH_arthritis_treatment_date");
									
									
									
									
										MH_Arthritis_arthritislocation= driver.findElement(By.xpath(EApp_LandingPage.arthritis_location));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Arthritis_arthritis_location = cell.getStringCellValue();
								       System.out.println(MH_Arthritis_arthritis_location);	
									   MH_Arthritis_arthritislocation.sendKeys(MH_Arthritis_arthritis_location);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_arthritis_location ","Adding MH_Arthritis_arthritis_location");
									
									
									MH_Arthritisresult= driver.findElement(By.xpath(EApp_LandingPage.results));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_Arthritis_result = cell.getStringCellValue();
								       System.out.println(MH_Arthritis_result);	
									   MH_Arthritisresult.sendKeys(MH_Arthritis_result);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_result ","Adding MH_Arthritis_result");
									
									MH_arthritisadd= driver.findElement(By.xpath(EApp_LandingPage.arthritis_add));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_arthritis_add = cell.getStringCellValue();
								       System.out.println(MH_arthritis_add);	
									   MH_arthritisadd.sendKeys(MH_arthritis_add);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_result ","Adding MH_Arthritis_result");
									
											
									
									MH_Arthritis_advisedOPDCheck= driver.findElement(By.xpath(EApp_LandingPage.advisedOPDCheck));
										MH_Arthritis_advisedOPDCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_advisedOPDCheck ","Adding MH_Arthritis_advisedOPDCheck");
									
									
									MH_advisedOPD_Inpt= driver.findElement(By.xpath(EApp_LandingPage.advisedOPDInpt));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_advisedOPDInpt = cell.getStringCellValue();
								       System.out.println(MH_advisedOPDInpt);	
									   MH_advisedOPD_Inpt.sendKeys(MH_advisedOPDInpt);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_advisedOPD_Inpt ","Adding MH_advisedOPD_Inpt");
									
										MH_Arthritis_systemicManifstCheck= driver.findElement(By.xpath(EApp_LandingPage.systemicManifstCheck));
										MH_Arthritis_systemicManifstCheck.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_Arthritis_systemicManifstCheck ","Adding MH_Arthritis_systemicManifstCheck");
									
											
									MH_systemicManifst_Inpt= driver.findElement(By.xpath(EApp_LandingPage.systemicManifstInpt));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_systemicManifstInpt = cell.getStringCellValue();
								       System.out.println(MH_systemicManifstInpt);	
									   MH_systemicManifst_Inpt.sendKeys(MH_systemicManifstInpt);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_systemicManifst_Inpt ","Adding MH_systemicManifst_Inpt");
									
									MH_systemicadd_Info= driver.findElement(By.xpath(EApp_LandingPage.addInfo));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_systemicaddInfo = cell.getStringCellValue();
								       System.out.println(MH_systemicaddInfo);	
									   MH_systemicadd_Info.sendKeys(MH_systemicaddInfo);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_systemicadd_Info ","Adding MH_systemicadd_Info");
									
									
									MH_Arthritis_arthrities_Submit= driver.findElement(By.xpath(EApp_LandingPage.arthrities_Submit));
										MH_Arthritis_arthrities_Submit.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_Arthritis_arthrities_Submit ","Clicking MH_Arthritis_arthrities_Submit");
									
									//Scroll
				                JavascriptExecutor jse29 = (JavascriptExecutor)driver;
				                jse29.executeScript("window.scrollBy(0,300)", "");
				                Thread.sleep(2000);
									
							//Disorder of Eye

							
									MH_EyeDisorderRadio= driver.findElement(By.xpath(EApp_LandingPage.EyeDisorderRadio));
										MH_EyeDisorderRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_EyeDisorderRadio ","Clicking MH_EyeDisorderRadio");
									
								
									MH_EarDisorderRadio= driver.findElement(By.xpath(EApp_LandingPage.EarDisorderRadio));
										MH_EarDisorderRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_EarDisorderRadio ","Clicking MH_EarDisorderRadio");
									
									
									MH_EyeCurrent_Symp= driver.findElement(By.xpath(EApp_LandingPage.EyeCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_EyeCurrentSymp = cell.getStringCellValue();
								       System.out.println(MH_EyeCurrentSymp);	
									   MH_EyeCurrent_Symp.sendKeys(MH_EyeCurrentSymp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_EyeCurrent_Symp ","Adding MH_EyeCurrent_Symp");
									
										MH_EyeDiagnosis_Date= driver.findElement(By.xpath(EApp_LandingPage.EyeDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_EyeDiagnosisDate = cell.getStringCellValue();
								       System.out.println(MH_EyeDiagnosisDate);	
									   MH_EyeDiagnosis_Date.sendKeys(MH_EyeDiagnosisDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_EyeDiagnosis_Date ","Adding MH_EyeDiagnosis_Date");
									
										MH_EyeLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.EyeLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_EyeLastDate_Consult = cell.getStringCellValue();
								       System.out.println(MH_EyeLastDate_Consult);	
									   MH_EyeLastDateConsult.sendKeys(MH_EyeLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_EyeLastDate_Consult ","Adding MH_EyeLastDate_Consult");
									
												
										MH_EyeDiagnosis_Detail= driver.findElement(By.xpath(EApp_LandingPage.EyeDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_EyeDiagnosisDetail = cell.getStringCellValue();
								       System.out.println(MH_EyeDiagnosisDetail);	
									   MH_EyeDiagnosis_Detail.sendKeys(MH_EyeDiagnosisDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_EyeLastDate_Consult ","Adding MH_EyeLastDate_Consult");
									
							//other Illness
							
									
									MH_OtherIllnessRadio= driver.findElement(By.xpath(EApp_LandingPage.OtherIllnessRadio));
										MH_OtherIllnessRadio.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_OtherIllnessRadio ","Clicking MH_OtherIllnessRadio");
									
									
										MH_OtherCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.OtherCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_OtherCurrent_Symp = cell.getStringCellValue();
								       System.out.println(MH_OtherCurrent_Symp);	
									   MH_OtherCurrentSymp.sendKeys(MH_EyeDiagnosisDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_OtherCurrentSymp ","Adding MH_OtherCurrentSymp");
									
									
										MH_OtherDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.OtherDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_OtherDoctor_Detail = cell.getStringCellValue();
								       System.out.println(MH_OtherDoctor_Detail);	
									   MH_OtherDoctorDetail.sendKeys(MH_OtherDoctor_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_OtherDoctorDetail ","Adding MH_OtherDoctorDetail");
									
									
									MH_OtherDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.OtherDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_OtherDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(MH_OtherDiagnosis_Date);	
									   MH_OtherDiagnosisDate.sendKeys(MH_OtherDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_OtherDiagnosisDate ","Adding MH_OtherDiagnosisDate");
									
										MH_OtherLastDate_Consult= driver.findElement(By.xpath(EApp_LandingPage.OtherLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_OtherLastDateConsult = cell.getStringCellValue();
								       System.out.println(MH_OtherLastDateConsult);	
									   MH_OtherLastDate_Consult.sendKeys(MH_OtherLastDateConsult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_OtherLastDate_Consult ","Adding MH_OtherLastDate_Consult");
									
									MH_OtherDiagnosis_Detail= driver.findElement(By.xpath(EApp_LandingPage.OtherDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_OtherDiagnosisDetail = cell.getStringCellValue();
								       System.out.println(MH_OtherDiagnosisDetail);	
									   MH_OtherDiagnosis_Detail.sendKeys(MH_OtherDiagnosisDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_OtherDiagnosisDetail ","Adding MH_OtherDiagnosisDetail");
							
						//physical Defects 
						
						
									MH_Toggle_yes= driver.findElement(By.xpath(EApp_LandingPage.Toggle30));
										MH_Toggle_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_Toggle_yes ","Clicking MH_Toggle_yes");
									
							
						
									MH_PDCurrent_Symp= driver.findElement(By.xpath(EApp_LandingPage.PDCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String PDCurrentSymp = cell.getStringCellValue();
								       System.out.println(PDCurrentSymp);	
									   MH_PDCurrent_Symp.sendKeys(PDCurrentSymp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_PDCurrent_Symp ","Adding MH_PDCurrent_Symp");
									
									MH_PDDoctor_Detail= driver.findElement(By.xpath(EApp_LandingPage.PDDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_PDDoctorDetail = cell.getStringCellValue();
								       System.out.println(MH_PDDoctorDetail);	
									   MH_PDDoctor_Detail.sendKeys(MH_PDDoctorDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_PDDoctorDetail ","Adding MH_PDDoctorDetail");
									
									MH_PDDiagnosisDate= driver.findElement(By.xpath(EApp_LandingPage.PDDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_PDDiagnosis_Date = cell.getStringCellValue();
								       System.out.println(MH_PDDiagnosis_Date);	
									   MH_PDDiagnosisDate.sendKeys(MH_PDDiagnosis_Date);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_PDDiagnosis_Date ","Adding MH_PDDiagnosis_Date");
						
								MH_PDLastDateConsult= driver.findElement(By.xpath(EApp_LandingPage.PDLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String PDLastDate_Consult= cell.getStringCellValue();
								       System.out.println(PDLastDate_Consult);	
									   MH_PDLastDateConsult.sendKeys(PDLastDate_Consult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding PDLastDate_Consult ","Adding PDLastDate_Consult");
								
								MH_PPDDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.PDDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_PPDDiagnosis_Detail= cell.getStringCellValue();
								       System.out.println(MH_PPDDiagnosis_Detail);	
									   MH_PPDDiagnosisDetail.sendKeys(MH_PPDDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_PPDDiagnosisDetail ","Adding MH_PPDDiagnosisDetail");
						// HIV 

						//Scroll
				                JavascriptExecutor jse30 = (JavascriptExecutor)driver;
				                jse28.executeScript("window.scrollBy(0,250)", "");
				                Thread.sleep(2000);
								
								

								MH_ToggleHIV_yes= driver.findElement(By.xpath(EApp_LandingPage.Toggle31));
										MH_ToggleHIV_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_ToggleHIV_yes ","Clicking MH_ToggleHIV_yes");
									
									MH_HIVCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.HIVCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_HIVCurrent_Symp= cell.getStringCellValue();
								       System.out.println(MH_HIVCurrent_Symp);	
									   MH_HIVCurrentSymp.sendKeys(MH_HIVCurrent_Symp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_HIVCurrentSymp ","Adding MH_HIVCurrentSymp");
									
									
									MH_HIVDoctorDetail= driver.findElement(By.xpath(EApp_LandingPage.HIVDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_HIVDoctor_Detail= cell.getStringCellValue();
								       System.out.println(MH_HIVDoctor_Detail);	
									   MH_HIVDoctorDetail.sendKeys(MH_HIVDoctor_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_HIVDoctor_Detail ","Adding MH_HIVDoctor_Detail");
									
									MH_HIVDiagnosis_Date= driver.findElement(By.xpath(EApp_LandingPage.HIVDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_HIVDiagnosisDate= cell.getStringCellValue();
								       System.out.println(MH_HIVDiagnosisDate);	
									   MH_HIVDiagnosis_Date.sendKeys(MH_HIVDiagnosisDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_HIVDiagnosis_Date ","Adding MH_HIVDiagnosis_Date");
									
						
										MH_HIVLastDate_Consult= driver.findElement(By.xpath(EApp_LandingPage.HIVLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_HIVLastDateConsult= cell.getStringCellValue();
								       System.out.println(MH_HIVLastDateConsult);	
									   MH_HIVLastDate_Consult.sendKeys(MH_HIVLastDateConsult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_HIVLastDate_Consult ","Adding MH_HIVLastDate_Consult");
									
										MH_HIVDiagnosisDetail= driver.findElement(By.xpath(EApp_LandingPage.HIVDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_HIVDiagnosis_Detail= cell.getStringCellValue();
								       System.out.println(MH_HIVDiagnosis_Detail);	
									   MH_HIVDiagnosisDetail.sendKeys(MH_HIVDiagnosis_Detail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_HIVDiagnosis_Detail ","Adding MH_HIVDiagnosis_Detail");
									
						//Treatment not Received(TNR)
						
						

						MH_ToggleTreatment_yes= driver.findElement(By.xpath(EApp_LandingPage.Toggle32));
										MH_ToggleTreatment_yes.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_ToggleTreatment_yes ","Clicking MH_ToggleTreatment_yes");
									
									MH_TNRCurrentSymp= driver.findElement(By.xpath(EApp_LandingPage.TNRCurrentSymp));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TNRCurrent_Symp= cell.getStringCellValue();
								       System.out.println(MH_TNRCurrent_Symp);	
									   MH_TNRCurrentSymp.sendKeys(MH_TNRCurrent_Symp);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TNRCurrentSymp ","Adding MH_TNRCurrentSymp");
									
									
									
									MH_TNRDoctor_Detail= driver.findElement(By.xpath(EApp_LandingPage.TNRDoctorDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TNRDoctorDetail= cell.getStringCellValue();
								       System.out.println(MH_TNRDoctorDetail);	
									   MH_TNRDoctor_Detail.sendKeys(MH_TNRDoctorDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TNRDoctor_Detail ","Adding MH_TNRDoctor_Detail");
									
									
									
									MH_TNRDiagnosis_Date= driver.findElement(By.xpath(EApp_LandingPage.TNRDiagnosisDate));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String TNRDiagnosisDate= cell.getStringCellValue();
								       System.out.println(TNRDiagnosisDate);	
									   MH_TNRDiagnosis_Date.sendKeys(TNRDiagnosisDate);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TNRDiagnosis_Date ","Adding MH_TNRDiagnosis_Date");
									
									
									
									MH_TNRLastDate_Consult= driver.findElement(By.xpath(EApp_LandingPage.TNRLastDateConsult));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String MH_TNRLastDateConsult= cell.getStringCellValue();
								       System.out.println(MH_TNRLastDateConsult);	
									   MH_TNRLastDate_Consult.sendKeys(MH_TNRLastDateConsult);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TNRLastDateConsult ","Adding MH_TNRLastDateConsult");
									
									MH_TNRDiagnosis_Detail= driver.findElement(By.xpath(EApp_LandingPage.TNRDiagnosisDetail));
										cell = sheet.getRow(6).getCell(314);
								       cell.setCellType(Cell.CELL_TYPE_STRING);
								       String TNRDiagnosisDetail= cell.getStringCellValue();
								       System.out.println(TNRDiagnosisDetail);	
									   MH_TNRDiagnosis_Detail.sendKeys(TNRDiagnosisDetail);
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Adding MH_TNRDiagnosis_Detail ","Adding MH_TNRDiagnosis_Detail");
									
									
													
							MH_Pregant_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle33));
										MH_Detials_Submit.click();
									   Thread.sleep(2000);
									Extent_Reporting.Log_Pass("Clicking MH_Detials_Submit ","Clicking MH_Detials_Submit");
									
									MH_Gynac_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle34));
									MH_Detials_Submit.click();
								   Thread.sleep(2000);
								Extent_Reporting.Log_Pass("Clicking MH_Detials_Submit ","Clicking MH_Detials_Submit");
								
								MH_Detials_Submit= driver.findElement(By.xpath(EApp_LandingPage.Iagree5));
								MH_Detials_Submit.click();
							   Thread.sleep(2000);
							Extent_Reporting.Log_Pass("Clicking MH_Detials_Submit ","Clicking MH_Detials_Submit");
					  
				}
				catch(Exception e)
				{
					Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
					e.printStackTrace();
				}
			}
			
			
		//NRI Mandate
		@SuppressWarnings("deprecation")
		public void NRI_Mandate(WebDriver driver) throws IOException, InterruptedException {
			try {
				FileInputStream finput = new FileInputStream(src);
				  workbook = new XSSFWorkbook(finput);
				  sheet= workbook.getSheetAt(3);		
		
		//NRI Mandate Form
		
		NRI_Father_First_Name = driver.findElement(By.xpath(EApp_LandingPage.NRI_Father_First_Name));
		cell = sheet.getRow(6).getCell(145);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_Father_FirstName = cell.getStringCellValue();
		System.out.println(NRI_Father_FirstName);
		NRI_Father_First_Name.sendKeys(NRI_Father_FirstName);
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+NRI_Father_FirstName);

		NRI_Father_Middle_Name = driver.findElement(By.xpath(EApp_LandingPage.NRI_Father_Middle_Name));
		cell = sheet.getRow(6).getCell(146);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_Father_MiddleName = cell.getStringCellValue();
		System.out.println(NRI_Father_MiddleName);
		NRI_Father_Middle_Name.sendKeys(NRI_Father_MiddleName);
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+NRI_Father_MiddleName);

		NRI_Father_Surname = driver.findElement(By.xpath(EApp_LandingPage.NRI_Father_Surname));
		cell = sheet.getRow(6).getCell(147);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_Father_surname = cell.getStringCellValue();
		System.out.println(NRI_Father_surname);
		NRI_Father_Surname.sendKeys(NRI_Father_surname);
		Extent_Reporting.Log_Pass("Selecting Mother Health State","Selected Mother Health State as "+NRI_Father_surname);

		//Scroll
				JavascriptExecutor jse12 = (JavascriptExecutor)driver;
				jse12.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(1000);
		
		NRI_Country_of_Birth = driver.findElement(By.xpath(EApp_LandingPage.NRI_CountryofBirth));
		cell = sheet.getRow(6).getCell(149);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_Country_ofBirth = cell.getStringCellValue();		
		System.out.println(NRI_Country_ofBirth);	
		NRI_Country_of_Birth.sendKeys(NRI_Country_ofBirth);
		Thread.sleep(1000);
		NRI_Country_of_Birth2 = driver.findElement(By.xpath("//li[text()='India']"));
		NRI_Country_of_Birth2.click();
		Extent_Reporting.Log_Pass("Entering Country of Birth ","Entered Country of Birth as "+NRI_Country_ofBirth);


		NRI_Origin_Yes = driver.findElement(By.xpath(EApp_LandingPage.NRI_Origin_Yes));
		NRI_Origin_Yes.click();
		Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Clicking Origin - yes ","Clicked Origin - yes");
		
		NRI_Country_PR = driver.findElement(By.xpath(EApp_LandingPage.NRI_Country_PR));
		cell = sheet.getRow(6).getCell(151);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_CountryPR = cell.getStringCellValue();
		System.out.println(NRI_CountryPR);
		NRI_Country_PR.sendKeys(NRI_CountryPR);
		Thread.sleep(1000);
		NRI_Country_PR2 = driver.findElement(By.xpath("//li[text()='United States']"));
		NRI_Country_PR2.click();
	       Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Entering NRI Country PR","Entering NRI Country PR as  "+NRI_CountryPR);

		NRI_Date_PR = driver.findElement(By.xpath(EApp_LandingPage.NRI_Date_PR));
		cell = sheet.getRow(6).getCell(152);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_DatePR = cell.getStringCellValue();
		System.out.println(NRI_DatePR);
		NRI_Date_PR.sendKeys(NRI_DatePR);
		Extent_Reporting.Log_Pass("Entering NRI Date PR","Entering NRI Date PR as  "+NRI_DatePR);

		NRI_Current_Country = driver.findElement(By.xpath(EApp_LandingPage.NRI_Current_Country));
		cell = sheet.getRow(6).getCell(153);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_CurrentCountry = cell.getStringCellValue();
		System.out.println("NRI Current Country"+NRI_CurrentCountry);
		NRI_Current_Country.sendKeys(NRI_CurrentCountry,Keys.TAB);
		Thread.sleep(1000);
		//NRI_Current_Country22 = driver.findElement(By.xpath("//li[text()='United States of America']"));
		//NRI_Current_Country22.click();
	       Thread.sleep(1000);
		Extent_Reporting.Log_Pass("Entering NRI Country","Entering NRI Country as  "+NRI_CurrentCountry);
		 Thread.sleep(1000);
		 
		NRI_Last_Visit = driver.findElement(By.xpath(EApp_LandingPage.NRI_Last_Visit));
		cell = sheet.getRow(6).getCell(154);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_LastVisit = cell.getStringCellValue();
		System.out.println(NRI_LastVisit);
		NRI_Last_Visit.sendKeys(NRI_LastVisit);
		Extent_Reporting.Log_Pass("Entering NRI Last Visit","Entering NRI Last Visit as  "+NRI_LastVisit);
		 Thread.sleep(1000);
		 
		NRI_Passport_Number = driver.findElement(By.xpath(EApp_LandingPage.NRI_Passport_Number));
		cell = sheet.getRow(6).getCell(155);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String NRI_PassportNumber = cell.getStringCellValue();
		System.out.println(NRI_PassportNumber);
		NRI_Passport_Number.sendKeys(NRI_PassportNumber);
		Extent_Reporting.Log_Pass("Entering NRI Passport Number","Entering NRI Passport Number as  "+NRI_PassportNumber);
		
	 
	 
	//Scroll
		JavascriptExecutor jse16 = (JavascriptExecutor)driver;
		jse16.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(1000);

	//Other Details
		
		Thread.sleep(1000);
		NRI_Other_Details = driver.findElement(By.xpath(EApp_LandingPage.NRI_Other_Details));
		NRI_Other_Details.click();
		Extent_Reporting.Log_Pass("Clicking Other Details","Clicked Other Details");
		 Thread.sleep(3000);
		
		  Purpose = driver.findElement(By.xpath(EApp_LandingPage.NRI_Purpose));
		  Purpose.click();
			Extent_Reporting.Log_Pass("Clicking Purpose - Student","Clicked Purpose - Student");
			 Thread.sleep(1000);
		 
			 Purpose_Details = driver.findElement(By.xpath(EApp_LandingPage.NRI_Purpose_Details));
				
				String PurposeDetails = "Education";
				System.out.println(PurposeDetails);
				Purpose_Details.sendKeys(PurposeDetails);
				Extent_Reporting.Log_Pass("Entering Purpose Details","Entering Purpose Details as "+PurposeDetails);
			  Thread.sleep(1000);
			 
			  Stay_Years = driver.findElement(By.xpath(EApp_LandingPage.NRI_Stay_Years));
				cell = sheet.getRow(6).getCell(165);
				cell.setCellType(Cell.CELL_TYPE_STRING);
				String StayYears = cell.getStringCellValue();
				System.out.println(StayYears);
				Stay_Years.sendKeys(StayYears);
				Extent_Reporting.Log_Pass("Entering NRI Stay Years","Entered NRI Stay Years "+StayYears);
			  Thread.sleep(1000);
		 
			  Stay_Months = driver.findElement(By.xpath(EApp_LandingPage.NRI_Stay_Months));
				cell = sheet.getRow(6).getCell(166);
				cell.setCellType(Cell.CELL_TYPE_STRING);
				String StayMonths = cell.getStringCellValue();
				System.out.println(StayMonths);
				Stay_Months.sendKeys(StayMonths);
				Extent_Reporting.Log_Pass("Entering NRI Stay Months","Entered NRI Stay Months "+StayMonths);
			  Thread.sleep(1000);
		 
			//Scroll
				JavascriptExecutor jse15 = (JavascriptExecutor)driver;
				jse15.executeScript("window.scrollBy(0,150)", "");
				Thread.sleep(1000);
			  
			  Type_Of_Address = driver.findElement(By.xpath(EApp_LandingPage.NRI_Type_Of_Address_Business));
			  Type_Of_Address.click();
				Extent_Reporting.Log_Pass("Clicking Purpose - Student","Clicked Purpose - Student");
				 Thread.sleep(1000);
			  
				 Abroad_Address1 = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Address1));
					cell = sheet.getRow(6).getCell(168);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AbroadAddress1 = cell.getStringCellValue();
					System.out.println(AbroadAddress1);
					Abroad_Address1.sendKeys(AbroadAddress1);
					Extent_Reporting.Log_Pass("Entering NRI Abroad Address 1","Entered Abroad Address 1 "+AbroadAddress1);
				  Thread.sleep(1000);
				  
				  Abroad_Address2 = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Address2));
					cell = sheet.getRow(6).getCell(169);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AbroadAddress2 = cell.getStringCellValue();
					System.out.println(AbroadAddress2);
					Abroad_Address2.sendKeys(AbroadAddress2);
					Extent_Reporting.Log_Pass("Entering NRI Abroad Address 2","Entered Abroad Address 2 "+AbroadAddress2);
				  Thread.sleep(1000);
				  
				  Abroad_Address3 = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Address3));
					cell = sheet.getRow(6).getCell(170);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AbroadAddress3 = cell.getStringCellValue();
					System.out.println(AbroadAddress3);
					Abroad_Address3.sendKeys(AbroadAddress3);
					Extent_Reporting.Log_Pass("Entering NRI Abroad Address 3","Entered Abroad Address 3 "+AbroadAddress3);
				  Thread.sleep(1000);
				  
				//Scroll
					JavascriptExecutor jse17 = (JavascriptExecutor)driver;
					jse17.executeScript("window.scrollBy(0,150)", "");
					Thread.sleep(1000);
				  
				  Abroad_Area = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Area));
					cell = sheet.getRow(6).getCell(171);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String AbroadArea = cell.getStringCellValue();
					System.out.println(AbroadArea);
					Abroad_Area.sendKeys(AbroadArea);
					Extent_Reporting.Log_Pass("Entering NRI Stay Months","Entered NRI Stay Months "+AbroadArea);
				  Thread.sleep(1000);
				  
				  NRI_City = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_City));
					cell = sheet.getRow(6).getCell(172);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String NRICity = cell.getStringCellValue();
					System.out.println(NRICity);
					NRI_City.sendKeys(NRICity);
					Extent_Reporting.Log_Pass("Entering NRI Stay Months","Entered NRI Stay Months "+NRICity);
				  Thread.sleep(1000);
				  
				  NRI_State = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_State));
					cell = sheet.getRow(6).getCell(173);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String NRIState = cell.getStringCellValue();
					System.out.println(NRIState);
					NRI_State.sendKeys(NRIState);
					//Thread.sleep(1000);
					//NRI_State2 = driver.findElement(By.xpath("//li[text()='United States']"));
					//NRI_State2.click();
					Extent_Reporting.Log_Pass("Entering NRI State","Entered NRI State as "+NRIState);
				  Thread.sleep(1000);
				  
				  NRI_PIN = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_PIN));
					cell = sheet.getRow(6).getCell(174);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String NRIPIN = cell.getStringCellValue();
					System.out.println(NRIPIN);
					NRI_PIN.sendKeys(NRIPIN);
					Extent_Reporting.Log_Pass("Entering NRI PIN","Entered NRI PIN as "+NRIPIN);
				  Thread.sleep(1000);
				  
				  NRI_Residence = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Residence_Number));
					cell = sheet.getRow(6).getCell(175);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String NRIResidence = cell.getStringCellValue();
					System.out.println(NRIResidence);
					NRI_Residence.sendKeys(NRIResidence);
					Extent_Reporting.Log_Pass("Entering NRI Residence Number","Entered NRI Residence Number as "+NRIResidence);
				  Thread.sleep(1000);
				  
				  NRI_Office = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Office_Number));
					cell = sheet.getRow(6).getCell(176);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String StayOffice = cell.getStringCellValue();
					System.out.println(StayOffice);
					NRI_Office.sendKeys(StayOffice);
					Extent_Reporting.Log_Pass("Entering NRI Office Number","Entered NRI Office Number as "+StayOffice);
				  Thread.sleep(1000);
				  
				  NRI_Mobile = driver.findElement(By.xpath(EApp_LandingPage.NRI_Abroad_Mobile_Number));
					cell = sheet.getRow(6).getCell(177);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					String NRIMobile = cell.getStringCellValue();
					System.out.println(NRIMobile);
					NRI_Mobile.sendKeys(NRIMobile);
					Extent_Reporting.Log_Pass("Entering NRI Mobile Number","Entered NRI Mobile Number as "+NRIMobile);
				  Thread.sleep(1000);
		 
				//Bank Details
					
				  Bank_Details = driver.findElement(By.xpath(EApp_LandingPage.NRI_Bank_Details));
				  Bank_Details.click();
					Extent_Reporting.Log_Pass("Clicking Bank Details","Clicked Bank Details");
					 Thread.sleep(1000); 
		
					 NRI_Account_No = driver.findElement(By.xpath(EApp_LandingPage.NRI_Account_No));
					 NRI_Account_No.click();
						Extent_Reporting.Log_Pass("Entering NRI Account Number","Entered NRI Account Number");
						 Thread.sleep(1000); 
		
						//Exchange Details
						
						  Exchange_Details = driver.findElement(By.xpath(EApp_LandingPage.NRI_Exchange_Details));
						  Exchange_Details.click();
							Extent_Reporting.Log_Pass("Clicking Exchange Details","Clicked Exchange Details");
							 Thread.sleep(1000); 
				
							 Exchange_Facility_No = driver.findElement(By.xpath(EApp_LandingPage.NRI_Exchange_Facility));
							 Exchange_Facility_No.click();
								Extent_Reporting.Log_Pass("Clicking Exchange Facility No","Clicked Exchange Facility No");
								 Thread.sleep(1000); 
			
		 //Payment Details
								 Payment_Details = driver.findElement(By.xpath(EApp_LandingPage.NRI_Payment_Details));
								 Payment_Details.click();
									Extent_Reporting.Log_Pass("Clicking Payment Details","Clicked Payment Details");
									 Thread.sleep(1000); 
						
									 NRI_Payment_NRE = driver.findElement(By.xpath(EApp_LandingPage.NRI_Payment_NRE));
									 NRI_Payment_NRE.click();
										Extent_Reporting.Log_Pass("Clicking NRI Payment - NRE","Clicked NRI Payment - NRE");
										 Thread.sleep(1000); 
						
										 NRI_IAgree = driver.findElement(By.xpath(EApp_LandingPage.NRI_IAgree));
										 NRI_IAgree.click();
											Extent_Reporting.Log_Pass("Clicking NRI IAgree","Clicked NRI IAgree");
											 Thread.sleep(1000);
						
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
			}
		 
        @SuppressWarnings("deprecation")
		public void Bank_details_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
		{
		   try
		   {
        //bank Details
        
        holder_Name=driver.findElement(By.xpath(EApp_LandingPage.AccountHolderNam));
		   cell = sheet.getRow(6).getCell(3);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String holdername = cell.getStringCellValue();
	       System.out.println(holdername);	
	       first_Name.sendKeys(holdername);
	       Extent_Reporting.Log_Pass("Enterng holdername","Entered holdername Successfully");
        
	       account_no=driver.findElement(By.xpath(EApp_LandingPage.AccountNum));
		   cell = sheet.getRow(6).getCell(3);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String accno = cell.getStringCellValue();
	       System.out.println(accno);	
	       first_Name.sendKeys(accno);
	       Extent_Reporting.Log_Pass("Enterng accno","Entered accno Successfully");
	       
	       Acc_type=driver.findElement(By.xpath(EApp_LandingPage.AccountType))	;
	       Acc_type.click();
	       
	       
	       ifsc_code=driver.findElement(By.xpath(EApp_LandingPage.IFSC));
	  		   cell = sheet.getRow(6).getCell(3);
	  	       cell.setCellType(Cell.CELL_TYPE_STRING);
	  	       String ifsccode = cell.getStringCellValue();
	  	       System.out.println(ifsccode);	
	  	       first_Name.sendKeys(ifsccode);
	  	       Extent_Reporting.Log_Pass("Enterng IFSC","Entered IFSC Successfully");
        
        
        Premium_pay=driver.findElement(By.xpath(EApp_LandingPage.PlusSign7));
        Premium_pay.click();
        
        
        Direct_bill=driver.findElement(By.xpath(EApp_LandingPage.DirectBill));
        Direct_bill.click();
        
        
        
        Iagree4=driver.findElement(By.xpath(EApp_LandingPage.Iagree4));
        Iagree4.click();
		   }
    	catch(Exception e)
		{
			Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
			e.printStackTrace();
		}
        
        
		   }
		   
        //Health details tab
        @SuppressWarnings("deprecation")
		public void Health_details_Prop_BSLI_life_secure_plan(WebDriver driver) throws InterruptedException
	  		{
	  		   try
	  		   { 
        
        //proposer
        
        Hight_feet=driver.findElement(By.xpath(EApp_LandingPage.HeightFt));
		   cell = sheet.getRow(6).getCell(3);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String hight_feet = cell.getStringCellValue();
	       System.out.println(hight_feet);	
	       Hight_feet.sendKeys(hight_feet);
	       Extent_Reporting.Log_Pass("Enterng hight in feet","Entered hight Successfully");
	       
	       Hight_inch=driver.findElement(By.xpath(EApp_LandingPage.HeightInch));
		   cell = sheet.getRow(6).getCell(3);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String Hightinch = cell.getStringCellValue();
	       System.out.println(Hightinch);	
	       Hight_inch.sendKeys(Hightinch);
	       Extent_Reporting.Log_Pass("Enterng hight in inch","Entered hight Successfully");
	       
	       Weight=driver.findElement(By.xpath(EApp_LandingPage.Weight));
		   cell = sheet.getRow(6).getCell(3);
	       cell.setCellType(Cell.CELL_TYPE_STRING);
	       String weight = cell.getStringCellValue();
	       System.out.println(weight);	
	       Weight.sendKeys(weight);
	       Extent_Reporting.Log_Pass("Enterng weight","Entered weight Successfully");
	       
	       weightChangetoggle=driver.findElement(By.xpath(EApp_LandingPage.Toggle17));
	       weightChangetoggle.click();
        
        
	       
	      
		       
				Weightchange=driver.findElement(By.xpath(EApp_LandingPage.WeightChanDetails));
				   cell = sheet.getRow(6).getCell(49);
			    cell.setCellType(Cell.CELL_TYPE_STRING);
			    String weightchange = cell.getStringCellValue();
			    System.out.println(weightchange);	
			    Weightchange.sendKeys(weight);
			       Extent_Reporting.Log_Pass("Enterng weight","Entered weight Successfully");
			    //life style information
		       lifestyleclick=driver.findElement(By.xpath(EApp_LandingPage.PlusSign8));
		       lifestyleclick.click();
	       
	   
	       
	    		   Travel_Outside=driver.findElement(By.xpath(EApp_LandingPage.travelno));
	    		   Travel_Outside.click();
	    		
	    		    Extent_Reporting.Log_Pass("Selecting Traveloutside","Selected Traveloutside");
	    		    
	    		    
	    	  		

	    		    Occupation=driver.findElement(By.xpath(EApp_LandingPage.occupation));
	    		    Occupation.click();
	    		    Extent_Reporting.Log_Pass("Selecting Occupation","Selected Occupation");
	    		    
	    		    
	    		    Consume=driver.findElement(By.xpath(EApp_LandingPage.consume));
	    		    Consume.click();
	    		    Extent_Reporting.Log_Pass("Selecting consume","Selected consume");
	    		    
	    		    
	    		    Consume_alcohol=driver.findElement(By.xpath(EApp_LandingPage.consume));
	    		    Consume_alcohol.click();
	    		    Extent_Reporting.Log_Pass("Selecting Consume_alcohol","Selected Consume_alcohol");
	    		    
	    		    
	    		    
	    		    Consume_cigaratte=driver.findElement(By.xpath(EApp_LandingPage.consume));
	    		    Consume_cigaratte.click();
	    		    Extent_Reporting.Log_Pass("Selecting Consume_cigaratte","Selected Consume_cigaratte");
	    		    
	    		    
	    		    //family medical history
	    		    
	    		   familyclick=driver.findElement(By.xpath(EApp_LandingPage.PlusSign9));
	    		   familyclick.click();
	    		   
	    		   Diseasenone=driver.findElement(By.xpath(EApp_LandingPage.FMHNone));
	    		   Diseasenone.click();
	    		   
	    		   
	    		   //sisage
	    		   FatherAge=driver.findElement(By.xpath(EApp_LandingPage.FatherAge));
				   cell = sheet.getRow(6).getCell(3);
			       cell.setCellType(Cell.CELL_TYPE_STRING);
			       String fatherAge = cell.getStringCellValue();
			       System.out.println(fatherAge);	
			       first_Name.sendKeys(fatherAge);
			       Extent_Reporting.Log_Pass("Enterng father age","Entered father age Successfully");
	    		   
					Fatherhealth_State=driver.findElement(By.xpath(EApp_LandingPage.FatherHealthState));
					   cell = sheet.getRow(6).getCell(15);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String fhealthState = cell.getStringCellValue();
				       System.out.println(fhealthState);	
				  
						Thread.sleep(1000);
						Fatherhealth_State = driver.findElement(By.xpath(EApp_LandingPage.Fhealthstateok));
						Fatherhealth_State.click();
						Thread.sleep(1000);
				       Extent_Reporting.Log_Pass("Entering father health State","Entered health State");
	    		    
				       
				       
				       
					  motherage=driver.findElement(By.xpath(EApp_LandingPage.MotherAge));
					   cell = sheet.getRow(6).getCell(3);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String motherage = cell.getStringCellValue();
				       System.out.println(motherage);	
				       first_Name.sendKeys(motherage);
				       Extent_Reporting.Log_Pass("Enterngmotherage","Enteredmotherage Successfully");
		    		   
						Motherhealth_State=driver.findElement(By.xpath(EApp_LandingPage.MotherHealthState));
						   cell = sheet.getRow(6).getCell(15);
					       cell.setCellType(Cell.CELL_TYPE_STRING);
					       String mhealthState = cell.getStringCellValue();
					       System.out.println(mhealthState);	
					    
							Thread.sleep(1000);
							Motherhealth_State = driver.findElement(By.xpath(EApp_LandingPage.MotherHealthStateok));
							Motherhealth_State.click();
							Thread.sleep(1000);
					       Extent_Reporting.Log_Pass("Entering mother healthState","Entered mother healthState State");
					       
					       
					       //brother
					       Havebrother=driver.findElement(By.xpath(EApp_LandingPage.Toggle23));
					       Havebrother.click();
					       //sister
					       
					       Havesis=driver.findElement(By.xpath(EApp_LandingPage.Toggle24));
					       Havesis.click();
					       
					       
							  sisterage=driver.findElement(By.xpath(EApp_LandingPage.SisterAge));
							   cell = sheet.getRow(6).getCell(3);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String sisterage = cell.getStringCellValue();
						       System.out.println(sisterage);	
						       first_Name.sendKeys(sisterage);
						       Extent_Reporting.Log_Pass("Enterngsisterage","Enteredsisterage Successfully");
					    		   
					       
						   	Sisterhealth_State=driver.findElement(By.xpath(EApp_LandingPage.SisterHealthState));
							   cell = sheet.getRow(6).getCell(15);
						       cell.setCellType(Cell.CELL_TYPE_STRING);
						       String shealthState = cell.getStringCellValue();
						       System.out.println(shealthState);	
						
								Thread.sleep(1000);
								Sisterhealth_State = driver.findElement(By.xpath(EApp_LandingPage.SisterHealthStateok));
								Sisterhealth_State.click();
								Thread.sleep(1000);
						       Extent_Reporting.Log_Pass("Entering sister health State","Entered sister healthState");
					       
					       
					       Add=driver.findElement(By.xpath(EApp_LandingPage.Add));
					       Add.click();
	    	
	    		    //medical history
					       
					       MedicalHistoryClick=driver.findElement(By.xpath(EApp_LandingPage.PlusSign10));
				              MedicalHistoryClick.click();
				          // Are you on diet or any other medicine of any kind as prescribed by a doctor?
				              Medicine=driver.findElement(By.xpath(EApp_LandingPage.medicine));
				              Medicine.click();
				              //Consulted any doctor or health practitioner except for common cold, influenza lasting less than 4 days?
				              Medicine_cold=driver.findElement(By.xpath(EApp_LandingPage.medicine1));
				              Medicine_cold.click();
				             // Submitted to an ECG, X- rays, blood tests or any other tests?
				              Medicine_ECG=driver.findElement(By.xpath(EApp_LandingPage.medicine2));
				              Medicine_ECG.click();
				              //Admitted /been advised to be admitted to any hospital or a medical facility for medical management or surgical procedure?
				              Medicine_admit=driver.findElement(By.xpath(EApp_LandingPage.medicine3));
				              Medicine_admit.click();
				              // No I Have never sought advice or suffered from any of the above? 
				              Medicine_never=driver.findElement(By.xpath(EApp_LandingPage.never));
				              Medicine_never.click();
				              //Do you have any physical defects, impairment, deformities and / or any condition affecting mobility, sight and / or hearing?
				              Medicine_defects=driver.findElement(By.xpath(EApp_LandingPage.defects));
				              Medicine_defects.click();
				              //Do you have any health symptoms or complaints for which a physician has not been consulted or treatment received? (persistent fever, unexplained weight loss, loss of appetite, pain, swelling etc.)
				              Medicine_symptoms=driver.findElement(By.xpath(EApp_LandingPage.symptoms));
				              Medicine_symptoms.click();
				              //Have you or your spouse received any medical advice, testing or treatment for any sexually transmitted disease or HIV Infection / AIDS?
				              Medicine_HIV=driver.findElement(By.xpath(EApp_LandingPage.HIV));
				              Medicine_HIV.click();
				              //I Agree
				              Medicine_agree=driver.findElement(By.xpath(EApp_LandingPage.agree));
				              Medicine_agree.click();
					      
							}
	  			catch(Exception e)
	  			{
	  				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	  				e.printStackTrace();
	  			}
	  		}
        
		   //IAR
@SuppressWarnings("deprecation")
public void IAR_NRI(WebDriver driver) throws IOException, InterruptedException {
	try {
		FileInputStream finput = new FileInputStream(src);
		  workbook = new XSSFWorkbook(finput);
		  sheet= workbook.getSheetAt(3);		
 
		                                     
											
	/* IAR_Tab = driver.findElement(By.xpath(EApp_LandingPage.IAR_Tab));
	 IAR_Tab.click();
	  */Thread.sleep(2000);
	 
											 IAR_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.middleName));
												cell = sheet.getRow(6).getCell(186);
												cell.setCellType(Cell.CELL_TYPE_STRING);
												String IARMiddleName = cell.getStringCellValue();
												System.out.println(IARMiddleName);
												IAR_MiddleName.sendKeys(IARMiddleName);
												Extent_Reporting.Log_Pass("Entering IAR Middle Name","Entered IAR Middle Name as "+IARMiddleName);
											  Thread.sleep(1000);
									
											  IAR_NonMedical = driver.findElement(By.xpath(EApp_LandingPage.nonMedical));
											  IAR_NonMedical.click();
													Extent_Reporting.Log_Pass("Clicking IAR Non Medical","Clicked IAR Non Medical");
													 Thread.sleep(1000);
													
													
													 IAR_AgeProof = driver.findElement(By.xpath(EApp_LandingPage.ageProof_Dropdown));
													/*	cell = sheet.getRow(6).getCell(188);
														cell.setCellType(Cell.CELL_TYPE_STRING);
														String AgeProof = cell.getStringCellValue();*/
														System.out.println("Aadhar Card"); 
													 Select IARAgeProof = new Select(IAR_AgeProof);
													 IARAgeProof.selectByValue("1");	
														Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

													 IAR_Personally_Met_Yes = driver.findElement(By.xpath(EApp_LandingPage.Toggle1_IAR_Yes));
													 IAR_Personally_Met_Yes.click();
															Extent_Reporting.Log_Pass("Clicking IAR Personally Met","Clicked IAR Personally Met");
															 Thread.sleep(1000); 
													
															//Scroll
																JavascriptExecutor jse20 = (JavascriptExecutor)driver;
																jse20.executeScript("window.scrollBy(0,80)", "");
																Thread.sleep(1000);
															 
															 Applicant_Request = driver.findElement(By.xpath(EApp_LandingPage.applicant_Request));
															 Applicant_Request.click();
																	Extent_Reporting.Log_Pass("Clicking Applicant Request","Clicked Applicant Request");
																	 Thread.sleep(1000); 
													
																	//Scroll
																		JavascriptExecutor jse19 = (JavascriptExecutor)driver;
																		jse19.executeScript("window.scrollBy(0,180)", "");
																		Thread.sleep(1000);
																	
																	 Cluster_Market = driver.findElement(By.xpath(EApp_LandingPage.clusterName));
																		cell = sheet.getRow(6).getCell(191);
																		cell.setCellType(Cell.CELL_TYPE_STRING);
																		String ClusterMarket = cell.getStringCellValue();
																		System.out.println(ClusterMarket);
																		Cluster_Market.sendKeys(ClusterMarket);
																		Extent_Reporting.Log_Pass("Entering Cluster Market","Entered Cluster Market as "+ClusterMarket);
																	

																		 IAR_Years = driver.findElement(By.xpath(EApp_LandingPage.IAR_years));
																			cell = sheet.getRow(6).getCell(192);
																			cell.setCellType(Cell.CELL_TYPE_STRING);
																			String IARYears = cell.getStringCellValue();
																			System.out.println(IARYears);
																			IAR_Years.sendKeys(IARYears);
																			Extent_Reporting.Log_Pass("Entering IAR Years","Entered IAR Years as "+IARYears);
																		

																			 IAR_Months = driver.findElement(By.xpath(EApp_LandingPage.IAR_months));
																				cell = sheet.getRow(6).getCell(193);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARMonths = cell.getStringCellValue();
																				System.out.println(IARMonths);
																				IAR_Months.sendKeys(IARMonths);
																				Extent_Reporting.Log_Pass("Entering IAR Months","Entered IAR Months as "+IARMonths);
																			
																				//Scroll
																				JavascriptExecutor jse21 = (JavascriptExecutor)driver;
																				jse21.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_Protection = driver.findElement(By.xpath(EApp_LandingPage.IAR_protection));
																				IAR_Protection.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Protection","Clicked IAR Protection");
																				Thread.sleep(1000); 
															
																				//Scroll
																				JavascriptExecutor jse18 = (JavascriptExecutor)driver;
																				jse18.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_How_Calculate = driver.findElement(By.xpath(EApp_LandingPage.IAR_howCalculate));
																				cell = sheet.getRow(6).getCell(195);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_HowCalculate = cell.getStringCellValue();
																				System.out.println(IAR_HowCalculate);
																				IAR_How_Calculate.sendKeys(IAR_HowCalculate);
																				Extent_Reporting.Log_Pass("Entering IAR How Calculate","Entered IAR How Calculate as "+IAR_HowCalculate);
																						
																				IAR_Realistic = driver.findElement(By.xpath(EApp_LandingPage.IAR_realistic_Estimate));
																				cell = sheet.getRow(6).getCell(196);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARRealistic = cell.getStringCellValue();
																				System.out.println(IARRealistic);
																				IAR_Realistic.sendKeys(IARRealistic);
																				Extent_Reporting.Log_Pass("Entering IAR Realistic","Entered IAR Realistic as "+IARRealistic);
																				
																				IAR_Investments = driver.findElement(By.xpath(EApp_LandingPage.IAR_Investments));
																				cell = sheet.getRow(6).getCell(197);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARInvestments = cell.getStringCellValue();
																				System.out.println(IARInvestments);
																				IAR_Investments.sendKeys(IARInvestments);
																				Extent_Reporting.Log_Pass("Entering IAR Investments","Entered IAR Investments as "+IARInvestments);
																				
																				//Scroll
																				JavascriptExecutor jse23 = (JavascriptExecutor)driver;
																				jse23.executeScript("window.scrollBy(0,250)", "");
																				Thread.sleep(1000);
																				
																				IAR_Liabilities = driver.findElement(By.xpath(EApp_LandingPage.IAR_liabilities));
																				cell = sheet.getRow(6).getCell(198);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARLiabilities = cell.getStringCellValue();
																				System.out.println(IARLiabilities);
																				IAR_Liabilities.sendKeys(IARLiabilities);
																				Extent_Reporting.Log_Pass("Entering IAR Liabilities","Entered IAR Liabilities as "+IARLiabilities);
																				
																				IAR_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.Toggle2_IAR));
																				IAR_Toggle2.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 2","Clicked IAR Toggle 2");
																				Thread.sleep(1000); 
															
																				IAR_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.Toggle3_IAR));
																				IAR_Toggle3.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 3","Clicked IAR Toggle 3");
																				Thread.sleep(1000);

																				IAR_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.Toggle4_IAR));
																				IAR_Toggle4.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 4","Clicked IAR Toggle 4");
																				Thread.sleep(1000);

																				IAR_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.Toggle5_IAR));
																				IAR_Toggle5.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 5","Clicked IAR Toggle 5");
																				Thread.sleep(1000);

																				IAR_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.Toggle6_IAR));
																				IAR_Toggle6.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 6","Clicked IAR Toggle 6");
																				Thread.sleep(1000);
																				
																				IAR_Other_Remarks = driver.findElement(By.xpath(EApp_LandingPage.otherRemarks));
																				cell = sheet.getRow(6).getCell(204);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_OtherRemarks = cell.getStringCellValue();
																				System.out.println(IAR_OtherRemarks);
																				IAR_Other_Remarks.sendKeys(IAR_OtherRemarks);
																				Extent_Reporting.Log_Pass("Entering IAR Other Remarks","Entered IAR Other Remarks as "+IAR_OtherRemarks);
																				Thread.sleep(2000);

																				IAR_IAgree = driver.findElement(By.xpath(EApp_LandingPage.IAR_IAgree));
																				IAR_IAgree.click();
																				Extent_Reporting.Log_Pass("Clicking IAR I Agree","Clicked IAR Agree");
																				Thread.sleep(2000);
																				
	}
	catch(Exception e)
	{
		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
		e.printStackTrace();
	}
	}

//IAR_Same
							@SuppressWarnings("deprecation")
							public void IAR_Same(WebDriver driver) throws IOException, InterruptedException {
						try {
							FileInputStream finput = new FileInputStream(src);
							  workbook = new XSSFWorkbook(finput);
							  sheet= workbook.getSheetAt(1);		

		                                     
											
						/* IAR_Tab = driver.findElement(By.xpath(EApp_LandingPage.IAR_Tab));
						 IAR_Tab.click();
						  */Thread.sleep(2000);
						 
											 IAR_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.middleName));
												cell = sheet.getRow(6).getCell(183);
												cell.setCellType(Cell.CELL_TYPE_STRING);
												String IARMiddleName = cell.getStringCellValue();
												System.out.println(IARMiddleName);
												IAR_MiddleName.sendKeys(IARMiddleName);
												Extent_Reporting.Log_Pass("Entering IAR Middle Name","Entered IAR Middle Name as "+IARMiddleName);
											  Thread.sleep(1000);
									
											  IAR_NonMedical = driver.findElement(By.xpath(EApp_LandingPage.nonMedical));
											  IAR_NonMedical.click();
													Extent_Reporting.Log_Pass("Clicking IAR Non Medical","Clicked IAR Non Medical");
													 Thread.sleep(1000);
													
													
													 IAR_AgeProof = driver.findElement(By.xpath(EApp_LandingPage.ageProof_Dropdown));
													/*	cell = sheet.getRow(6).getCell(188);
														cell.setCellType(Cell.CELL_TYPE_STRING);
														String AgeProof = cell.getStringCellValue();*/
														System.out.println("Aadhar Card"); 
													 Select IARAgeProof = new Select(IAR_AgeProof);
													 IARAgeProof.selectByValue("1");	
														Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

													 IAR_Personally_Met_Yes = driver.findElement(By.xpath(EApp_LandingPage.Toggle1_IAR_Yes));
													 IAR_Personally_Met_Yes.click();
															Extent_Reporting.Log_Pass("Clicking IAR Personally Met","Clicked IAR Personally Met");
															 Thread.sleep(1000); 
													
															//Scroll
																JavascriptExecutor jse20 = (JavascriptExecutor)driver;
																jse20.executeScript("window.scrollBy(0,80)", "");
																Thread.sleep(1000);
															 
															 Applicant_Request = driver.findElement(By.xpath(EApp_LandingPage.applicant_Request));
															 Applicant_Request.click();
																	Extent_Reporting.Log_Pass("Clicking Applicant Request","Clicked Applicant Request");
																	 Thread.sleep(1000); 
													
																	//Scroll
																		JavascriptExecutor jse19 = (JavascriptExecutor)driver;
																		jse19.executeScript("window.scrollBy(0,180)", "");
																		Thread.sleep(1000);
																	
																	 Cluster_Market = driver.findElement(By.xpath(EApp_LandingPage.clusterName));
																		cell = sheet.getRow(6).getCell(189);
																		cell.setCellType(Cell.CELL_TYPE_STRING);
																		String ClusterMarket = cell.getStringCellValue();
																		System.out.println(ClusterMarket);
																		Cluster_Market.sendKeys(ClusterMarket);
																		Extent_Reporting.Log_Pass("Entering Cluster Market","Entered Cluster Market as "+ClusterMarket);
																	

																		 IAR_Years = driver.findElement(By.xpath(EApp_LandingPage.IAR_years));
																			cell = sheet.getRow(6).getCell(190);
																			cell.setCellType(Cell.CELL_TYPE_STRING);
																			String IARYears = cell.getStringCellValue();
																			System.out.println(IARYears);
																			IAR_Years.sendKeys(IARYears);
																			Extent_Reporting.Log_Pass("Entering IAR Years","Entered IAR Years as "+IARYears);
																		

																			 IAR_Months = driver.findElement(By.xpath(EApp_LandingPage.IAR_months));
																				cell = sheet.getRow(6).getCell(191);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARMonths = cell.getStringCellValue();
																				System.out.println(IARMonths);
																				IAR_Months.sendKeys(IARMonths);
																				Extent_Reporting.Log_Pass("Entering IAR Months","Entered IAR Months as "+IARMonths);
																			
																				//Scroll
																				JavascriptExecutor jse21 = (JavascriptExecutor)driver;
																				jse21.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_Protection = driver.findElement(By.xpath(EApp_LandingPage.IAR_protection));
																				IAR_Protection.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Protection","Clicked IAR Protection");
																				Thread.sleep(1000); 
															
																				//Scroll
																				JavascriptExecutor jse18 = (JavascriptExecutor)driver;
																				jse18.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_How_Calculate = driver.findElement(By.xpath(EApp_LandingPage.IAR_howCalculate));
																				cell = sheet.getRow(6).getCell(193);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_HowCalculate = cell.getStringCellValue();
																				System.out.println(IAR_HowCalculate);
																				IAR_How_Calculate.sendKeys(IAR_HowCalculate);
																				Extent_Reporting.Log_Pass("Entering IAR How Calculate","Entered IAR How Calculate as "+IAR_HowCalculate);
																						
																				IAR_Realistic = driver.findElement(By.xpath(EApp_LandingPage.IAR_realistic_Estimate));
																				cell = sheet.getRow(6).getCell(194);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARRealistic = cell.getStringCellValue();
																				System.out.println(IARRealistic);
																				IAR_Realistic.sendKeys(IARRealistic);
																				Extent_Reporting.Log_Pass("Entering IAR Realistic","Entered IAR Realistic as "+IARRealistic);
																				
																				IAR_Investments = driver.findElement(By.xpath(EApp_LandingPage.IAR_Investments));
																				cell = sheet.getRow(6).getCell(195);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARInvestments = cell.getStringCellValue();
																				System.out.println(IARInvestments);
																				IAR_Investments.sendKeys(IARInvestments);
																				Extent_Reporting.Log_Pass("Entering IAR Investments","Entered IAR Investments as "+IARInvestments);
																				
																				//Scroll
																				JavascriptExecutor jse23 = (JavascriptExecutor)driver;
																				jse23.executeScript("window.scrollBy(0,250)", "");
																				Thread.sleep(1000);
																				
																				IAR_Liabilities = driver.findElement(By.xpath(EApp_LandingPage.IAR_liabilities));
																				cell = sheet.getRow(6).getCell(196);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARLiabilities = cell.getStringCellValue();
																				System.out.println(IARLiabilities);
																				IAR_Liabilities.sendKeys(IARLiabilities);
																				Extent_Reporting.Log_Pass("Entering IAR Liabilities","Entered IAR Liabilities as "+IARLiabilities);
																				
																				IAR_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.Toggle2_IAR));
																				IAR_Toggle2.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 2","Clicked IAR Toggle 2");
																				Thread.sleep(1000); 
															
																				IAR_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.Toggle3_IAR));
																				IAR_Toggle3.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 3","Clicked IAR Toggle 3");
																				Thread.sleep(1000);

																				IAR_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.Toggle4_IAR));
																				IAR_Toggle4.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 4","Clicked IAR Toggle 4");
																				Thread.sleep(1000);

																				IAR_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.Toggle5_IAR));
																				IAR_Toggle5.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 5","Clicked IAR Toggle 5");
																				Thread.sleep(1000);

																				IAR_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.Toggle6_IAR));
																				IAR_Toggle6.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 6","Clicked IAR Toggle 6");
																				Thread.sleep(1000);
																				
																				IAR_Other_Remarks = driver.findElement(By.xpath(EApp_LandingPage.otherRemarks));
																				cell = sheet.getRow(6).getCell(204);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_OtherRemarks = cell.getStringCellValue();
																				System.out.println(IAR_OtherRemarks);
																				IAR_Other_Remarks.sendKeys(IAR_OtherRemarks);
																				Extent_Reporting.Log_Pass("Entering IAR Other Remarks","Entered IAR Other Remarks as "+IAR_OtherRemarks);
																				Thread.sleep(2000);

																				IAR_IAgree = driver.findElement(By.xpath(EApp_LandingPage.IAR_IAgree));
																				IAR_IAgree.click();
																				Extent_Reporting.Log_Pass("Clicking IAR I Agree","Clicked IAR Agree");
																				Thread.sleep(2000);
																				
	}
	catch(Exception e)
	{
		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
		e.printStackTrace();
	}
	}


//IAR_Same - ULIP
@SuppressWarnings("deprecation")
public void IAR_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
	try {
		FileInputStream finput = new FileInputStream(src);
		  workbook = new XSSFWorkbook(finput);
		  sheet= workbook.getSheetAt(2);		

		                                     
											
	/* IAR_Tab = driver.findElement(By.xpath(EApp_LandingPage.IAR_Tab));
	 IAR_Tab.click();
	  */Thread.sleep(2000);
	 
											 IAR_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.middleName));
												cell = sheet.getRow(6).getCell(180);
												cell.setCellType(Cell.CELL_TYPE_STRING);
												String IARMiddleName = cell.getStringCellValue();
												System.out.println(IARMiddleName);
												IAR_MiddleName.sendKeys(IARMiddleName);
												Extent_Reporting.Log_Pass("Entering IAR Middle Name","Entered IAR Middle Name as "+IARMiddleName);
											  Thread.sleep(1000);
									
											  IAR_NonMedical = driver.findElement(By.xpath(EApp_LandingPage.nonMedical));
											  IAR_NonMedical.click();
													Extent_Reporting.Log_Pass("Clicking IAR Non Medical","Clicked IAR Non Medical");
													 Thread.sleep(1000);
													
													
													 IAR_AgeProof = driver.findElement(By.xpath(EApp_LandingPage.ageProof_Dropdown));
													/*	cell = sheet.getRow(6).getCell(188);
														cell.setCellType(Cell.CELL_TYPE_STRING);
														String AgeProof = cell.getStringCellValue();*/
														System.out.println("Aadhar Card"); 
													 Select IARAgeProof = new Select(IAR_AgeProof);
													 IARAgeProof.selectByValue("1");	
														Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

													 IAR_Personally_Met_Yes = driver.findElement(By.xpath(EApp_LandingPage.Toggle1_IAR_Yes));
													 IAR_Personally_Met_Yes.click();
															Extent_Reporting.Log_Pass("Clicking IAR Personally Met","Clicked IAR Personally Met");
															 Thread.sleep(1000); 
													
															//Scroll
																JavascriptExecutor jse20 = (JavascriptExecutor)driver;
																jse20.executeScript("window.scrollBy(0,80)", "");
																Thread.sleep(1000);
															 
															 Applicant_Request = driver.findElement(By.xpath(EApp_LandingPage.applicant_Request));
															 Applicant_Request.click();
																	Extent_Reporting.Log_Pass("Clicking Applicant Request","Clicked Applicant Request");
																	 Thread.sleep(1000); 
													
																	//Scroll
																		JavascriptExecutor jse19 = (JavascriptExecutor)driver;
																		jse19.executeScript("window.scrollBy(0,180)", "");
																		Thread.sleep(1000);
																	
																	 Cluster_Market = driver.findElement(By.xpath(EApp_LandingPage.clusterName));
																		cell = sheet.getRow(6).getCell(186);
																		cell.setCellType(Cell.CELL_TYPE_STRING);
																		String ClusterMarket = cell.getStringCellValue();
																		System.out.println(ClusterMarket);
																		Cluster_Market.sendKeys(ClusterMarket);
																		Extent_Reporting.Log_Pass("Entering Cluster Market","Entered Cluster Market as "+ClusterMarket);
																	

																		 IAR_Years = driver.findElement(By.xpath(EApp_LandingPage.IAR_years));
																			cell = sheet.getRow(6).getCell(187);
																			cell.setCellType(Cell.CELL_TYPE_STRING);
																			String IARYears = cell.getStringCellValue();
																			System.out.println(IARYears);
																			IAR_Years.sendKeys(IARYears);
																			Extent_Reporting.Log_Pass("Entering IAR Years","Entered IAR Years as "+IARYears);
																		

																			 IAR_Months = driver.findElement(By.xpath(EApp_LandingPage.IAR_months));
																				cell = sheet.getRow(6).getCell(188);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARMonths = cell.getStringCellValue();
																				System.out.println(IARMonths);
																				IAR_Months.sendKeys(IARMonths);
																				Extent_Reporting.Log_Pass("Entering IAR Months","Entered IAR Months as "+IARMonths);
																			
																				//Scroll
																				JavascriptExecutor jse21 = (JavascriptExecutor)driver;
																				jse21.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_Protection = driver.findElement(By.xpath(EApp_LandingPage.IAR_protection));
																				IAR_Protection.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Protection","Clicked IAR Protection");
																				Thread.sleep(1000); 
															
																				//Scroll
																				JavascriptExecutor jse18 = (JavascriptExecutor)driver;
																				jse18.executeScript("window.scrollBy(0,100)", "");
																				Thread.sleep(1000);
																				
																				IAR_How_Calculate = driver.findElement(By.xpath(EApp_LandingPage.IAR_howCalculate));
																				cell = sheet.getRow(6).getCell(190);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_HowCalculate = cell.getStringCellValue();
																				System.out.println(IAR_HowCalculate);
																				IAR_How_Calculate.sendKeys(IAR_HowCalculate);
																				Extent_Reporting.Log_Pass("Entering IAR How Calculate","Entered IAR How Calculate as "+IAR_HowCalculate);
																						
																				IAR_Realistic = driver.findElement(By.xpath(EApp_LandingPage.IAR_realistic_Estimate));
																				cell = sheet.getRow(6).getCell(191);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARRealistic = cell.getStringCellValue();
																				System.out.println(IARRealistic);
																				IAR_Realistic.sendKeys(IARRealistic);
																				Extent_Reporting.Log_Pass("Entering IAR Realistic","Entered IAR Realistic as "+IARRealistic);
																				
																				IAR_Investments = driver.findElement(By.xpath(EApp_LandingPage.IAR_Investments));
																				cell = sheet.getRow(6).getCell(192);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARInvestments = cell.getStringCellValue();
																				System.out.println(IARInvestments);
																				IAR_Investments.sendKeys(IARInvestments);
																				Extent_Reporting.Log_Pass("Entering IAR Investments","Entered IAR Investments as "+IARInvestments);
																				
																				//Scroll
																				JavascriptExecutor jse23 = (JavascriptExecutor)driver;
																				jse23.executeScript("window.scrollBy(0,250)", "");
																				Thread.sleep(1000);
																				
																				IAR_Liabilities = driver.findElement(By.xpath(EApp_LandingPage.IAR_liabilities));
																				cell = sheet.getRow(6).getCell(193);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IARLiabilities = cell.getStringCellValue();
																				System.out.println(IARLiabilities);
																				IAR_Liabilities.sendKeys(IARLiabilities);
																				Extent_Reporting.Log_Pass("Entering IAR Liabilities","Entered IAR Liabilities as "+IARLiabilities);
																				
																				IAR_Toggle2 = driver.findElement(By.xpath(EApp_LandingPage.Toggle2_IAR));
																				IAR_Toggle2.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 2","Clicked IAR Toggle 2");
																				Thread.sleep(1000); 
															
																				IAR_Toggle3 = driver.findElement(By.xpath(EApp_LandingPage.Toggle3_IAR));
																				IAR_Toggle3.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 3","Clicked IAR Toggle 3");
																				Thread.sleep(1000);

																				IAR_Toggle4 = driver.findElement(By.xpath(EApp_LandingPage.Toggle4_IAR));
																				IAR_Toggle4.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 4","Clicked IAR Toggle 4");
																				Thread.sleep(1000);

																				IAR_Toggle5 = driver.findElement(By.xpath(EApp_LandingPage.Toggle5_IAR));
																				IAR_Toggle5.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 5","Clicked IAR Toggle 5");
																				Thread.sleep(1000);

																				IAR_Toggle6 = driver.findElement(By.xpath(EApp_LandingPage.Toggle6_IAR));
																				IAR_Toggle6.click();
																				Extent_Reporting.Log_Pass("Clicking IAR Toggle 6","Clicked IAR Toggle 6");
																				Thread.sleep(1000);
																				
																				IAR_Other_Remarks = driver.findElement(By.xpath(EApp_LandingPage.otherRemarks));
																				cell = sheet.getRow(6).getCell(199);
																				cell.setCellType(Cell.CELL_TYPE_STRING);
																				String IAR_OtherRemarks = cell.getStringCellValue();
																				System.out.println(IAR_OtherRemarks);
																				IAR_Other_Remarks.sendKeys(IAR_OtherRemarks);
																				Extent_Reporting.Log_Pass("Entering IAR Other Remarks","Entered IAR Other Remarks as "+IAR_OtherRemarks);
																				Thread.sleep(2000);

																				IAR_IAgree = driver.findElement(By.xpath(EApp_LandingPage.IAR_IAgree));
																				IAR_IAgree.click();
																				Extent_Reporting.Log_Pass("Clicking IAR I Agree","Clicked IAR Agree");
																				Thread.sleep(2000);
																				
	}
	catch(Exception e)
	{
		Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
		e.printStackTrace();
	}
	}



//Review and Acceptance
@SuppressWarnings("deprecation")
public void Review_and_Acceptance(WebDriver driver) throws IOException, InterruptedException {
try {
																				
	JavascriptExecutor jse24 = (JavascriptExecutor)driver;
	jse24.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(1000);
	
	Place_Of_Application = driver.findElement(By.xpath(EApp_LandingPage.applicationPlace));
	String Place_OfApplication = "Mumbai";
	System.out.println(Place_OfApplication);
	Place_Of_Application.sendKeys(Place_OfApplication);
	Extent_Reporting.Log_Pass("Entering IAR Other Remarks","Entered IAR Other Remarks as "+Place_OfApplication);		
	
	Reviewed_Accepted = driver.findElement(By.xpath(EApp_LandingPage.final_button));
	Reviewed_Accepted.click();
	Extent_Reporting.Log_Pass("Clicking Reviewed and Accepted","Clicked Reviewed and Accepted");
	Thread.sleep(15000);

	//Scroll
	JavascriptExecutor jse25 = (JavascriptExecutor)driver;
	jse25.executeScript("window.scrollBy(0,500)", "");
	Thread.sleep(1000);
	
	
	Enter_OTP = driver.findElement(By.xpath(EApp_LandingPage.otp_input));
	Enter_OTP.sendKeys("123456");
	Extent_Reporting.Log_Pass("Entering OTP","Entered OTP as 123456");		
	
	Submit_OTP = driver.findElement(By.xpath(EApp_LandingPage.submit_otp));
	Submit_OTP.click();
	Extent_Reporting.Log_Pass("Clicking Submit button","Clicked Submit button");
	Thread.sleep(5000);

}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}

//Document Upload
@SuppressWarnings("deprecation")
public void Document_Upload_NRI(WebDriver driver) throws IOException, InterruptedException {
try {
FileInputStream finput = new FileInputStream(src);
workbook = new XSSFWorkbook(finput);
sheet= workbook.getSheetAt(3);		
	
																				Identity_Proof = driver.findElement(By.xpath(EApp_LandingPage.identity_Proof));
																				Identity_Proof.click();
																	            Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");
																	            Thread.sleep(1000);

																				Identity_Proof_Document_Type = driver.findElement(By.xpath(EApp_LandingPage.typeOfDocument));

																	            Select Identity_Proof_DocumentType = new Select(Identity_Proof_Document_Type);
																	            Identity_Proof_DocumentType.selectByValue("1");	
																					Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

																					Identity_Proof_Browse_Button = driver.findElement(By.xpath(EApp_LandingPage.browseButton));
																					Identity_Proof_Browse_Button.click();
																		            Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");
																			
																		            Thread.sleep(500);
																		            StringSelection ss = new StringSelection(fileUploadPath);
																		              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

																		              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																		              Robot robot = new Robot();
																		              robot.delay(250);
																		              robot.keyPress(KeyEvent.VK_ENTER);
																		              robot.keyRelease(KeyEvent.VK_ENTER);
																		              robot.keyPress(KeyEvent.VK_CONTROL);
																		              robot.keyPress(KeyEvent.VK_V);
																		              robot.keyRelease(KeyEvent.VK_V);
																		              robot.keyRelease(KeyEvent.VK_CONTROL);
																		              robot.keyPress(KeyEvent.VK_ENTER);
																		              robot.delay(50);
																		              robot.keyRelease(KeyEvent.VK_ENTER);
																			            Extent_Reporting.Log_Pass("Selecting Identity Proof image","Selecting Identity Proof image");
                                                                                                Thread.sleep(1000);
																		              Identity_Proof_Agree_Button = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
																		              Identity_Proof_Agree_Button.click();
																			            Extent_Reporting.Log_Pass("Clicking Identity Proof Agree Button","Clicked Identity Proof Agree Button");
																			
																			            Thread.sleep(5000);
																			
																			              Identity_Proof_Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
																			              Identity_Proof_Close_Button.click();
																				            Extent_Reporting.Log_Pass("Clicking Identity Proof Close Button","Clicked Identity Proof Close Button");
																				            Thread.sleep(1000);
																				            
																				            System.out.println("Identity_Proof_Agree_Button");

																				            //Income Proof
																				            Income_Proof = driver.findElement(By.xpath(EApp_LandingPage.incomeProof));
																				            Income_Proof.click();
																				            Extent_Reporting.Log_Pass("Clicking Income Proof","Clicked Income Proof");
																				            Thread.sleep(1000);
																				
																							Income_Proof_Document_Type = driver.findElement(By.xpath(EApp_LandingPage.incomeProof_Type));

																				            Select Income_Proof_DocumentType = new Select(Income_Proof_Document_Type);
																				            Income_Proof_DocumentType.selectByValue("41");	
																								Extent_Reporting.Log_Pass("Selecting Income Proof Document Type","Selected Income Proof Document Type");

																								Income_Proof_Browse_Button = driver.findElement(By.xpath(EApp_LandingPage.incomeProof_browse));
																								Income_Proof_Browse_Button.click();
																					            Extent_Reporting.Log_Pass("Clicking Income Proof Browse Button","Clicked Income Proof Browse Button");
																						
																					            Thread.sleep(500);
																					            StringSelection ss7 = new StringSelection(fileUploadPath);
																					              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss7, null);

																					              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																					              Robot robot7 = new Robot();
																					              robot7.delay(250);
																					              robot7.keyPress(KeyEvent.VK_ENTER);
																					              robot7.keyRelease(KeyEvent.VK_ENTER);
																					              robot7.keyPress(KeyEvent.VK_CONTROL);
																					              robot7.keyPress(KeyEvent.VK_V);
																					              robot7.keyRelease(KeyEvent.VK_V);
																					              robot7.keyRelease(KeyEvent.VK_CONTROL);
																					              robot7.keyPress(KeyEvent.VK_ENTER);
																					              robot7.delay(50);
																					              robot7.keyRelease(KeyEvent.VK_ENTER);
																						            Extent_Reporting.Log_Pass("Selecting Income Proof image","Selecting Income Proof image");
																						              Thread.sleep(1000);

																					              Income_Proof_Agree_Button = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
																					              Income_Proof_Agree_Button.click();
																						            Extent_Reporting.Log_Pass("Clicking Income Proof Agree Button","Clicked Income Proof Agree Button");
																						
																						            Thread.sleep(5000);
																						
																						              Income_Proof_Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
																						              Income_Proof_Close_Button.click();
																							            Extent_Reporting.Log_Pass("Clicking Identity Proof Close Button","Clicked Identity Proof Close Button");
																							            Thread.sleep(1000);

																							            System.out.println("Income_Proof_Agree_Button");

																							            
																							            Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.nonMedicalRequirements));
																							            Non_Medical_Requirements.click();
																								            Extent_Reporting.Log_Pass("Clicking Non Medical Requirements","Clicked Non Medical Requirements");
																								            Thread.sleep(1000);
																							
																								            Cancelled_Cheque = driver.findElement(By.xpath(EApp_LandingPage.neft_Cancelled_Cheque));
																								            Cancelled_Cheque.click();
																									            Extent_Reporting.Log_Pass("Clicking NEFT Cancelled Cheque Browse Button","Clicked NEFT Cancelled Cheque Browse Button");
																									            Thread.sleep(1000);
																								
																									            StringSelection ss6 = new StringSelection(fileUploadPath);
																									              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss6, null);

																									              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																									              Robot robot6 = new Robot();
																									              robot6.delay(250);
																									              robot6.keyPress(KeyEvent.VK_ENTER);
																									              robot6.keyRelease(KeyEvent.VK_ENTER);
																									              robot6.keyPress(KeyEvent.VK_CONTROL);
																									              robot6.keyPress(KeyEvent.VK_V);
																									              robot6.keyRelease(KeyEvent.VK_V);
																									              robot6.keyRelease(KeyEvent.VK_CONTROL);
																									              robot6.keyPress(KeyEvent.VK_ENTER);
																									              robot6.delay(50);
																									              robot6.keyRelease(KeyEvent.VK_ENTER);			
																										            Extent_Reporting.Log_Pass("Selecting Cancelled Checque image","Selecting Cancelled Checque image");
																										              Thread.sleep(1000);

																											            System.out.println("Cancelled Cheque");

																									              Passport_Copy = driver.findElement(By.xpath(EApp_LandingPage.passport_Copy));
																									              Passport_Copy.click();
																											            Extent_Reporting.Log_Pass("Clicking Passport Copy Browse Button","Clicked Passport Copy Browse Button");
																											            Thread.sleep(1000);
																										
																											            StringSelection ss5 = new StringSelection(fileUploadPath);
																											              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss5, null);

																											              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																											              Robot robot5 = new Robot();
																											              robot5.delay(250);
																											              robot5.keyPress(KeyEvent.VK_ENTER);
																											              robot5.keyRelease(KeyEvent.VK_ENTER);
																											              robot5.keyPress(KeyEvent.VK_CONTROL);
																											              robot5.keyPress(KeyEvent.VK_V);
																											              robot5.keyRelease(KeyEvent.VK_V);
																											              robot5.keyRelease(KeyEvent.VK_CONTROL);
																											              robot5.keyPress(KeyEvent.VK_ENTER);
																											              robot5.delay(50);
																											              robot5.keyRelease(KeyEvent.VK_ENTER);			
																												            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
																							              Thread.sleep(1000);
																						
																								            System.out.println("Passport_Copy");

				                                                                               //Photograph
																								            
																								            //Scroll
																											JavascriptExecutor jse27 = (JavascriptExecutor)driver;
																											jse27.executeScript("window.scrollBy(0,100)", "");
																											Thread.sleep(1000);	              
																													              Photograph = driver.findElement(By.xpath(EApp_LandingPage.photograph));
																													              Photograph.click();
																															            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
																															            Thread.sleep(1000);
																														
																															            StringSelection ss4 = new StringSelection(fileUploadPath);
																															              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss4, null);

																															              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																															              Robot robot4 = new Robot();
																															              robot4.delay(250);
																															              robot4.keyPress(KeyEvent.VK_ENTER);
																															              robot4.keyRelease(KeyEvent.VK_ENTER);
																															              robot4.keyPress(KeyEvent.VK_CONTROL);
																															              robot4.keyPress(KeyEvent.VK_V);
																															              robot4.keyRelease(KeyEvent.VK_V);
																															              robot4.keyRelease(KeyEvent.VK_CONTROL);
																															              robot4.keyPress(KeyEvent.VK_ENTER);
																															              robot4.delay(50);
																															              robot4.keyRelease(KeyEvent.VK_ENTER);			
																																            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
																											              Thread.sleep(1000);
																													
																												            System.out.println("Photograph");

																												          //Scroll
																															JavascriptExecutor jse28 = (JavascriptExecutor)driver;
																															jse28.executeScript("window.scrollBy(0,250)", "");
																															Thread.sleep(1000);           
																								            
																								            Customer_Declaration_Form = driver.findElement(By.xpath(EApp_LandingPage.eapp_Customer_Declaration_Form));
																								              Customer_Declaration_Form.click();
																										            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
																										            Thread.sleep(1000);
																									
																										            StringSelection ss3 = new StringSelection(fileUploadPath);
																										              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss3, null);

																										              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																										              Robot robot3 = new Robot();
																										              robot3.delay(250);
																										              robot3.keyPress(KeyEvent.VK_ENTER);
																										              robot3.keyRelease(KeyEvent.VK_ENTER);
																										              robot3.keyPress(KeyEvent.VK_CONTROL);
																										              robot3.keyPress(KeyEvent.VK_V);
																										              robot3.keyRelease(KeyEvent.VK_V);
																										              robot3.keyRelease(KeyEvent.VK_CONTROL);
																										              robot3.keyPress(KeyEvent.VK_ENTER);
																										              robot3.delay(50);
																										              robot3.keyRelease(KeyEvent.VK_ENTER);			
																											            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
																						              Thread.sleep(1000);
																								
																							            System.out.println("Customer_Declaration_Form");

																						              
																						              Central_Kyc_Form = driver.findElement(By.xpath(EApp_LandingPage.central_KYC_form));
																						              Central_Kyc_Form.click();
																								            Extent_Reporting.Log_Pass("Clicking Central Kyc Form Browse Button","Clicked Central Kyc Form Browse Button");
																								            Thread.sleep(1000);
																							
																								            StringSelection ss2 = new StringSelection(fileUploadPath);
																								              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss2, null);

																								              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																								              Robot robot2 = new Robot();
																								              robot2.delay(250);
																								              robot2.keyPress(KeyEvent.VK_ENTER);
																								              robot2.keyRelease(KeyEvent.VK_ENTER);
																								              robot2.keyPress(KeyEvent.VK_CONTROL);
																								              robot2.keyPress(KeyEvent.VK_V);
																								              robot2.keyRelease(KeyEvent.VK_V);
																								              robot2.keyRelease(KeyEvent.VK_CONTROL);
																								              robot2.keyPress(KeyEvent.VK_ENTER);
																								              robot2.delay(50);
																								              robot2.keyRelease(KeyEvent.VK_ENTER);			
																									            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
																				              Thread.sleep(1000);
																						
																					            System.out.println("Central_Kyc_Form");

																					            I_Agree_Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.i_agree_Non_Medical_Requirements));
																					              I_Agree_Non_Medical_Requirements.click();
																							            Extent_Reporting.Log_Pass("Clicking Passport Copy Browse Button","Clicked Passport Copy Browse Button");
																							            Thread.sleep(15000);				
																					
																							            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
																							            Close_Button.click();
																									            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
																									            Thread.sleep(1000);
																									            
																									            abg_Employee = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee));
																									            abg_Employee.click();
																											            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
																											            Thread.sleep(1000);	            
																									    
																											            abg_Employee_browse = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee_browse));
																											            abg_Employee_browse.click();
																													            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
																													            Thread.sleep(1000);
																											          
																													            StringSelection ss8 = new StringSelection(fileUploadPath);
																													              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss8, null);

																													              //imitate mouse events like ENTER, CTRL+C, CTRL+V
																													              Robot robot8 = new Robot();
																													              robot8.delay(250);
																													              robot8.keyPress(KeyEvent.VK_ENTER);
																													              robot8.keyRelease(KeyEvent.VK_ENTER);
																													              robot8.keyPress(KeyEvent.VK_CONTROL);
																													              robot8.keyPress(KeyEvent.VK_V);
																													              robot8.keyRelease(KeyEvent.VK_V);
																													              robot8.keyRelease(KeyEvent.VK_CONTROL);
																													              robot8.keyPress(KeyEvent.VK_ENTER);
																													              robot8.delay(50);
																													              robot8.keyRelease(KeyEvent.VK_ENTER);			
																														            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
																									              Thread.sleep(1000);
																									              
																									              i_agree_ABG_Employee = driver.findElement(By.xpath(EApp_LandingPage.i_agree_ABG_Employee));
																									              i_agree_ABG_Employee.click();
																												            Extent_Reporting.Log_Pass("Clicking I agree ABG Employee","Clicked I Agree ABG Employee");
																												            Thread.sleep(1000);
																										     
																											            
																									            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
																									            Close_Button.click();
																											            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
																											            Thread.sleep(1000);
																									
																			
																			I_Agree_Document_Upload = driver.findElement(By.xpath(EApp_LandingPage.i_agree));
																			I_Agree_Document_Upload.click();
																		            Extent_Reporting.Log_Pass("Clicking I Agree Button","Clicked I Agree Button");
																		            Thread.sleep(5000);
																			
																			Extent_Reporting.Log_Pass_with_Screenshot("Uploading All Documents", "All Documents uploaded Successfully", driver);

}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}

//Document Upload
@SuppressWarnings("deprecation")
public void Document_Upload_Same(WebDriver driver) throws IOException, InterruptedException {
try {

	Identity_Proof = driver.findElement(By.xpath(EApp_LandingPage.identity_Proof));
	Identity_Proof.click();
    Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");
    Thread.sleep(1000);

	Identity_Proof_Document_Type = driver.findElement(By.xpath(EApp_LandingPage.typeOfDocument));

    Select Identity_Proof_DocumentType = new Select(Identity_Proof_Document_Type);
    Identity_Proof_DocumentType.selectByValue("1");	
		Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

		Identity_Proof_Browse_Button = driver.findElement(By.xpath(EApp_LandingPage.browseButton));
		Identity_Proof_Browse_Button.click();
        Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");

        Thread.sleep(500);
        StringSelection ss = new StringSelection(fileUploadPath);
          Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

          //imitate mouse events like ENTER, CTRL+C, CTRL+V
          Robot robot = new Robot();
          robot.delay(250);
          robot.keyPress(KeyEvent.VK_ENTER);
          robot.keyRelease(KeyEvent.VK_ENTER);
          robot.keyPress(KeyEvent.VK_CONTROL);
          robot.keyPress(KeyEvent.VK_V);
          robot.keyRelease(KeyEvent.VK_V);
          robot.keyRelease(KeyEvent.VK_CONTROL);
          robot.keyPress(KeyEvent.VK_ENTER);
          robot.delay(50);
          robot.keyRelease(KeyEvent.VK_ENTER);
            Extent_Reporting.Log_Pass("Selecting Identity Proof image","Selecting Identity Proof image");
             Thread.sleep(2000);
          Identity_Proof_Agree_Button = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
          Identity_Proof_Agree_Button.click();
            Extent_Reporting.Log_Pass("Clicking Identity Proof Agree Button","Clicked Identity Proof Agree Button");

            Thread.sleep(5000);

              Identity_Proof_Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
              Identity_Proof_Close_Button.click();
	            Extent_Reporting.Log_Pass("Clicking Identity Proof Close Button","Clicked Identity Proof Close Button");
	            Thread.sleep(1000);
	            
	            System.out.println("Identity_Proof_Agree_Button");

	            //Income Proof
	            Income_Proof = driver.findElement(By.xpath(EApp_LandingPage.incomeProof));
	            Income_Proof.click();
	            Extent_Reporting.Log_Pass("Clicking Income Proof","Clicked Income Proof");
	            Thread.sleep(1000);
	
				Income_Proof_Document_Type = driver.findElement(By.xpath(EApp_LandingPage.incomeProof_Type));

	            Select Income_Proof_DocumentType = new Select(Income_Proof_Document_Type);
	            Income_Proof_DocumentType.selectByValue("41");	
					Extent_Reporting.Log_Pass("Selecting Income Proof Document Type","Selected Income Proof Document Type");

					Income_Proof_Browse_Button = driver.findElement(By.xpath(EApp_LandingPage.incomeProof_browse));
					Income_Proof_Browse_Button.click();
		            Extent_Reporting.Log_Pass("Clicking Income Proof Browse Button","Clicked Income Proof Browse Button");
			
		            Thread.sleep(500);
		            StringSelection ss7 = new StringSelection(fileUploadPath);
		              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss7, null);

		              //imitate mouse events like ENTER, CTRL+C, CTRL+V
		              Robot robot7 = new Robot();
		              robot7.delay(250);
		              robot7.keyPress(KeyEvent.VK_ENTER);
		              robot7.keyRelease(KeyEvent.VK_ENTER);
		              robot7.keyPress(KeyEvent.VK_CONTROL);
		              robot7.keyPress(KeyEvent.VK_V);
		              robot7.keyRelease(KeyEvent.VK_V);
		              robot7.keyRelease(KeyEvent.VK_CONTROL);
		              robot7.keyPress(KeyEvent.VK_ENTER);
		              robot7.delay(50);
		              robot7.keyRelease(KeyEvent.VK_ENTER);
			            Extent_Reporting.Log_Pass("Selecting Income Proof image","Selecting Income Proof image");
			              Thread.sleep(2000);

		              Income_Proof_Agree_Button = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
		              Income_Proof_Agree_Button.click();
			            Extent_Reporting.Log_Pass("Clicking Income Proof Agree Button","Clicked Income Proof Agree Button");
			
			            Thread.sleep(5000);
			
			              Income_Proof_Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
			              Income_Proof_Close_Button.click();
				            Extent_Reporting.Log_Pass("Clicking Identity Proof Close Button","Clicked Identity Proof Close Button");
				            Thread.sleep(1000);

				            System.out.println("Income_Proof_Agree_Button");

				            
				            Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.nonMedicalRequirements));
				            Non_Medical_Requirements.click();
					            Extent_Reporting.Log_Pass("Clicking Non Medical Requirements","Clicked Non Medical Requirements");
					            Thread.sleep(1000);
				
					            Cancelled_Cheque = driver.findElement(By.xpath(EApp_LandingPage.neft_Cancelled_Cheque));
					            Cancelled_Cheque.click();
						            Extent_Reporting.Log_Pass("Clicking NEFT Cancelled Cheque Browse Button","Clicked NEFT Cancelled Cheque Browse Button");
						            Thread.sleep(1000);
					
						            StringSelection ss6 = new StringSelection(fileUploadPath);
						              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss6, null);

						              //imitate mouse events like ENTER, CTRL+C, CTRL+V
						              Robot robot6 = new Robot();
						              robot6.delay(250);
						              robot6.keyPress(KeyEvent.VK_ENTER);
						              robot6.keyRelease(KeyEvent.VK_ENTER);
						              robot6.keyPress(KeyEvent.VK_CONTROL);
						              robot6.keyPress(KeyEvent.VK_V);
						              robot6.keyRelease(KeyEvent.VK_V);
						              robot6.keyRelease(KeyEvent.VK_CONTROL);
						              robot6.keyPress(KeyEvent.VK_ENTER);
						              robot6.delay(50);
						              robot6.keyRelease(KeyEvent.VK_ENTER);			
							            Extent_Reporting.Log_Pass("Selecting Cancelled Checque image","Selecting Cancelled Checque image");
							              Thread.sleep(1000);

								            System.out.println("Cancelled Cheque");

						     			                                                                               //Photograph
					            
					           
										              Photograph = driver.findElement(By.xpath(EApp_LandingPage.photograph));
										              Photograph.click();
												            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
												            Thread.sleep(1000);
											
												            StringSelection ss4 = new StringSelection(fileUploadPath);
												              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss4, null);

												              //imitate mouse events like ENTER, CTRL+C, CTRL+V
												              Robot robot4 = new Robot();
												              robot4.delay(250);
												              robot4.keyPress(KeyEvent.VK_ENTER);
												              robot4.keyRelease(KeyEvent.VK_ENTER);
												              robot4.keyPress(KeyEvent.VK_CONTROL);
												              robot4.keyPress(KeyEvent.VK_V);
												              robot4.keyRelease(KeyEvent.VK_V);
												              robot4.keyRelease(KeyEvent.VK_CONTROL);
												              robot4.keyPress(KeyEvent.VK_ENTER);
												              robot4.delay(50);
												              robot4.keyRelease(KeyEvent.VK_ENTER);			
													            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
								              Thread.sleep(1000);
										
									            System.out.println("Photograph");

									          //Scroll
												JavascriptExecutor jse28 = (JavascriptExecutor)driver;
												jse28.executeScript("window.scrollBy(0,250)", "");
												Thread.sleep(1000);           
					            
					            Customer_Declaration_Form = driver.findElement(By.xpath(EApp_LandingPage.eapp_Customer_Declaration_Form));
					              Customer_Declaration_Form.click();
							            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
							            Thread.sleep(1000);
						
							            StringSelection ss3 = new StringSelection(fileUploadPath);
							              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss3, null);

							              //imitate mouse events like ENTER, CTRL+C, CTRL+V
							              Robot robot3 = new Robot();
							              robot3.delay(250);
							              robot3.keyPress(KeyEvent.VK_ENTER);
							              robot3.keyRelease(KeyEvent.VK_ENTER);
							              robot3.keyPress(KeyEvent.VK_CONTROL);
							              robot3.keyPress(KeyEvent.VK_V);
							              robot3.keyRelease(KeyEvent.VK_V);
							              robot3.keyRelease(KeyEvent.VK_CONTROL);
							              robot3.keyPress(KeyEvent.VK_ENTER);
							              robot3.delay(50);
							              robot3.keyRelease(KeyEvent.VK_ENTER);			
								            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
			              Thread.sleep(1000);
					
				            System.out.println("Customer_Declaration_Form");

			              
			              Central_Kyc_Form = driver.findElement(By.xpath(EApp_LandingPage.central_KYC_form));
			              Central_Kyc_Form.click();
					            Extent_Reporting.Log_Pass("Clicking Central Kyc Form Browse Button","Clicked Central Kyc Form Browse Button");
					            Thread.sleep(1000);
				
					            StringSelection ss2 = new StringSelection(fileUploadPath);
					              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss2, null);

					              //imitate mouse events like ENTER, CTRL+C, CTRL+V
					              Robot robot2 = new Robot();
					              robot2.delay(250);
					              robot2.keyPress(KeyEvent.VK_ENTER);
					              robot2.keyRelease(KeyEvent.VK_ENTER);
					              robot2.keyPress(KeyEvent.VK_CONTROL);
					              robot2.keyPress(KeyEvent.VK_V);
					              robot2.keyRelease(KeyEvent.VK_V);
					              robot2.keyRelease(KeyEvent.VK_CONTROL);
					              robot2.keyPress(KeyEvent.VK_ENTER);
					              robot2.delay(50);
					              robot2.keyRelease(KeyEvent.VK_ENTER);			
						            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
	              Thread.sleep(1000);
			
		            System.out.println("Central_Kyc_Form");

		            I_Agree_Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.i_agree_Non_Medical_Requirements));
		              I_Agree_Non_Medical_Requirements.click();
				            Extent_Reporting.Log_Pass("Clicking Passport Copy Browse Button","Clicked Passport Copy Browse Button");
				            Thread.sleep(15000);				
		
				            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
				            Close_Button.click();
						            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
						            Thread.sleep(1000);
					            
						            abg_Employee = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee));
						            abg_Employee.click();
								            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
								            Thread.sleep(1000);	            
						    
								            abg_Employee_browse = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee_browse));
								            abg_Employee_browse.click();
										            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
										            Thread.sleep(1000);
								          
										            StringSelection ss8 = new StringSelection(fileUploadPath);
										              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss8, null);

										              //imitate mouse events like ENTER, CTRL+C, CTRL+V
										              Robot robot8 = new Robot();
										              robot8.delay(250);
										              robot8.keyPress(KeyEvent.VK_ENTER);
										              robot8.keyRelease(KeyEvent.VK_ENTER);
										              robot8.keyPress(KeyEvent.VK_CONTROL);
										              robot8.keyPress(KeyEvent.VK_V);
										              robot8.keyRelease(KeyEvent.VK_V);
										              robot8.keyRelease(KeyEvent.VK_CONTROL);
										              robot8.keyPress(KeyEvent.VK_ENTER);
										              robot8.delay(50);
										              robot8.keyRelease(KeyEvent.VK_ENTER);			
											            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
						              Thread.sleep(2000);
						              
						              i_agree_ABG_Employee = driver.findElement(By.xpath(EApp_LandingPage.i_agree_ABG_Employee));
						              i_agree_ABG_Employee.click();
									            Extent_Reporting.Log_Pass("Clicking I agree ABG Employee","Clicked I Agree ABG Employee");
									            Thread.sleep(1000);
							     
								            
						            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
						            Close_Button.click();
								            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
								            Thread.sleep(1000);
						

I_Agree_Document_Upload = driver.findElement(By.xpath(EApp_LandingPage.i_agree));
I_Agree_Document_Upload.click();
        Extent_Reporting.Log_Pass("Clicking I Agree Button","Clicked I Agree Button");
        Thread.sleep(5000);
				

}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}


//Document Upload
@SuppressWarnings("deprecation")
public void Document_Upload_Same_ULIP(WebDriver driver) throws IOException, InterruptedException {
try {

	Identity_Proof = driver.findElement(By.xpath(EApp_LandingPage.identity_Proof));
	Identity_Proof.click();
  Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");
  Thread.sleep(1000);

	Identity_Proof_Document_Type = driver.findElement(By.xpath(EApp_LandingPage.typeOfDocument));

  Select Identity_Proof_DocumentType = new Select(Identity_Proof_Document_Type);
  Identity_Proof_DocumentType.selectByValue("1");	
		Extent_Reporting.Log_Pass("Selecting Age Proof","Selecting Age Proof as Aadhar Card");

		Identity_Proof_Browse_Button = driver.findElement(By.xpath(EApp_LandingPage.browseButton));
		Identity_Proof_Browse_Button.click();
      Extent_Reporting.Log_Pass("Clicking Identity Proof","Clicked Identity Proof");

      Thread.sleep(500);
      StringSelection ss = new StringSelection(fileUploadPath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

        //imitate mouse events like ENTER, CTRL+C, CTRL+V
        Robot robot = new Robot();
        robot.delay(250);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(50);
        robot.keyRelease(KeyEvent.VK_ENTER);
          Extent_Reporting.Log_Pass("Selecting Identity Proof image","Selecting Identity Proof image");
           Thread.sleep(2000);
        Identity_Proof_Agree_Button = driver.findElement(By.xpath(EApp_LandingPage.agree_button));
        Identity_Proof_Agree_Button.click();
          Extent_Reporting.Log_Pass("Clicking Identity Proof Agree Button","Clicked Identity Proof Agree Button");

          Thread.sleep(5000);

            Identity_Proof_Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
            Identity_Proof_Close_Button.click();
	            Extent_Reporting.Log_Pass("Clicking Identity Proof Close Button","Clicked Identity Proof Close Button");
	            Thread.sleep(1000);
	            
	            System.out.println("Identity_Proof_Agree_Button");

	                 
				            Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.nonMedicalRequirements));
				            Non_Medical_Requirements.click();
					            Extent_Reporting.Log_Pass("Clicking Non Medical Requirements","Clicked Non Medical Requirements");
					            Thread.sleep(1000);
				
					            Cancelled_Cheque = driver.findElement(By.xpath(EApp_LandingPage.neft_Cancelled_Cheque));
					            Cancelled_Cheque.click();
						            Extent_Reporting.Log_Pass("Clicking NEFT Cancelled Cheque Browse Button","Clicked NEFT Cancelled Cheque Browse Button");
						            Thread.sleep(1000);
					
						            StringSelection ss6 = new StringSelection(fileUploadPath);
						              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss6, null);

						              //imitate mouse events like ENTER, CTRL+C, CTRL+V
						              Robot robot6 = new Robot();
						              robot6.delay(250);
						              robot6.keyPress(KeyEvent.VK_ENTER);
						              robot6.keyRelease(KeyEvent.VK_ENTER);
						              robot6.keyPress(KeyEvent.VK_CONTROL);
						              robot6.keyPress(KeyEvent.VK_V);
						              robot6.keyRelease(KeyEvent.VK_V);
						              robot6.keyRelease(KeyEvent.VK_CONTROL);
						              robot6.keyPress(KeyEvent.VK_ENTER);
						              robot6.delay(50);
						              robot6.keyRelease(KeyEvent.VK_ENTER);			
							            Extent_Reporting.Log_Pass("Selecting Cancelled Checque image","Selecting Cancelled Checque image");
							              Thread.sleep(1000);

								            System.out.println("Cancelled Cheque");

						     			                                                                               //Photograph
					            
					           
										              Photograph = driver.findElement(By.xpath(EApp_LandingPage.photograph));
										              Photograph.click();
												            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
												            Thread.sleep(1000);
											
												            StringSelection ss4 = new StringSelection(fileUploadPath);
												              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss4, null);

												              //imitate mouse events like ENTER, CTRL+C, CTRL+V
												              Robot robot4 = new Robot();
												              robot4.delay(250);
												              robot4.keyPress(KeyEvent.VK_ENTER);
												              robot4.keyRelease(KeyEvent.VK_ENTER);
												              robot4.keyPress(KeyEvent.VK_CONTROL);
												              robot4.keyPress(KeyEvent.VK_V);
												              robot4.keyRelease(KeyEvent.VK_V);
												              robot4.keyRelease(KeyEvent.VK_CONTROL);
												              robot4.keyPress(KeyEvent.VK_ENTER);
												              robot4.delay(50);
												              robot4.keyRelease(KeyEvent.VK_ENTER);			
													            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
								              Thread.sleep(1000);
										
									            System.out.println("Photograph");

									          //Scroll
												JavascriptExecutor jse28 = (JavascriptExecutor)driver;
												jse28.executeScript("window.scrollBy(0,250)", "");
												Thread.sleep(1000);           
					            
					            Customer_Declaration_Form = driver.findElement(By.xpath(EApp_LandingPage.eapp_Customer_Declaration_Form));
					              Customer_Declaration_Form.click();
							            Extent_Reporting.Log_Pass("Clicking Photograph Browse Button","Clicked Photograph Browse Button");
							            Thread.sleep(1000);
						
							            StringSelection ss3 = new StringSelection(fileUploadPath);
							              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss3, null);

							              //imitate mouse events like ENTER, CTRL+C, CTRL+V
							              Robot robot3 = new Robot();
							              robot3.delay(250);
							              robot3.keyPress(KeyEvent.VK_ENTER);
							              robot3.keyRelease(KeyEvent.VK_ENTER);
							              robot3.keyPress(KeyEvent.VK_CONTROL);
							              robot3.keyPress(KeyEvent.VK_V);
							              robot3.keyRelease(KeyEvent.VK_V);
							              robot3.keyRelease(KeyEvent.VK_CONTROL);
							              robot3.keyPress(KeyEvent.VK_ENTER);
							              robot3.delay(50);
							              robot3.keyRelease(KeyEvent.VK_ENTER);			
								            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
			              Thread.sleep(1000);
					
				            System.out.println("Customer_Declaration_Form");

			              
			              Central_Kyc_Form = driver.findElement(By.xpath(EApp_LandingPage.central_KYC_form));
			              Central_Kyc_Form.click();
					            Extent_Reporting.Log_Pass("Clicking Central Kyc Form Browse Button","Clicked Central Kyc Form Browse Button");
					            Thread.sleep(1000);
				
					            StringSelection ss2 = new StringSelection(fileUploadPath);
					              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss2, null);

					              //imitate mouse events like ENTER, CTRL+C, CTRL+V
					              Robot robot2 = new Robot();
					              robot2.delay(250);
					              robot2.keyPress(KeyEvent.VK_ENTER);
					              robot2.keyRelease(KeyEvent.VK_ENTER);
					              robot2.keyPress(KeyEvent.VK_CONTROL);
					              robot2.keyPress(KeyEvent.VK_V);
					              robot2.keyRelease(KeyEvent.VK_V);
					              robot2.keyRelease(KeyEvent.VK_CONTROL);
					              robot2.keyPress(KeyEvent.VK_ENTER);
					              robot2.delay(50);
					              robot2.keyRelease(KeyEvent.VK_ENTER);			
						            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
	              Thread.sleep(1000);
			
		            System.out.println("Central_Kyc_Form");

		            I_Agree_Non_Medical_Requirements = driver.findElement(By.xpath(EApp_LandingPage.i_agree_Non_Medical_Requirements));
		              I_Agree_Non_Medical_Requirements.click();
				            Extent_Reporting.Log_Pass("Clicking Passport Copy Browse Button","Clicked Passport Copy Browse Button");
				            Thread.sleep(15000);				
		
				            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
				            Close_Button.click();
						            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
						            Thread.sleep(1000);
					            
						            abg_Employee = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee));
						            abg_Employee.click();
								            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
								            Thread.sleep(1000);	            
						    
								            abg_Employee_browse = driver.findElement(By.xpath(EApp_LandingPage.abg_Employee_browse));
								            abg_Employee_browse.click();
										            Extent_Reporting.Log_Pass("Clicking ABG Employee Button","Clicked ABG Employee Button");
										            Thread.sleep(1000);
								          
										            StringSelection ss8 = new StringSelection(fileUploadPath);
										              Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss8, null);

										              //imitate mouse events like ENTER, CTRL+C, CTRL+V
										              Robot robot8 = new Robot();
										              robot8.delay(250);
										              robot8.keyPress(KeyEvent.VK_ENTER);
										              robot8.keyRelease(KeyEvent.VK_ENTER);
										              robot8.keyPress(KeyEvent.VK_CONTROL);
										              robot8.keyPress(KeyEvent.VK_V);
										              robot8.keyRelease(KeyEvent.VK_V);
										              robot8.keyRelease(KeyEvent.VK_CONTROL);
										              robot8.keyPress(KeyEvent.VK_ENTER);
										              robot8.delay(50);
										              robot8.keyRelease(KeyEvent.VK_ENTER);			
											            Extent_Reporting.Log_Pass("Selecting Passport Copy image","Selecting Passport Copy image");
						              Thread.sleep(2000);
						              
						              i_agree_ABG_Employee = driver.findElement(By.xpath(EApp_LandingPage.i_agree_ABG_Employee));
						              i_agree_ABG_Employee.click();
									            Extent_Reporting.Log_Pass("Clicking I agree ABG Employee","Clicked I Agree ABG Employee");
									            Thread.sleep(1000);
							     
								            
						            Close_Button = driver.findElement(By.xpath(EApp_LandingPage.close_button));
						            Close_Button.click();
								            Extent_Reporting.Log_Pass("Clicking Close Button","Clicked Close Button");
								            Thread.sleep(1000);
						

I_Agree_Document_Upload = driver.findElement(By.xpath(EApp_LandingPage.i_agree));
I_Agree_Document_Upload.click();
      Extent_Reporting.Log_Pass("Clicking I Agree Button","Clicked I Agree Button");
      Thread.sleep(5000);
				

}
catch(Exception e)
{
	Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
	e.printStackTrace();
}
}


//Payment
@SuppressWarnings("deprecation")
public void Online_Payment(WebDriver driver) throws IOException, InterruptedException {
try {		

online_payment_submit_button = driver.findElement(By.xpath(EApp_LandingPage.online_payment_submit));
online_payment_submit_button.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(5000);

			            

        String winHandleBefore = driver.getWindowHandle();
        for (String handle : driver.getWindowHandles()) 
        {          
                 driver.switchTo().window(handle);
        }
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);  
		
		dummy_payment = driver.findElement(By.xpath(EApp_LandingPage.dummy_payment));
		dummy_payment.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(2000);
		
         
        i_agree_button = driver.findElement(By.xpath(EApp_LandingPage.i_agree_button));
        i_agree_button.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(2000);
        
        online_submit = driver.findElement(By.xpath(EApp_LandingPage.online_submit));
        online_submit.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(2000);
      // driver.switchTo().window(winHandleBefore);
        
        Pay_Now = driver.findElement(By.xpath(EApp_LandingPage.Pay_Now));
        Pay_Now.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(5000);


        Close_Payment_Success = driver.findElement(By.xpath(EApp_LandingPage.Close_Payment_Success));
        Close_Payment_Success.click();
        Extent_Reporting.Log_Pass("Clicking online payment submit Button","Clicked online payment submit Button");
        Thread.sleep(5000);
	       Extent_Reporting.Log_Pass_with_Screenshot("ABG Employee Checkbox Selected", "Entered Employee ID", driver);

driver.navigate().refresh();
        
Extent_Reporting.Log_Pass_with_Screenshot("ABG Employee Checkbox Selected", "Entered Employee ID", driver);


		
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
		}


		//Policy Tab
		@SuppressWarnings("deprecation")
		public void Eapp(WebDriver driver) throws IOException, InterruptedException {
			try {
				FileInputStream finput = new FileInputStream(src);
				  workbook = new XSSFWorkbook(finput);
				  sheet= workbook.getSheetAt(5);
				 Eapp_Button =driver.findElement(By.xpath(IChamp_HomePage.eApp_Link));
				 Eapp_Button.click();
				 Thread.sleep(2000);
				 Search_Input  =driver.findElement(By.xpath(EApp_LandingPage.Search_Input));
				 Search_Input.sendKeys("13588");
				 
				 Application_Number =driver.findElement(By.xpath("//*[@id='applicationListTableBody']/tr/td[6]/span[2]"));
				 Application_Number.click();
				 Thread.sleep(2000);
				   //Toggle - Existing BSLI policy
			       Thread.sleep(1000);
			       Existing_BSLI_Policy_Toggle_No= driver.findElement(By.xpath(EApp_LandingPage.Toggle_No_BSLI_Policy));
			       Existing_BSLI_Policy_Toggle_No.click();
			       	
			       Thread.sleep(1000);
					System.out.println("Toggle");

				    
					Aadhar_UID = driver.findElement(By.xpath(EApp_LandingPage.Proposer_UID));
					cell = sheet.getRow(6).getCell(44);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String AadharUID = cell.getStringCellValue();
				       System.out.println(AadharUID);	
				       Aadhar_UID.sendKeys(AadharUID);
				
					Thread.sleep(1000);
					Proposer_Personal_Details = driver.findElement(By.xpath(EApp_LandingPage.personal_Details));
					Proposer_Personal_Details.click();
					
					Thread.sleep(1000);
					Proposer_MiddleName = driver.findElement(By.xpath(EApp_LandingPage.Proposer_MiddleName));
					cell = sheet.getRow(6).getCell(46);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerMiddleName = cell.getStringCellValue();
				       System.out.println(ProposerMiddleName );	
				       Proposer_MiddleName.sendKeys(ProposerMiddleName );
			       Extent_Reporting.Log_Pass("Entering Proposer's Middle Name","Entered Proposer's Middle Name");
			       
			       Thread.sleep(1000);
			      Relationship = driver.findElement(By.xpath(minor_indian.relationshipwithInsurer));
					cell = sheet.getRow(6).getCell(47);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String Relationship1  = cell.getStringCellValue();
				       System.out.println(Relationship1 );	
				       Select Relationship_Dropdown = new Select(Relationship);
				       Relationship_Dropdown.selectByValue("PAREN");
			       Extent_Reporting.Log_Pass("Selecting Relationship with Insurer","Selected Relationship with Insurer as Parent");
			       
			       
			       
			       Thread.sleep(1000);
					Proposer_Marital_Status = driver.findElement(By.xpath(minor_indian.Proposer_MaritalStatus));
					cell = sheet.getRow(6).getCell(48);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String MaritalStatus = cell.getStringCellValue();
				       System.out.println(MaritalStatus);	
				       Select Proposer_Marital_Status_Dropdown = new Select(Proposer_Marital_Status );
				       Proposer_Marital_Status_Dropdown.selectByValue("M");
			       Extent_Reporting.Log_Pass("Selecting Marital Status","Selected Marital Status as Married");
			       
			       
			       Proposerholdingcitizenship = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Citizenship_NO));
			       Proposerholdingcitizenship.click();
			       
			       Proposertaxresident =driver.findElement(By.xpath(EApp_LandingPage.Proposer_Tax_Resident_NO));
			       Proposertaxresident.click(); 
			      
			       Thread.sleep(1000);
			       
			       //proposer professional details
			       Proposer_professional_Details=driver.findElement(By.xpath(EApp_LandingPage.proffessional_Details));
			       Proposer_professional_Details.click();
			          
			          //Qualifications
			          Proposer_Qualifications=driver.findElement(By.xpath(EApp_LandingPage.qualification_Dropdown));
			       cell = sheet.getRow(6).getCell(52);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String qualify = cell.getStringCellValue();
			          System.out.println(qualify); 
			          Select qualification1 = new Select( Proposer_Qualifications);
			          qualification1.selectByValue("S");
			          Extent_Reporting.Log_Pass("Entering Qualification ","Entered Qualification as "+qualify);
			               
			          //Occupations
			          Proposer_occupations =driver.findElement(By.xpath(EApp_LandingPage.occupation_Dropdown));
			       cell = sheet.getRow(6).getCell(54);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String occupy = cell.getStringCellValue();
			          System.out.println(occupy); 
			          Select occupations1 = new Select(Proposer_occupations);
			          occupations1.selectByValue("92");
			          Extent_Reporting.Log_Pass("Entering occupations ","Entered occupations as "+occupy);
			          
			          //Name of business
			          Proposer_Nameofbusiness =driver.findElement(By.xpath(EApp_LandingPage.BussEmployerName));
			          cell = sheet.getRow(6).getCell(55);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String Name_business = cell.getStringCellValue();
			          System.out.println(Name_business);
			          Proposer_Nameofbusiness.sendKeys(Name_business);
			          Extent_Reporting.Log_Pass("Entering Name of Business","Entered Name of Business Successfully");
			          
			          //Nature of Business
			          Proposer_Nature_Business =driver.findElement(By.xpath(EApp_LandingPage.NatureofBus));
			          cell = sheet.getRow(6).getCell(56);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String Nature_business = cell.getStringCellValue();
			          System.out.println(Nature_business);
			          Proposer_Nature_Business.sendKeys(Nature_business);
			          Extent_Reporting.Log_Pass("Entering Nature of Business","Entered Nature of Business Successfully");
			          
			          //Type of Organization
			          Proposer_Type_Organization=driver.findElement(By.xpath(EApp_LandingPage.BUsOrganizationType));
			          cell = sheet.getRow(6).getCell(57);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String type_organization = cell.getStringCellValue();
			          System.out.println(type_organization); 
			          Select type_organization1 = new Select(Proposer_Type_Organization);
			          type_organization1.selectByValue("H");
			             Extent_Reporting.Log_Pass("Entering Type_Organization ","Entered Type_Organization as "+type_organization1);
			          
			             //Years in Business
			             Proposer_Years_Business =driver.findElement(By.xpath(EApp_LandingPage.BusExperience));
			          cell = sheet.getRow(6).getCell(58);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String Years_business = cell.getStringCellValue();
			          System.out.println(Years_business);
			          Proposer_Years_Business.sendKeys(Years_business);
			          Extent_Reporting.Log_Pass("Entering Years of Business","Entered Years of Business Successfully");
			             
			          //Annual Income
			          Proposer_Annual_Income =driver.findElement(By.xpath(EApp_LandingPage.BusAnnualIncome));
			          cell = sheet.getRow(6).getCell(70);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String Annual_income = cell.getStringCellValue();
			          System.out.println(Annual_income);
			          Proposer_Annual_Income.sendKeys(Annual_income);
			          Extent_Reporting.Log_Pass("Entering Annual income","Entered Annual Income Successfully");
			          
			          //PAN
			          Proposer_Pan_Card=driver.findElement(By.xpath(EApp_LandingPage.pan));
			          cell = sheet.getRow(6).getCell(71);
			          cell.setCellType(Cell.CELL_TYPE_STRING);
			          String Pan_card = cell.getStringCellValue();
			          System.out.println(Pan_card);
			          Proposer_Pan_Card.sendKeys(Pan_card);
			          Extent_Reporting.Log_Pass("Entering Pan card","Entered Pan card Successfully");
			          
			        //PAN Card Validate
			          PanCard_Validatebutton = driver.findElement(By.xpath(EApp_LandingPage.validate_Button));
			          PanCard_Validatebutton.click();
			          
			         /*  //Close
			            pan_close =driver.findElement(By.xpath(""));
			            pan_close.click();
			            
			          */
			         
			          
			          
			       //Communication Details
			       Communication_Address = driver.findElement(By.xpath(EApp_LandingPage.Communication_Address));
			       Communication_Address.click();
			       
			       
			       //address1
			       
			       Thread.sleep(1000);
			       Proposer_Address1 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address1));
					cell = sheet.getRow(6).getCell(75);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerAddress1  = cell.getStringCellValue();
				       System.out.println(ProposerAddress1);	
				       Proposer_Address1.sendKeys(ProposerAddress1);
			       Extent_Reporting.Log_Pass("Entering Proposer's Address 1","Entered Proposer's Address1");
			       
			     //address2
			       
			       Thread.sleep(1000);
			       Proposer_Address2 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address2));
					cell = sheet.getRow(6).getCell(76);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerAddress2  = cell.getStringCellValue();
				       System.out.println(ProposerAddress2);	
				       Proposer_Address2.sendKeys(ProposerAddress2);
			       Extent_Reporting.Log_Pass("Entering Proposer's Address 2","Entered Proposer's Address2");
			       
			       //address3
			       
			       Thread.sleep(1000);
			       Proposer_Address3 = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Address3));
					cell = sheet.getRow(6).getCell(77);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerAddress3  = cell.getStringCellValue();
				       System.out.println(ProposerAddress3);	
				       Proposer_Address3.sendKeys(ProposerAddress3);
			       Extent_Reporting.Log_Pass("Entering Proposer's Address 3","Entered Proposer's Address3");
			       
			       //area
			       Thread.sleep(1000);
			       Proposer_Area= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Area));
					cell = sheet.getRow(6).getCell(78);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerArea  = cell.getStringCellValue();
				       System.out.println(ProposerArea);	
				       Proposer_Area.sendKeys(ProposerArea);
			       Extent_Reporting.Log_Pass("Entering Proposer's Area","Entered Proposer's Area");
			       
			       
			       //city/town/village
			       
			       Thread.sleep(1000);
			       Proposer_City_Town_Village= driver.findElement(By.xpath(EApp_LandingPage.Proposer_city));
					cell = sheet.getRow(6).getCell(79);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerCity  = cell.getStringCellValue();
				       System.out.println(ProposerCity);	
				       Proposer_City_Town_Village.sendKeys(ProposerCity);
			       Extent_Reporting.Log_Pass("Entering Proposer's City","Entered Proposer's City"); 
			       
			       
			       //pin
			       Thread.sleep(1000);
			       Proposer_Pin= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Pin));
					cell = sheet.getRow(6).getCell(80);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerPin  = cell.getStringCellValue();
				       System.out.println(ProposerPin);	
				       Proposer_Pin.sendKeys(ProposerPin);
			       Extent_Reporting.Log_Pass("Entering Proposer's Pin","Entered Proposer's Pin"); 
			       
			       //TelNo/ ResNo
			       
			       Thread.sleep(1000);
			       Proposer_TelNo_ResNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_Tel_Number));
					cell = sheet.getRow(6).getCell(81);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerTelNo  = cell.getStringCellValue();
				       System.out.println(ProposerTelNo);	
				       Proposer_TelNo_ResNo.sendKeys(ProposerTelNo);
			       Extent_Reporting.Log_Pass("Entering Proposer's Tel No","Entered Proposer's Tel No"); 
			       
			       
			       //mobile no
			       
			       Thread.sleep(1000);
			       Proposer_mobNo= driver.findElement(By.xpath(EApp_LandingPage.Proposer_mobile_Number));
					cell = sheet.getRow(6).getCell(82);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerMobNo  = cell.getStringCellValue();
				       System.out.println(ProposerMobNo);	
				       Proposer_mobNo.sendKeys(ProposerMobNo);
			       Extent_Reporting.Log_Pass("Entering Proposer's Mob No","Entered Proposer's Mob No"); 
			       
			       //alt mob no
			       
			       Thread.sleep(1000);
			       Proposer_AltmobNo = driver.findElement(By.xpath(EApp_LandingPage.Proposer_Alternate_Number));
					cell = sheet.getRow(6).getCell(83);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerAltMobNo  = cell.getStringCellValue();
				       System.out.println(ProposerAltMobNo);	
				       Proposer_AltmobNo.sendKeys(ProposerAltMobNo);
			       Extent_Reporting.Log_Pass("Entering Proposer's Alt Mob No","Entered Proposer's Alt Mob No"); 
			       
			       
			      //emailadd
			       
			       Thread.sleep(1000);
			       Proposer_Email= driver.findElement(By.xpath(EApp_LandingPage.Proposer_emailID));
					cell = sheet.getRow(6).getCell(84);
				       cell.setCellType(Cell.CELL_TYPE_STRING);
				       String ProposerEmailid = cell.getStringCellValue();
				       System.out.println(ProposerEmailid);	
				       Proposer_Email.sendKeys(ProposerEmailid);
			       Extent_Reporting.Log_Pass("Entering Proposer's EmailId","Entered Proposer's EmailId"); 
			       
			       
			       Proposer_GetPolicyDoc =driver.findElement(By.xpath(EApp_LandingPage.Get_Email_Toggle1_Yes));
			       Proposer_GetPolicyDoc.click();
			       
			       
			     //EIA Details
			       Thread.sleep(1000);
			       Proposer_EIA_Details = driver.findElement(By.xpath(EApp_LandingPage.EIA_Details));
			       Proposer_EIA_Details.click();   
			       EIA_Details =driver.findElement(By.xpath(EApp_LandingPage.EIA_NO));
			       EIA_Details .click();
			      
			       JavascriptExecutor jse1 = (JavascriptExecutor)driver;
					jse1.executeScript("window.scrollBy(0,250)", "");
					Thread.sleep(1000);
					Proposer_Agreebutton = driver.findElement(By.xpath(minor_indian.IAgree_button));
					Proposer_Agreebutton.click();
				
			    
			}
			catch(Exception e)
			{
				Extent_Reporting.Log_Fail("Details not entered","Element not found", driver);
				e.printStackTrace();
			}
		}


}

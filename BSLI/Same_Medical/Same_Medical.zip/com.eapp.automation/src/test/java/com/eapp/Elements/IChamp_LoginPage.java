package com.eapp.Elements;

public class IChamp_LoginPage {

	//iChamp Login
		public static String Progress="//span[@id='percentageProgress']";
		public static String Ichamp="//*[@id='headerPort']/div/div[2]/img";
		public static String Uname="//input[@id='j_username']";
		public static String Pwd="//input[@id='j_password']";
		public static String Login="//a[@class='loginBtn']";
	
}
